<?php
// order.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';

$stmt = $pdo->prepare("SELECT o.*, g.name as game_name, p.name as package_name
    FROM orders o
    LEFT JOIN games g ON o.game_id = g.id
    LEFT JOIN packages p ON o.package_id = p.id
    WHERE o.user_id = ?
    ORDER BY o.id DESC");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();
$hasOrders = count($orders) > 0;

?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <!-- Header -->
    <div class="bg-white px-4 py-4 flex items-center shadow-sm sticky top-0 z-40">
        <div class="border border-gray-200 rounded-lg p-1.5 mr-3 flex items-center justify-center text-gray-700 bg-gray-50">
            <i class="fa-solid fa-list-ul text-sm"></i>
        </div>
        <h1 class="text-xl font-bold text-gray-900">My Orders</h1>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <?php if(!$hasOrders): ?>
        <!-- Empty State -->
        <div class="bg-white rounded-2xl shadow-soft p-10 text-center border border-gray-100 mb-6">
            <h3 class="text-lg font-bold text-gray-700 mb-5">No order data found !</h3>
            <a href="<?= SITE_URL ?>/index.php" class="inline-block bg-accent hover:bg-orange-600 text-white font-bold py-2.5 px-8 rounded-full shadow-md transition text-sm uppercase tracking-wider">
                ORDER NOW
            </a>
        </div>
        <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($orders as $o): ?>
            <div class="bg-white rounded-xl p-4 shadow-soft border border-gray-100">
                <div class="flex justify-between items-start mb-2">
                    <div>
                        <p class="font-bold text-gray-800"><?= htmlspecialchars($o['game_name'] ?? 'Topup') ?></p>
                        <p class="text-xs text-gray-500"><?= htmlspecialchars($o['package_name'] ?? '') ?></p>
                    </div>
                    <span class="text-xs font-bold px-2 py-1 rounded-full bg-yellow-50 text-yellow-700"><?= htmlspecialchars($o['status']) ?></span>
                </div>
                <div class="flex justify-between text-xs text-gray-500">
                    <span>#<?= htmlspecialchars($o['order_no']) ?></span>
                    <span class="font-bold text-accent">৳ <?= number_format((float)$o['total_amount'], 2) ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
?>
<!-- Floating Action Button (Headset Icon) -->
<a href="#" class="fixed bottom-24 right-4 bg-accent text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:scale-105 transition z-50 border-2 border-white/20">
    <i class="fa-solid fa-headset text-xl"></i>
</a>
<?php
require_once 'common/footer.php';
?>

