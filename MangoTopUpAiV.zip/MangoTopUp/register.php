<?php
require_once 'common/config.php';
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}
$pageTitle = 'Register | ' . siteName();
require_once 'common/header.php';
require_once 'common/navbar.php';
?>
<div class="min-h-screen bg-gradient-to-b from-orange-50 to-white pb-24">
    <main class="max-w-6xl mx-auto px-4 py-8 md:py-14 grid md:grid-cols-2 gap-10 items-center">
        <div class="hidden md:block fade-up">
            <span class="text-[11px] font-bold text-accent uppercase tracking-widest flex items-center gap-2 mb-3">
                <span class="w-1.5 h-1.5 bg-accent rounded-full"></span> Create Account
            </span>
            <h1 class="text-5xl font-black text-gray-900 leading-tight">Join<br><span class="text-accent"><?= htmlspecialchars(siteName()) ?></span></h1>
            <p class="text-sm text-gray-500 mt-4 max-w-sm">Create an account for fast, safe and simple game topup.</p>
            <div class="mt-8 grid grid-cols-3 gap-3 max-w-sm">
                <div class="bg-white rounded-2xl p-3 text-center shadow-soft border border-orange-100"><i class="fa-solid fa-bolt text-accent"></i><p class="text-[11px] font-bold mt-1">Fast</p></div>
                <div class="bg-white rounded-2xl p-3 text-center shadow-soft border border-orange-100"><i class="fa-solid fa-shield-halved text-primary"></i><p class="text-[11px] font-bold mt-1">Secure</p></div>
                <div class="bg-white rounded-2xl p-3 text-center shadow-soft border border-orange-100"><i class="fa-solid fa-heart text-rose-500"></i><p class="text-[11px] font-bold mt-1">Trusted</p></div>
            </div>
        </div>

        <div class="bg-white p-5 md:p-7 rounded-2xl shadow-soft border border-orange-100/80 fade-up">
            <div class="md:hidden mb-6 text-center">
                <h1 class="text-3xl font-black text-gray-900">Create <span class="text-accent">Account</span></h1>
                <p class="text-sm text-gray-500 mt-1">Join us for fast and secure gaming topups.</p>
            </div>
            <form action="ajax/auth.php" method="POST" class="ajax-form space-y-3">
                <input type="hidden" name="action" value="register">
                <label class="block text-xs font-bold text-gray-700">Full Name</label>
                <div class="relative">
                    <i class="fa-regular fa-user absolute left-4 top-3.5 text-gray-400"></i>
                    <input type="text" name="name" required class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-accent" placeholder="Enter your name">
                </div>
                <label class="block text-xs font-bold text-gray-700">Email address</label>
                <div class="relative">
                    <i class="fa-regular fa-envelope absolute left-4 top-3.5 text-gray-400"></i>
                    <input type="email" name="email" required class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-accent" placeholder="Enter your email">
                </div>
                <label class="block text-xs font-bold text-gray-700">Phone Number</label>
                <div class="relative">
                    <i class="fa-solid fa-phone absolute left-4 top-3.5 text-gray-400"></i>
                    <input type="text" name="phone" required class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-accent" placeholder="e.g. 017xxxxxxxx">
                </div>
                <label class="block text-xs font-bold text-gray-700">Password</label>
                <div class="relative">
                    <i class="fa-solid fa-lock absolute left-4 top-3.5 text-gray-400"></i>
                    <input type="password" name="password" required class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-accent" placeholder="Create a password">
                </div>
                <button type="submit" class="w-full bg-accent hover:bg-orange-600 text-white font-bold py-3.5 rounded-xl shadow-md flex items-center justify-center gap-2 mt-2">
                    <i class="fa-solid fa-user-plus"></i> Register Now
                </button>
                <p class="text-center text-xs text-gray-500">Already have an account? <a href="login.php" class="text-accent font-bold">Sign In</a></p>
                <p class="text-center text-[11px] text-gray-400">By registering you agree to our <a href="terms.php" class="text-accent font-bold">Terms</a> & <a href="privacy-policy.php" class="text-accent font-bold">Privacy Policy</a>.</p>
            </form>
        </div>
    </main>
</div>
<?php require_once 'common/bottom-nav.php'; ?>
<script src="<?= SITE_URL ?>/assets/js/security.js"></script>
<script src="<?= SITE_URL ?>/assets/js/script.js"></script>
</body></html>
