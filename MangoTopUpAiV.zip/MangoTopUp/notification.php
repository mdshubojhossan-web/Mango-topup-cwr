<?php
// notification.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

// Mark as read automatically when visited
$pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$userId]);
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <div class="bg-white px-4 py-4 flex items-center justify-between shadow-sm sticky top-0 z-40">
        <div class="flex items-center gap-3">
            <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
            <h1 class="text-xl font-bold text-gray-900">Notifications</h1>
        </div>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <?php if(count($notifications) > 0): ?>
            <div class="space-y-3">
                <?php foreach($notifications as $notif): ?>
                <div class="bg-white p-4 rounded-xl shadow-soft border <?= $notif['is_read'] ? 'border-gray-100' : 'border-primary bg-green-50/20' ?> flex gap-3">
                    <div class="w-10 h-10 rounded-full bg-orange-50 text-accent flex items-center justify-center flex-shrink-0">
                        <i class="fa-solid fa-bell"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-gray-800 text-sm"><?= htmlspecialchars($notif['title']) ?></h4>
                        <p class="text-xs text-gray-600 mt-1"><?= htmlspecialchars($notif['message']) ?></p>
                        <span class="text-[10px] text-gray-400 mt-2 block"><i class="fa-regular fa-clock"></i> <?= date('d M Y, h:i A', strtotime($notif['created_at'])) ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-2xl shadow-soft p-10 text-center border border-gray-100">
                <i class="fa-regular fa-bell-slash text-4xl text-gray-300 mb-4"></i>
                <h3 class="text-lg font-bold text-gray-700">No Notifications</h3>
                <p class="text-xs text-gray-500 mt-2">You don't have any notifications yet.</p>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>

