<?php
// icx/tax.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$settings_query = $pdo->query("SELECT key_name, value FROM site_settings WHERE key_name IN ('tax_percentage', 'tax_status')")->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-file-invoice-dollar text-primary mr-2"></i> Tax & Fee Settings</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <form action="../ajax/admin-action.php" method="POST" class="max-w-2xl bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden p-6">
            <input type="hidden" name="action" value="update_settings">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Service Fee / Tax Status</label>
                <select name="settings[tax_status]" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary">
                    <option value="active" <?= ($settings_query['tax_status'] ?? '') == 'active' ? 'selected' : '' ?>>Enabled</option>
                    <option value="inactive" <?= ($settings_query['tax_status'] ?? '') == 'inactive' ? 'selected' : '' ?>>Disabled</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Tax Percentage (%)</label>
                <input type="number" step="0.01" name="settings[tax_percentage]" value="<?= htmlspecialchars($settings_query['tax_percentage'] ?? '0') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary">
            </div>

            <button type="submit" class="bg-primary hover:bg-green-600 text-white font-bold py-2.5 px-6 rounded-lg shadow-md transition flex items-center gap-2">
                <i class="fa-solid fa-save"></i> Save Settings
            </button>
        </form>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

