<?php
require_once __DIR__ . '/../common/config.php';
if (isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT * FROM admins WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $admin = $stmt->fetch();
    if ($admin && ($admin['status'] ?? 'active') === 'active' && password_verify($password, $admin['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        header('Location: index.php');
        exit;
    }
    $error = 'Invalid email or password';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - <?= htmlspecialchars(siteName()) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,#0b1220,#1f2937);font-family:Inter,system-ui,sans-serif;padding:16px}
.card{width:100%;max-width:400px;background:#fff;border-radius:20px;padding:28px;box-shadow:0 20px 50px rgba(0,0,0,.25)}
.logo{width:52px;height:52px;border-radius:16px;background:#ff7a00;color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;margin:0 auto 12px}
h1{text-align:center;margin:0 0 4px;font-size:22px}
p.sub{text-align:center;color:#64748b;margin:0 0 18px;font-size:13px}
label{display:block;font-size:11px;font-weight:800;margin:10px 0 6px}
input{width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px;font-size:14px;box-sizing:border-box}
button{width:100%;margin-top:16px;background:#ff7a00;color:#fff;border:0;border-radius:12px;padding:12px;font-weight:800}
.err{background:#fef2f2;color:#dc2626;padding:10px;border-radius:12px;font-size:13px;margin-bottom:10px}
</style>
</head>
<body>
<form method="POST" class="card">
  <div class="logo">M</div>
  <h1>Admin Panel</h1>
  <p class="sub"><?= htmlspecialchars(siteName()) ?> control center</p>
  <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <label>Email</label>
  <input type="email" name="email" required value="admin@mangotopup.com">
  <label>Password</label>
  <input type="password" name="password" required placeholder="admin123">
  <button>Sign In</button>
</form>
</body>
</html>
