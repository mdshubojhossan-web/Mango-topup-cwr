<?php
// icx/email-template.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$settings_query = $pdo->query("SELECT key_name, value FROM site_settings WHERE key_name LIKE 'email_%'")->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-envelope-open-text text-primary mr-2"></i> Email Templates</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <form action="../ajax/admin-action.php" method="POST" class="max-w-3xl bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden p-6 ajax-form">
            <input type="hidden" name="action" value="update_settings">
            
            <div class="mb-6">
                <h3 class="font-bold text-gray-800 mb-2 border-b border-gray-100 pb-2">Welcome Email</h3>
                <label class="block text-xs font-bold text-gray-700 mb-1">Subject</label>
                <input type="text" name="settings[email_welcome_sub]" value="<?= htmlspecialchars($settings_query['email_welcome_sub'] ?? 'Welcome to ICX TOPUP!') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary mb-2">
                <label class="block text-xs font-bold text-gray-700 mb-1">Message Body (Use {name} for user name)</label>
                <textarea name="settings[email_welcome_body]" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary"><?= htmlspecialchars($settings_query['email_welcome_body'] ?? "Hello {name},\nWelcome to ICX TOPUP.") ?></textarea>
            </div>

            <div class="mb-6">
                <h3 class="font-bold text-gray-800 mb-2 border-b border-gray-100 pb-2">Order Completion Email</h3>
                <label class="block text-xs font-bold text-gray-700 mb-1">Subject</label>
                <input type="text" name="settings[email_order_sub]" value="<?= htmlspecialchars($settings_query['email_order_sub'] ?? 'Order Completed - ICX TOPUP') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary mb-2">
                <label class="block text-xs font-bold text-gray-700 mb-1">Message Body (Use {order_id}, {game_name})</label>
                <textarea name="settings[email_order_body]" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary"><?= htmlspecialchars($settings_query['email_order_body'] ?? "Your order {order_id} for {game_name} is now complete.") ?></textarea>
            </div>

            <button type="submit" class="bg-primary hover:bg-green-600 text-white font-bold py-2.5 px-6 rounded-lg shadow-md transition flex items-center gap-2">
                <i class="fa-solid fa-save"></i> Save Templates
            </button>
        </form>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

