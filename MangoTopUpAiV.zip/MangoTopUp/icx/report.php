<?php
// icx/report.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Quick stats
$totalSales = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE status='Completed'")->fetchColumn() ?? 0;
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status='Completed'")->fetchColumn() ?? 0;
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-chart-pie text-primary mr-2"></i> Sales Report</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-primary">
                <p class="text-xs font-bold text-gray-500 uppercase">Total Revenue (All Time)</p>
                <h3 class="text-3xl font-black text-gray-800 mt-2">৳ <?= number_format($totalSales, 2) ?></h3>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-accent">
                <p class="text-xs font-bold text-gray-500 uppercase">Total Completed Orders</p>
                <h3 class="text-3xl font-black text-gray-800 mt-2"><?= number_format($totalOrders) ?></h3>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
            <i class="fa-solid fa-file-csv text-4xl text-gray-300 mb-3"></i>
            <h3 class="font-bold text-gray-700 mb-2">Export Data</h3>
            <p class="text-xs text-gray-500 mb-4">Download complete sales history as CSV format for accounting.</p>
            <button class="bg-gray-800 text-white px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-gray-900 transition shadow-md">
                <i class="fa-solid fa-download mr-2"></i> Download CSV
            </button>
        </div>

    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

