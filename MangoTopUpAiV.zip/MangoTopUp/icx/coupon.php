<?php
// icx/coupon.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$coupons = $pdo->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll();
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-tags text-primary mr-2"></i> Manage Coupons</h2>
        <button class="bg-primary hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md transition flex items-center gap-2">
            <i class="fa-solid fa-plus"></i> Add Coupon
        </button>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                        <th class="p-4 font-bold">Code</th>
                        <th class="p-4 font-bold">Discount</th>
                        <th class="p-4 font-bold">Usage Limit</th>
                        <th class="p-4 font-bold text-center">Status</th>
                        <th class="p-4 font-bold text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    <?php if(count($coupons) > 0): foreach($coupons as $c): ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4 font-mono font-bold text-accent"><?= htmlspecialchars($c['code']) ?></td>
                            <td class="p-4 text-gray-700 font-bold">
                                <?= $c['discount_type'] == 'percentage' ? $c['discount_value'].'%' : '৳'.$c['discount_value'] ?>
                            </td>
                            <td class="p-4 text-gray-600 text-xs"><?= $c['used_count'] ?> / <?= $c['usage_limit'] ?></td>
                            <td class="p-4 text-center">
                                <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold"><?= ucfirst($c['status']) ?></span>
                            </td>
                            <td class="p-4 text-right">
                                <button class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 p-2 rounded transition"><i class="fa-solid fa-trash-can"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="5" class="p-8 text-center text-gray-500">No coupons found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

