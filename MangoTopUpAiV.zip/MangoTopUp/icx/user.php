<?php
// icx/user.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Fetch users
$query = "SELECT * FROM users ORDER BY created_at DESC LIMIT 100";
$users = $pdo->query($query)->fetchAll();
?>

<div class="admin-page">
    
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-users text-primary mr-2"></i> Manage Users</h2>
        <div class="relative">
            <input type="text" placeholder="Search user..." class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary w-64">
            <i class="fa-solid fa-search absolute left-3 top-2.5 text-gray-400"></i>
        </div>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                            <th class="p-4 font-bold">User Info</th>
                            <th class="p-4 font-bold">Contact</th>
                            <th class="p-4 font-bold">Balance</th>
                            <th class="p-4 font-bold">Support PIN</th>
                            <th class="p-4 font-bold text-center">Status</th>
                            <th class="p-4 font-bold text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm divide-y divide-gray-100">
                        <?php if(count($users) > 0): ?>
                            <?php foreach($users as $u): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-4">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-bold">
                                            <?= strtoupper(substr($u['name'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div class="font-bold text-gray-900"><?= htmlspecialchars($u['name']) ?></div>
                                            <div class="text-xs text-gray-500">ID: #<?= $u['id'] ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="p-4 text-gray-600">
                                    <div class="mb-1"><i class="fa-regular fa-envelope text-gray-400 w-4"></i> <?= htmlspecialchars($u['email']) ?></div>
                                    <div class="text-xs"><i class="fa-solid fa-phone text-gray-400 w-4"></i> <?= htmlspecialchars($u['phone'] ?? 'N/A') ?></div>
                                </td>
                                <td class="p-4 font-bold text-accent">
                                    ৳ <?= number_format($u['balance'], 2) ?>
                                </td>
                                <td class="p-4 font-mono text-gray-600">
                                    <?= htmlspecialchars($u['support_pin']) ?>
                                </td>
                                <td class="p-4 text-center">
                                    <?php if($u['status'] == 'active'): ?>
                                        <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold">Active</span>
                                    <?php else: ?>
                                        <span class="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold">Blocked</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-4 text-right space-x-1">
                                    <button onclick="const a=prompt('Add/remove balance (use - to deduct)','100'); if(a!==null) adminPost({action:'adjust_balance',id:'<?= $u['id'] ?>',amount:a});" class="bg-green-50 text-green-700 px-2 py-1 rounded text-xs font-bold">Balance</button>
                                    <button onclick="adminPost({action:'toggle_user',id:'<?= $u['id'] ?>'})" class="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-bold">Block</button>

                                    <button class="text-primary hover:text-green-700 bg-green-50 hover:bg-green-100 p-2 rounded transition mr-1" title="Add/Deduct Balance">
                                        <i class="fa-solid fa-wallet"></i>
                                    </button>
                                    <button class="text-blue-500 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 p-2 rounded transition mr-1" title="View Profile">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                    <?php if($u['status'] == 'active'): ?>
                                    <button class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 p-2 rounded transition" title="Block User">
                                        <i class="fa-solid fa-ban"></i>
                                    </button>
                                    <?php else: ?>
                                    <button class="text-green-500 hover:text-green-700 bg-green-50 hover:bg-green-100 p-2 rounded transition" title="Unblock User">
                                        <i class="fa-solid fa-unlock"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="p-8 text-center text-gray-500">
                                    <i class="fa-solid fa-users-slash text-4xl mb-3 text-gray-300"></i>
                                    <p>No users found.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<?php require_once __DIR__ . '/common/footer.php'; ?>

