<?php
// icx/logs.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$logs =$pdo->query("SELECT l.*, a.name FROM activity_logs l LEFT JOIN admins a ON l.admin_id = a.id ORDER BY l.created_at DESC LIMIT 100")->fetchAll();
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-clipboard-list text-primary mr-2"></i> Activity Logs</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                        <th class="p-4 font-bold">Time</th>
                        <th class="p-4 font-bold">Admin</th>
                        <th class="p-4 font-bold">Action</th>
                        <th class="p-4 font-bold">IP Address</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    <?php if(count($logs) > 0): foreach($logs as$l): ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4 text-xs text-gray-500 font-mono"><?= date('d M Y, h:i A', strtotime($l['created_at'])) ?></td>
                            <td class="p-4 font-bold text-gray-900"><?= htmlspecialchars($l['name'] ?? 'System') ?></td>
                            <td class="p-4 text-gray-700"><?= htmlspecialchars($l['action']) ?></td>
                            <td class="p-4 text-xs font-mono text-gray-500"><?= htmlspecialchars($l['ip_address'] ?? 'Unknown') ?></td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="4" class="p-8 text-center text-gray-500">No logs found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

