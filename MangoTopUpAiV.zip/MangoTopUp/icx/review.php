<?php
// icx/review.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$query = "SELECT r.*, u.name as user_name, g.name as game_name 
          FROM reviews r 
          JOIN users u ON r.user_id = u.id 
          JOIN games g ON r.game_id = g.id 
          ORDER BY r.created_at DESC";
$reviews = $pdo->query($query)->fetchAll();
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-star text-primary mr-2"></i> Manage Reviews</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                        <th class="p-4 font-bold">User & Game</th>
                        <th class="p-4 font-bold">Rating</th>
                        <th class="p-4 font-bold w-1/3">Comment</th>
                        <th class="p-4 font-bold text-center">Status</th>
                        <th class="p-4 font-bold text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    <?php if(count($reviews) > 0): foreach($reviews as$r): ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4">
                                <div class="font-bold text-gray-900"><?= htmlspecialchars($r['user_name']) ?></div>
                                <div class="text-xs text-primary"><?= htmlspecialchars($r['game_name']) ?></div>
                            </td>
                            <td class="p-4 text-yellow-500 text-xs">
                                <?php for($i=1; $i<=5; $i++) echo $i <=$r['rating'] ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>'; ?>
                            </td>
                            <td class="p-4 text-gray-600 text-xs italic">"<?= htmlspecialchars($r['comment']) ?>"</td>
                            <td class="p-4 text-center">
                                <?php 
                                    $bg = $r['status'] == 'approved' ? 'bg-green-100 text-green-700' : ($r['status'] == 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700');
                                ?>
                                <span class="px-2 py-1 rounded text-xs font-bold <?= $bg ?>"><?= ucfirst($r['status']) ?></span>
                            </td>
                            <td class="p-4 text-right">
                                <?php if($r['status'] == 'pending'): ?>
                                    <button class="bg-green-500 hover:bg-green-600 text-white p-2 rounded transition text-xs mr-1"><i class="fa-solid fa-check"></i></button>
                                <?php endif; ?>
                                <button class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 p-2 rounded transition"><i class="fa-solid fa-trash-can"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="5" class="p-8 text-center text-gray-500">No reviews found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

