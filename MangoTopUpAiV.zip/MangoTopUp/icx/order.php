<?php
// icx/order.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Fetch orders (Mock query structure)
$statusFilter = $_GET['status'] ?? 'All';
$query = "SELECT o.*, u.name as user_name, g.name as game_name, p.name as package_name 
          FROM orders o 
          LEFT JOIN users u ON o.user_id = u.id 
          LEFT JOIN games g ON o.game_id = g.id 
          LEFT JOIN packages p ON o.package_id = p.id";

if($statusFilter !== 'All') {
    $query .= " WHERE o.status = " . $pdo->quote($statusFilter);
}
$query .= " ORDER BY o.created_at DESC LIMIT 50";
$orders = $pdo->query($query)->fetchAll();
?>

<!-- Main Content Area -->
<div class="admin-page">
    
    <!-- Top Navbar -->
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-cart-shopping text-primary mr-2"></i> Manage Orders</h2>
        <div class="flex items-center gap-3">
            <span class="bg-gray-100 text-gray-600 px-3 py-1.5 rounded-full text-sm font-medium"><i class="fa-solid fa-user-shield mr-1"></i> <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
        </div>
    </header>
    
    <!-- Content Scrollable -->
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <!-- Status Filters -->
        <div class="flex gap-2 mb-6 overflow-x-auto pb-2">
            <a href="?status=All" class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition <?= $statusFilter == 'All' ? 'bg-primary text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' ?>">All Orders</a>
            <a href="?status=Pending" class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition <?= $statusFilter == 'Pending' ? 'bg-yellow-500 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' ?>">Pending</a>
            <a href="?status=Processing" class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition <?= $statusFilter == 'Processing' ? 'bg-blue-500 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' ?>">Processing</a>
            <a href="?status=Completed" class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition <?= $statusFilter == 'Completed' ? 'bg-green-500 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' ?>">Completed</a>
            <a href="?status=Cancelled" class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition <?= $statusFilter == 'Cancelled' ? 'bg-red-500 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' ?>">Cancelled</a>
        </div>

        <!-- Orders Table -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                            <th class="p-4 font-bold">Order ID</th>
                            <th class="p-4 font-bold">User</th>
                            <th class="p-4 font-bold">Game & Package</th>
                            <th class="p-4 font-bold">Player ID</th>
                            <th class="p-4 font-bold">Amount</th>
                            <th class="p-4 font-bold">Status</th>
                            <th class="p-4 font-bold text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm divide-y divide-gray-100">
                        <?php if(count($orders) > 0): ?>
                            <?php foreach($orders as $o): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-4 font-medium text-gray-900">#<?= htmlspecialchars($o['order_no']) ?></td>
                                <td class="p-4 text-gray-600"><?= htmlspecialchars($o['user_name']) ?></td>
                                <td class="p-4">
                                    <div class="font-bold text-gray-800"><?= htmlspecialchars($o['game_name']) ?></div>
                                    <div class="text-xs text-primary"><?= htmlspecialchars($o['package_name']) ?></div>
                                </td>
                                <td class="p-4 font-mono text-gray-600"><?= htmlspecialchars($o['player_id'] ?? 'N/A') ?></td>
                                <td class="p-4 font-bold text-accent">৳ <?= number_format($o['total_amount'], 2) ?></td>
                                <td class="p-4">
                                    <?php 
                                        $bg = 'bg-gray-100 text-gray-600';
                                        if($o['status'] == 'Pending') $bg = 'bg-yellow-100 text-yellow-700';
                                        if($o['status'] == 'Processing') $bg = 'bg-blue-100 text-blue-700';
                                        if($o['status'] == 'Completed') $bg = 'bg-green-100 text-green-700';
                                        if($o['status'] == 'Cancelled') $bg = 'bg-red-100 text-red-700';
                                    ?>
                                    <span class="px-2.5 py-1 rounded-md text-xs font-bold <?= $bg ?>"><?= $o['status'] ?></span>
                                </td>
                                <td class="p-4 text-right">
                                    <select onchange="updateOrderStatus(<?= $o['id'] ?>, this.value)" class="bg-gray-50 border border-gray-200 text-gray-700 text-xs rounded focus:ring-primary focus:border-primary block w-full p-2 outline-none">
                                        <option value="Pending" <?= $o['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="Processing" <?= $o['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                                        <option value="Completed" <?= $o['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                                        <option value="Cancelled" <?= $o['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="p-8 text-center text-gray-500">
                                    <i class="fa-solid fa-box-open text-4xl mb-3 text-gray-300"></i>
                                    <p>No orders found.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<?php require_once __DIR__ . '/common/footer.php'; ?>

