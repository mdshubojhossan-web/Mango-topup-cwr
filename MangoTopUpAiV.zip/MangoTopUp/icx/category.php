<?php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';
$editId=(int)($_GET['edit']??0); $edit=null;
if($editId){ $st=$pdo->prepare("SELECT * FROM categories WHERE id=?"); $st->execute([$editId]); $edit=$st->fetch(); }
$rows=$pdo->query("SELECT * FROM categories ORDER BY sort_order ASC, id ASC")->fetchAll();
?>
<div class="admin-page">
<header class="h-16 bg-white border-b flex items-center justify-between px-6">
  <h2 class="text-xl font-bold">Categories</h2>
</header>
<main class="flex-1 overflow-y-auto p-6 space-y-6 bg-adminbg">
  <form action="../ajax/admin-action.php" method="POST" class="ajax-form bg-white rounded-xl border p-5 grid md:grid-cols-4 gap-3">
    <input type="hidden" name="action" value="save_category">
    <input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
    <input name="name" required value="<?= htmlspecialchars($edit['name']??'') ?>" placeholder="Category name" class="border rounded-lg px-3 py-2 text-sm">
    <input name="slug" value="<?= htmlspecialchars($edit['slug']??'') ?>" placeholder="slug (flash, hot...)" class="border rounded-lg px-3 py-2 text-sm">
    <input type="number" name="sort_order" value="<?= htmlspecialchars($edit['sort_order']??0) ?>" placeholder="Sort" class="border rounded-lg px-3 py-2 text-sm">
    <div class="flex gap-2">
      <select name="status" class="border rounded-lg px-3 py-2 text-sm flex-1">
        <option value="active">Active</option>
        <option value="inactive" <?= (($edit['status']??'')==='inactive')?'selected':'' ?>>Inactive</option>
      </select>
      <button class="bg-orange-500 text-white font-bold px-4 rounded-lg"><?= $edit?'Update':'Add' ?></button>
    </div>
  </form>
  <div class="bg-white rounded-xl border overflow-hidden">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs uppercase text-gray-500"><tr><th class="p-3 text-left">Name</th><th class="p-3">Slug</th><th class="p-3">Sort</th><th class="p-3">Status</th><th class="p-3 text-right">Action</th></tr></thead>
      <tbody class="divide-y">
      <?php foreach($rows as $r): ?>
        <tr>
          <td class="p-3 font-bold"><?= htmlspecialchars($r['name']) ?></td>
          <td class="p-3 text-center"><?= htmlspecialchars($r['slug']) ?></td>
          <td class="p-3 text-center"><?= (int)$r['sort_order'] ?></td>
          <td class="p-3 text-center"><?= ($r['status']??'active')==='active'?'<span class="text-green-600 font-bold">ON</span>':'<span class="text-red-500 font-bold">OFF</span>' ?></td>
          <td class="p-3 text-right space-x-2">
            <a href="?edit=<?= $r['id'] ?>" class="text-blue-600 font-bold">Edit</a>
            <button onclick="adminPost({action:'toggle_category',id:'<?= $r['id'] ?>'})" class="text-amber-600 font-bold">On/Off</button>
            <button onclick="adminPost({action:'delete_category',id:'<?= $r['id'] ?>'})" class="text-red-600 font-bold">Delete</button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>
