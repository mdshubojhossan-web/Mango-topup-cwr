<?php
// icx/seo.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$settings_query = $pdo->query("SELECT key_name, value FROM site_settings WHERE key_name IN ('seo_title', 'seo_desc', 'seo_keywords')")->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-magnifying-glass text-primary mr-2"></i> SEO Settings</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <form action="../ajax/admin-action.php" method="POST" class="max-w-2xl bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden p-6">
            <input type="hidden" name="action" value="update_settings">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Global Meta Title</label>
                <input type="text" name="settings[seo_title]" value="<?= htmlspecialchars($settings_query['seo_title'] ?? '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary">
            </div>

            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Meta Keywords (Comma separated)</label>
                <input type="text" name="settings[seo_keywords]" value="<?= htmlspecialchars($settings_query['seo_keywords'] ?? '') ?>" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary">
            </div>

            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Global Meta Description</label>
                <textarea name="settings[seo_desc]" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary"><?= htmlspecialchars($settings_query['seo_desc'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="bg-primary hover:bg-green-600 text-white font-bold py-2.5 px-6 rounded-lg shadow-md transition flex items-center gap-2">
                <i class="fa-solid fa-save"></i> Save SEO Settings
            </button>
        </form>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

