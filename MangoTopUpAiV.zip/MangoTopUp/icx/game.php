<?php
// icx/game.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$type = $_GET['type'] ?? 'uid';
$games = $pdo->prepare("SELECT * FROM games WHERE type = ? ORDER BY sort_order ASC");
$games->execute([$type]);
$gamesList = $games->fetchAll();
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-gamepad text-primary mr-2"></i> <?= strtoupper($type) ?> Games</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden p-6">
            <h3 class="font-bold text-gray-800 mb-4">Categorized List</h3>
            <ul class="space-y-2 text-sm text-gray-700">
                <?php if(count($gamesList) > 0): ?>
                    <?php foreach($gamesList as $g): ?>
                        <li class="border-b border-gray-100 pb-2 flex items-center justify-between">
                            <span><i class="fa-solid fa-caret-right text-accent mr-2"></i> <?= htmlspecialchars($g['name']) ?></span>
                            <a href="product.php" class="text-blue-500 hover:underline">Edit</a>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="text-gray-500">No games in this category.</li>
                <?php endif; ?>
            </ul>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

