<?php
// icx/payment-method.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Fetch payment methods
$methods = $pdo->query("SELECT * FROM payment_methods ORDER BY sort_order ASC")->fetchAll();
?>

<div class="admin-page">
    
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-money-check-dollar text-primary mr-2"></i> Payment Methods</h2>
        <button class="bg-primary hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md transition flex items-center gap-2" onclick="document.getElementById('addMethodModal').classList.remove('hidden')">
            <i class="fa-solid fa-plus"></i> Add Method
        </button>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                            <th class="p-4 font-bold">Method Name</th>
                            <th class="p-4 font-bold">Number / Details</th>
                            <th class="p-4 font-bold text-center">Status</th>
                            <th class="p-4 font-bold text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm divide-y divide-gray-100">
                        <?php if(count($methods) > 0): ?>
                            <?php foreach($methods as $m): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-4">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded bg-gray-100 flex items-center justify-center font-bold text-gray-400 border border-gray-200">
                                            <?= htmlspecialchars(substr($m['name'], 0, 2)) ?>
                                        </div>
                                        <div class="font-bold text-gray-900"><?= htmlspecialchars($m['name']) ?></div>
                                    </div>
                                </td>
                                <td class="p-4">
                                    <div class="font-mono font-bold text-accent tracking-wider text-lg"><?= htmlspecialchars($m['number']) ?></div>
                                </td>
                                <td class="p-4 text-center">
                                    <?php if($m['status'] == 'active'): ?>
                                        <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold">Active</span>
                                    <?php else: ?>
                                        <span class="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-4 text-right">
                                    <button class="text-gray-500 hover:text-accent bg-gray-100 hover:bg-orange-50 p-2 rounded transition mr-1" title="Edit">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    <button class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 p-2 rounded transition" title="Delete">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="p-8 text-center text-gray-500">
                                    <i class="fa-solid fa-money-bills text-4xl mb-3 text-gray-300"></i>
                                    <p>No payment methods found. Add bKash, Nagad etc.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<!-- Add Method Modal -->
<div id="addMethodModal" class="fixed inset-0 bg-gray-900/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <h3 class="font-bold text-gray-800"><i class="fa-solid fa-plus-circle text-primary mr-1"></i> Add Payment Method</h3>
            <button onclick="document.getElementById('addMethodModal').classList.add('hidden')" class="text-gray-400 hover:text-red-500 transition"><i class="fa-solid fa-xmark text-lg"></i></button>
        </div>
        <form action="../ajax/admin-action.php" method="POST" class="p-6">
            <input type="hidden" name="action" value="add_payment_method">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Method Name (e.g. bKash Personal)</label>
                <input type="text" name="name" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary">
            </div>
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Account Number</label>
                <input type="text" name="number" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary font-mono tracking-wider">
            </div>

            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Status</label>
                <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            
            <button type="submit" class="w-full bg-primary hover:bg-green-600 text-white font-bold py-2.5 rounded-lg shadow-md transition">
                Save Method
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/common/footer.php'; ?>

