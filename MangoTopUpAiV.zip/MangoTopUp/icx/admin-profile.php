<?php
// icx/admin-profile.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-user-shield text-primary mr-2"></i> Admin Profile</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <div class="max-w-2xl bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="p-6 border-b border-gray-100 bg-gray-50 flex items-center gap-4">
                <div class="w-16 h-16 rounded-full bg-primary text-white flex items-center justify-center text-2xl font-bold shadow-md">
                    <?= strtoupper(substr($admin['name'], 0, 1)) ?>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-gray-900"><?= htmlspecialchars($admin['name']) ?></h3>
                    <p class="text-xs text-gray-500 font-mono">Super Admin</p>
                </div>
            </div>

            <form action="../ajax/admin-action.php" method="POST" class="p-6 ajax-form">
                <input type="hidden" name="action" value="update_admin_profile">
                
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-700 mb-1">Email Address</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($admin['email']) ?>" required class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary">
                </div>

                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-700 mb-1">New Password (Leave blank to keep current)</label>
                    <input type="password" name="password" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary" placeholder="Enter new password">
                </div>

                <button type="submit" class="bg-primary hover:bg-green-600 text-white font-bold py-2.5 px-6 rounded-lg shadow-md transition flex items-center gap-2">
                    <i class="fa-solid fa-save"></i> Update Profile
                </button>
            </form>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

