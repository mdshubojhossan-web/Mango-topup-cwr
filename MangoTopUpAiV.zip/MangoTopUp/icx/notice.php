<?php
// icx/notice.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$notice_text = getSetting($pdo, 'notice_text');
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-bullhorn text-primary mr-2"></i> Scrolling Notice Bar</h2>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <form action="../ajax/admin-action.php" method="POST" class="max-w-2xl bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden p-6 ajax-form">
            <input type="hidden" name="action" value="update_settings">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Notice Text (Visible on all user pages)</label>
                <textarea name="settings[notice_text]" rows="3" class="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-primary" placeholder="Enter scrolling notice here..."><?= htmlspecialchars($notice_text ?? '') ?></textarea>
                <p class="text-[10px] text-gray-500 mt-1">Leave empty to completely hide the notice bar from the website.</p>
            </div>

            <button type="submit" class="bg-primary hover:bg-green-600 text-white font-bold py-2.5 px-6 rounded-lg shadow-md transition flex items-center gap-2">
                <i class="fa-solid fa-save"></i> Save Notice
            </button>
        </form>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

