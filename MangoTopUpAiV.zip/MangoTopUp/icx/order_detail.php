<?php
// icx/order_detail.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$orderId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT o.*, u.name as user_name, u.phone as user_phone, u.email as user_email, g.name as game_name, p.name as package_name 
          FROM orders o 
          JOIN users u ON o.user_id = u.id 
          JOIN games g ON o.game_id = g.id 
          JOIN packages p ON o.package_id = p.id 
          WHERE o.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    die("Order not found.");
}
?>

<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <div class="flex items-center gap-3">
            <a href="order.php" class="text-gray-500 hover:text-primary"><i class="fa-solid fa-arrow-left"></i></a>
            <h2 class="text-xl font-bold text-gray-800">Order #<?= htmlspecialchars($order['order_no']) ?></h2>
        </div>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 border-b border-gray-100 pb-2"><i class="fa-solid fa-gamepad text-gray-400 mr-2"></i> Game Details</h3>
                <div class="space-y-3 text-sm">
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Game:</span> <span class="font-bold text-gray-900"><?= htmlspecialchars($order['game_name']) ?></span></div>
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Package:</span> <span class="text-primary font-bold"><?= htmlspecialchars($order['package_name']) ?></span></div>
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Player ID:</span> <span class="font-mono bg-gray-100 px-2 py-0.5 rounded"><?= htmlspecialchars($order['player_id'] ?? 'N/A') ?></span></div>
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Quantity:</span> <span><?= $order['quantity'] ?></span></div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 border-b border-gray-100 pb-2"><i class="fa-solid fa-money-bill-wave text-gray-400 mr-2"></i> Payment Details</h3>
                <div class="space-y-3 text-sm">
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Amount:</span> <span class="font-bold text-accent text-lg">৳ <?= number_format($order['total_amount'], 2) ?></span></div>
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Method:</span> <span class="bg-gray-100 px-2 py-0.5 rounded font-bold"><?= htmlspecialchars($order['payment_method']) ?></span></div>
                    <div class="flex justify-between"><span class="text-gray-500 font-bold">Transaction ID:</span> <span class="font-mono tracking-wider uppercase"><?= htmlspecialchars($order['txn_id']) ?></span></div>
                    <div class="flex justify-between items-center"><span class="text-gray-500 font-bold">Status:</span> 
                        <select onchange="updateOrderStatus(<?= $order['id'] ?>, this.value)" class="bg-gray-50 border border-gray-300 text-gray-900 text-xs rounded-lg focus:ring-primary focus:border-primary block p-2">
                            <option value="Pending" <?= $order['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="Processing" <?= $order['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                            <option value="Completed" <?= $order['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 col-span-1 md:col-span-2">
                <h3 class="text-lg font-bold text-gray-800 mb-4 border-b border-gray-100 pb-2"><i class="fa-solid fa-user text-gray-400 mr-2"></i> Customer Info</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div><span class="text-gray-500 block text-xs font-bold uppercase mb-1">Name</span><span class="font-bold text-gray-900"><?= htmlspecialchars($order['user_name']) ?></span></div>
                    <div><span class="text-gray-500 block text-xs font-bold uppercase mb-1">Email</span><span><?= htmlspecialchars($order['user_email']) ?></span></div>
                    <div><span class="text-gray-500 block text-xs font-bold uppercase mb-1">Phone</span><span><?= htmlspecialchars($order['user_phone'] ?? 'N/A') ?></span></div>
                </div>
            </div>

        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>

