<?php
// icx/wallet-requests.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Fetch pending wallet requests
$query = "SELECT w.*, u.name as user_name, u.phone as user_phone 
          FROM wallet_requests w 
          JOIN users u ON w.user_id = u.id 
          ORDER BY w.created_at DESC";
$requests = $pdo->query($query)->fetchAll();
?>

<div class="admin-page">
    
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-money-bill-transfer text-primary mr-2"></i> Wallet Requests</h2>
        <div class="flex gap-2">
            <span class="bg-yellow-100 text-yellow-700 px-3 py-1.5 rounded-lg text-sm font-bold border border-yellow-200">Pending: <?= count(array_filter($requests, fn($r) => $r['status'] == 'Pending')) ?></span>
        </div>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                            <th class="p-4 font-bold">Date & Time</th>
                            <th class="p-4 font-bold">User</th>
                            <th class="p-4 font-bold">Payment Method</th>
                            <th class="p-4 font-bold">Transaction ID</th>
                            <th class="p-4 font-bold">Amount</th>
                            <th class="p-4 font-bold text-center">Status</th>
                            <th class="p-4 font-bold text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm divide-y divide-gray-100">
                        <?php if(count($requests) > 0): ?>
                            <?php foreach($requests as $req): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-4 text-gray-500 text-xs">
                                    <?= date('d M Y, h:i A', strtotime($req['created_at'])) ?>
                                </td>
                                <td class="p-4">
                                    <div class="font-bold text-gray-900"><?= htmlspecialchars($req['user_name']) ?></div>
                                    <div class="text-xs text-gray-500"><?= htmlspecialchars($req['user_phone'] ?? '') ?></div>
                                </td>
                                <td class="p-4">
                                    <span class="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-bold border border-gray-200"><?= htmlspecialchars($req['payment_method']) ?></span>
                                </td>
                                <td class="p-4 font-mono text-gray-700 font-bold uppercase tracking-wider">
                                    <?= htmlspecialchars($req['txn_id']) ?>
                                </td>
                                <td class="p-4 font-bold text-accent">
                                    ৳ <?= number_format($req['amount'], 2) ?>
                                </td>
                                <td class="p-4 text-center">
                                    <?php 
                                        $bg = 'bg-gray-100 text-gray-600';
                                        if($req['status'] == 'Pending') $bg = 'bg-yellow-100 text-yellow-700 border border-yellow-200';
                                        if($req['status'] == 'Approved') $bg = 'bg-green-100 text-green-700 border border-green-200';
                                        if($req['status'] == 'Rejected') $bg = 'bg-red-100 text-red-700 border border-red-200';
                                    ?>
                                    <span class="px-2.5 py-1 rounded-md text-xs font-bold <?= $bg ?>"><?= $req['status'] ?></span>
                                </td>
                                <td class="p-4 text-right space-x-1">
                                    <?php if($req['status'] == 'Pending'): ?>
                                    <button onclick="adminPost({action:'wallet_action',id:'<?= $req['id'] ?>',do:'approve'})" class="bg-primary hover:bg-green-600 text-white p-2 rounded transition text-xs font-bold">
                                        <i class="fa-solid fa-check"></i> Approve
                                    </button>
                                    <button onclick="adminPost({action:'wallet_action',id:'<?= $req['id'] ?>',do:'reject'})" class="bg-red-500 hover:bg-red-600 text-white p-2 rounded transition text-xs font-bold">
                                        <i class="fa-solid fa-xmark"></i> Reject
                                    </button>
                                    <?php else: ?>
                                    <span class="text-gray-400 text-xs italic">Processed</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="p-8 text-center text-gray-500">
                                    <i class="fa-solid fa-inbox text-4xl mb-3 text-gray-300"></i>
                                    <p>No wallet requests found.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<?php require_once __DIR__ . '/common/footer.php'; ?>

