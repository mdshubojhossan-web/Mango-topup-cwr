<?php
// icx/redeem-code.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Fetch existing codes
$query = "SELECT c.*, g.name as game_name, p.name as package_name, o.order_no 
          FROM redeem_codes c 
          JOIN games g ON c.game_id = g.id 
          JOIN packages p ON c.package_id = p.id 
          LEFT JOIN orders o ON c.order_id = o.id 
          ORDER BY c.created_at DESC LIMIT 100";
$codes = $pdo->query($query)->fetchAll();
?>

<div class="admin-page">
    
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-ticket text-primary mr-2"></i> Manage Redeem Codes</h2>
        <button class="bg-primary hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md transition flex items-center gap-2" onclick="document.getElementById('addCodeModal').classList.remove('hidden')">
            <i class="fa-solid fa-plus"></i> Add New Codes
        </button>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-200">
                            <th class="p-4 font-bold">Game & Package</th>
                            <th class="p-4 font-bold">Code</th>
                            <th class="p-4 font-bold text-center">Status</th>
                            <th class="p-4 font-bold">Used In Order</th>
                            <th class="p-4 font-bold text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm divide-y divide-gray-100">
                        <?php if(count($codes) > 0): ?>
                            <?php foreach($codes as $c): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-4">
                                    <div class="font-bold text-gray-900"><?= htmlspecialchars($c['game_name']) ?></div>
                                    <div class="text-xs text-primary"><?= htmlspecialchars($c['package_name']) ?></div>
                                </td>
                                <td class="p-4 font-mono font-bold text-gray-700">
                                    <?= htmlspecialchars($c['code']) ?>
                                </td>
                                <td class="p-4 text-center">
                                    <?php if($c['status'] == 'available'): ?>
                                        <span class="bg-green-100 text-green-700 px-2.5 py-1 rounded-md text-xs font-bold border border-green-200">Available</span>
                                    <?php else: ?>
                                        <span class="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-md text-xs font-bold border border-gray-200">Used</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-4 text-gray-600 font-mono text-xs">
                                    <?= $c['order_no'] ? '#'.htmlspecialchars($c['order_no']) : '-' ?>
                                </td>
                                <td class="p-4 text-right">
                                    <button class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 p-2 rounded transition" title="Delete Code">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="p-8 text-center text-gray-500">
                                    <i class="fa-solid fa-ticket-simple text-4xl mb-3 text-gray-300"></i>
                                    <p>No redeem codes found. Add some codes for voucher games.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<!-- Add Code Modal (Hidden by default) -->
<div id="addCodeModal" class="fixed inset-0 bg-gray-900/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <h3 class="font-bold text-gray-800"><i class="fa-solid fa-plus-circle text-primary mr-1"></i> Add Bulk Codes</h3>
            <button onclick="document.getElementById('addCodeModal').classList.add('hidden')" class="text-gray-400 hover:text-red-500 transition"><i class="fa-solid fa-xmark text-lg"></i></button>
        </div>
        <form action="../ajax/admin-action.php" method="POST" class="p-6">
            <input type="hidden" name="action" value="add_codes">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Select Game</label>
                <select name="game_id" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary">
                    <option value="">-- Select Game --</option>
                    <!-- In reality, populate this via PHP from games table where type='voucher' -->
                    <option value="1">Unipin Voucher (BD)</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Select Package</label>
                <select name="package_id" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary">
                    <option value="">-- Select Package --</option>
                    <!-- Populate via AJAX based on game selection -->
                    <option value="1">115 Diamond Code</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Paste Codes (One code per line)</label>
                <textarea name="codes" rows="5" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm font-mono focus:outline-none focus:border-primary" placeholder="UPBD-XXXX-YYYY&#10;UPBD-AAAA-BBBB"></textarea>
            </div>
            
            <button type="submit" class="w-full bg-primary hover:bg-green-600 text-white font-bold py-2.5 rounded-lg shadow-md transition">
                Save Codes
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/common/footer.php'; ?>

