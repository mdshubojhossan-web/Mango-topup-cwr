<?php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';
$s = $pdo->query("SELECT key_name, value FROM site_settings")->fetchAll(PDO::FETCH_KEY_PAIR);
$v = function($k,$d='') use($s){ return htmlspecialchars($s[$k] ?? $d); };
?>
<div class="admin-page">
<form action="../ajax/admin-action.php" method="POST" enctype="multipart/form-data" class="ajax-form" style="display:grid;gap:16px;max-width:920px">
<input type="hidden" name="action" value="update_settings">

<section class="admin-card" style="padding:18px">
  <h3 class="section-title">Brand</h3>
  <div class="admin-grid">
    <div class="field"><label>Site name (changes everywhere except developer credit)</label><input name="settings[site_name]" value="<?= $v('site_name','Mango TopUp') ?>"></div>
    <div class="field"><label>Currency symbol</label><input name="settings[currency_symbol]" value="<?= $v('currency_symbol','৳') ?>"></div>
    <div class="field" style="grid-column:1/-1">
      <label>Logo upload</label>
      <?php if (!empty($s['site_logo'])): ?><img src="<?= $v('site_logo') ?>" style="height:44px;margin-bottom:8px"><?php endif; ?>
      <input type="file" name="site_logo_file" accept="image/*">
      <input type="hidden" name="settings[site_logo]" value="<?= $v('site_logo') ?>">
    </div>
  </div>
</section>

<section class="admin-card" style="padding:18px">
  <h3 class="section-title">Colors</h3>
  <div class="admin-grid admin-grid-4">
    <div class="field"><label>Accent</label><input type="color" name="settings[color_accent]" value="<?= $v('color_accent','#FF7A00') ?>"></div>
    <div class="field"><label>Primary</label><input type="color" name="settings[color_primary]" value="<?= $v('color_primary','#3FAE72') ?>"></div>
    <div class="field"><label>Dark</label><input type="color" name="settings[color_dark]" value="<?= $v('color_dark','#0B1B36') ?>"></div>
    <div class="field"><label>Background</label><input type="color" name="settings[color_bg]" value="<?= $v('color_bg','#F6F7FB') ?>"></div>
  </div>
</section>

<section class="admin-card" style="padding:18px">
  <h3 class="section-title">Notice bar</h3>
  <div class="field"><label>Scrolling text</label><input name="settings[notice_text]" value="<?= $v('notice_text') ?>"></div>
</section>

<section class="admin-card" style="padding:18px">
  <h3 class="section-title">Free Fire Player Name API</h3>
  <div class="field">
    <label>API URL (use {uid} as the player ID placeholder)</label>
    <input name="settings[player_name_api_url]" value="<?= $v('player_name_api_url','http://ixbd.qd.je/ff.php?uid={uid}') ?>" placeholder="http://example.com/ff.php?uid={uid}">
    <small style="display:block;margin-top:6px;color:#64748b">Free Fire UID পাঠিয়ে URL-এর {uid} অংশে ID বসিয়ে GET request করা হবে। Response-এর username দেখানো হবে।</small>
  </div>
</section>

<section class="admin-card" style="padding:18px" id="popup">
  <h3 class="section-title">Popup ad</h3>
  <div class="admin-grid">
    <div class="field"><label>Status</label>
      <select name="settings[popup_status]">
        <option value="active" <?= (($s['popup_status']??'')==='active')?'selected':'' ?>>Active</option>
        <option value="inactive" <?= (($s['popup_status']??'')!=='active')?'selected':'' ?>>Inactive</option>
      </select>
    </div>
    <div class="field"><label>Button text</label><input name="settings[popup_btn]" value="<?= $v('popup_btn','Click now') ?>"></div>
    <div class="field" style="grid-column:1/-1"><label>Title</label><input name="settings[popup_title]" value="<?= $v('popup_title') ?>"></div>
    <div class="field" style="grid-column:1/-1"><label>Message</label><textarea name="settings[popup_message]" rows="3"><?= $v('popup_message') ?></textarea></div>
    <div class="field" style="grid-column:1/-1"><label>Link</label><input name="settings[popup_link]" value="<?= $v('popup_link') ?>"></div>
    <div class="field" style="grid-column:1/-1">
      <label>Popup image</label>
      <?php if (!empty($s['popup_image'])): ?><img src="<?= $v('popup_image') ?>" style="width:160px;border-radius:12px;margin-bottom:8px"><?php endif; ?>
      <input type="file" name="popup_image_file" accept="image/*">
      <input type="hidden" name="settings[popup_image]" value="<?= $v('popup_image') ?>">
    </div>
  </div>
</section>

<section class="admin-card" style="padding:18px">
  <h3 class="section-title">Support links</h3>
  <div class="admin-grid">
    <div class="field"><label>WhatsApp</label><input name="settings[support_whatsapp]" value="<?= $v('support_whatsapp') ?>"></div>
    <div class="field"><label>Telegram support</label><input name="settings[support_telegram]" value="<?= $v('support_telegram') ?>"></div>
    <div class="field"><label>Facebook page</label><input name="settings[social_facebook]" value="<?= $v('social_facebook') ?>"></div>
    <div class="field"><label>Telegram group</label><input name="settings[social_group]" value="<?= $v('social_group') ?>"></div>
    <div class="field"><label>Support hours</label><input name="settings[support_hours]" value="<?= $v('support_hours','9AM-12PM') ?>"></div>
    <div class="field"><label>Helpline number</label><input name="settings[support_phone]" value="<?= $v('support_phone') ?>"></div>
  </div>
</section>

<section class="admin-card" style="padding:18px">
  <h3 class="section-title">SEO / extra</h3>
  <div class="admin-grid">
    <div class="field" style="grid-column:1/-1"><label>Homepage title</label><input name="settings[seo_title]" value="<?= $v('seo_title') ?>"></div>
    <div class="field" style="grid-column:1/-1"><label>Homepage description</label><textarea name="settings[seo_desc]" rows="2"><?= $v('seo_desc') ?></textarea></div>
  </div>
</section>

<div style="display:flex;justify-content:flex-end">
  <button class="btn btn-orange">Save all settings</button>
</div>
</form>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>
