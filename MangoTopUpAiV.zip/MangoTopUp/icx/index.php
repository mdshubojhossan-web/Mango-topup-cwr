<?php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

$users = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$orders = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$pending = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status='Pending'")->fetchColumn();
$games = (int)$pdo->query('SELECT COUNT(*) FROM games')->fetchColumn();
$walletReq = (int)$pdo->query("SELECT COUNT(*) FROM wallet_requests WHERE status='Pending'")->fetchColumn();
$sales = (float)$pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status='Completed'")->fetchColumn();
$recent = $pdo->query("SELECT o.*, u.name as user_name, g.name as game_name FROM orders o LEFT JOIN users u ON o.user_id=u.id LEFT JOIN games g ON o.game_id=g.id ORDER BY o.id DESC LIMIT 8")->fetchAll();
?>
<div class="admin-page">
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-solid fa-chart-line text-primary mr-2"></i> Dashboard</h2>
        <span class="text-sm font-medium text-gray-500">Hi, <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
    </header>
    <main class="flex-1 overflow-y-auto bg-adminbg p-6">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <a href="product.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Products</p><p class="text-xs text-gray-500">Add / edit / prices</p></a>
            <a href="category.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Categories</p><p class="text-xs text-gray-500">Homepage sections</p></a>
            <a href="site-settings.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Settings</p><p class="text-xs text-gray-500">Logo, colors, popup</p></a>
            <a href="order.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Orders</p><p class="text-xs text-gray-500">Pending & complete</p></a>
            <a href="slider.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Banners</p><p class="text-xs text-gray-500">Home sliders</p></a>
            <a href="wallet-requests.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Wallet</p><p class="text-xs text-gray-500">Approve topup</p></a>
            <a href="user.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Users</p><p class="text-xs text-gray-500">Block / balance</p></a>
            <a href="payment-method.php" class="bg-white border rounded-xl p-4 hover:border-orange-400"><p class="font-bold text-sm">Payments</p><p class="text-xs text-gray-500">bKash / Nagad</p></a>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"><p class="text-xs text-gray-500 font-bold uppercase">Users</p><p class="text-2xl font-black mt-1"><?= $users ?></p></div>
            <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"><p class="text-xs text-gray-500 font-bold uppercase">Orders</p><p class="text-2xl font-black mt-1"><?= $orders ?></p></div>
            <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"><p class="text-xs text-gray-500 font-bold uppercase">Pending</p><p class="text-2xl font-black mt-1 text-yellow-600"><?= $pending ?></p></div>
            <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"><p class="text-xs text-gray-500 font-bold uppercase">Games</p><p class="text-2xl font-black mt-1"><?= $games ?></p></div>
            <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"><p class="text-xs text-gray-500 font-bold uppercase">Wallet Requests</p><p class="text-2xl font-black mt-1"><?= $walletReq ?></p></div>
            <div class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"><p class="text-xs text-gray-500 font-bold uppercase">Completed Sales</p><p class="text-2xl font-black mt-1 text-primary">৳ <?= number_format($sales) ?></p></div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="p-4 border-b font-bold">Recent Orders</div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-xs uppercase text-gray-500"><tr>
                        <th class="p-3 text-left">Order</th><th class="p-3 text-left">User</th><th class="p-3 text-left">Game</th><th class="p-3 text-left">Amount</th><th class="p-3 text-left">Status</th>
                    </tr></thead>
                    <tbody class="divide-y">
                    <?php if (!$recent): ?>
                        <tr><td colspan="5" class="p-8 text-center text-gray-400">No orders yet</td></tr>
                    <?php else: foreach ($recent as $o): ?>
                        <tr>
                            <td class="p-3 font-medium">#<?= htmlspecialchars($o['order_no']) ?></td>
                            <td class="p-3"><?= htmlspecialchars($o['user_name'] ?? '-') ?></td>
                            <td class="p-3"><?= htmlspecialchars($o['game_name'] ?? '-') ?></td>
                            <td class="p-3 font-bold text-accent">৳ <?= number_format((float)$o['total_amount'],2) ?></td>
                            <td class="p-3"><?= htmlspecialchars($o['status']) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/common/footer.php'; ?>
