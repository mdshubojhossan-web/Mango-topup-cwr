<?php
// icx/common/auth-check.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
$stmt = $pdo->prepare('SELECT id, status FROM admins WHERE id = ?');
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();
if (!$admin || ($admin['status'] ?? '') !== 'active') {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php?error=' . rawurlencode('Admin account is not active.'));
    exit();
}
?>
