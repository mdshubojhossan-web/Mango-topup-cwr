<?php
$currentPage = basename($_SERVER['PHP_SELF']);
function adnav($file,$icon,$label,$currentPage){
  $on = $currentPage===$file ? 'on' : '';
  echo '<a class="'.$on.'" href="'.$file.'"><i class="'.$icon.'"></i> '.$label.'</a>';
}
?>
<aside class="admin-side" id="adminSide">
  <a class="admin-brand" href="index.php"><i class="fa-solid fa-bolt"></i> <?= htmlspecialchars(siteName()) ?></a>
  <nav class="admin-nav">
    <p>MAIN</p>
    <?php
      adnav('index.php','fa-solid fa-chart-line','Dashboard',$currentPage);
      adnav('order.php','fa-solid fa-cart-shopping','Orders',$currentPage);
      adnav('category.php','fa-solid fa-layer-group','Categories',$currentPage);
      adnav('product.php','fa-solid fa-gamepad','Products',$currentPage);
      adnav('user.php','fa-solid fa-users','Users',$currentPage);
      adnav('wallet-requests.php','fa-solid fa-wallet','Wallet',$currentPage);
    ?>
    <p>CATALOG</p>
    <?php
      adnav('slider.php','fa-regular fa-images','Banners',$currentPage);
      adnav('coupon.php','fa-solid fa-percent','Coupons',$currentPage);
      adnav('redeem-code.php','fa-solid fa-ticket','Redeem codes',$currentPage);
      adnav('review.php','fa-solid fa-star','Reviews',$currentPage);
    ?>
    <p>SYSTEM</p>
    <?php
      adnav('site-settings.php','fa-solid fa-sliders','Site settings',$currentPage);
      adnav('payment-method.php','fa-solid fa-money-check-dollar','Payments',$currentPage);
      adnav('report.php','fa-solid fa-chart-pie','Reports',$currentPage);
      adnav('logs.php','fa-solid fa-clipboard-list','Activity logs',$currentPage);
    ?>
  </nav>
  <div class="admin-side-foot"><a href="logout.php"><i class="fa-solid fa-power-off"></i> Logout</a></div>
</aside>
<div class="admin-main">
<div class="admin-top">
  <div style="display:flex;align-items:center;gap:8px">
    <button class="menu-btn" type="button" onclick="toggleAdminMenu()"><i class="fa-solid fa-bars"></i></button>
    <h2>Admin panel</h2>
  </div>
  <div style="font-size:12px;font-weight:700;color:#64748b"><?= htmlspecialchars($_SESSION["admin_name"] ?? "Admin") ?></div>
</div>

