</div>
</div>
<script src="<?= defined('SITE_URL') ? SITE_URL : '..' ?>/assets/js/script.js"></script>
<script>
function toggleAdminMenu(force){
  const side=document.getElementById('adminSide');
  const ov=document.getElementById('adminOverlay');
  const open = force===undefined ? !side.classList.contains('open') : !!force;
  side.classList.toggle('open', open);
  ov.classList.toggle('show', open);
}
async function adminPost(data){
  const fd=new FormData();
  Object.entries(data).forEach(([k,v])=>fd.append(k,v));
  const res=await fetch('../ajax/admin-action.php',{method:'POST',body:fd});
  const raw=await res.text();
  let json; try{json=JSON.parse(raw)}catch(e){alert('Request failed');return}
  if(window.showToast) showToast(json.message||'Done', json.status==='success'?'success':'error');
  else alert(json.message||'Done');
  if(json.status==='success') setTimeout(()=>location.reload(),600);
}
function updateOrderStatus(orderId,status){ adminPost({action:'update_order_status',id:orderId,status}); }
</script>
</body></html>
