<?php
if (!isset($pdo)) require_once __DIR__ . '/../../common/config.php';
$siteName = siteName();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - <?= htmlspecialchars($siteName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/admin.css">
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config={theme:{extend:{colors:{primary:'#16a34a',accent:'#ff7a00',adminbg:'#f4f6fb',admindark:'#0f172a'}}}}</script>
</head>
<body class="admin-body">
<div class="admin-shell">
<div class="admin-overlay" id="adminOverlay" onclick="toggleAdminMenu(false)"></div>
