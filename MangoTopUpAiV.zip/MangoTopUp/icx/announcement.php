<?php
header('Location: site-settings.php#popup');
exit;
