<?php
// icx/slider.php
require_once __DIR__ . '/../common/config.php';
require_once __DIR__ . '/common/auth-check.php';
require_once __DIR__ . '/common/header.php';
require_once __DIR__ . '/common/sidebar.php';

// Fetch sliders
$sliders = $pdo->query("SELECT * FROM sliders ORDER BY sort_order ASC")->fetchAll();
?>

<div class="admin-page">
    
    <header class="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 border-b border-gray-200">
        <h2 class="text-xl font-bold text-gray-800"><i class="fa-regular fa-images text-primary mr-2"></i> Banners & Sliders</h2>
        <button class="bg-primary hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md transition flex items-center gap-2" onclick="document.getElementById('addSliderModal').classList.remove('hidden')">
            <i class="fa-solid fa-upload"></i> Upload Banner
        </button>
    </header>
    
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-adminbg p-6">
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php if(count($sliders) > 0): ?>
                <?php foreach($sliders as $s): ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden group">
                    <div class="h-32 bg-gray-100 overflow-hidden relative">
                        <img src="<?= htmlspecialchars($s['image']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        <?php if($s['status'] == 'inactive'): ?>
                            <div class="absolute inset-0 bg-black/50 flex items-center justify-center">
                                <span class="bg-red-500 text-white px-3 py-1 rounded text-xs font-bold">Hidden</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="p-4 flex justify-between items-center bg-gray-50 border-t border-gray-100">
                        <div class="text-xs text-gray-500 truncate mr-2 flex-1">
                            Link: <?= htmlspecialchars($s['link_url'] ?? 'None') ?>
                        </div>
                        <div class="flex gap-2">
                            <button onclick="adminPost({action:'toggle_slider',id:'<?= $s['id'] ?>'})" class="w-8 h-8 rounded bg-gray-200 text-gray-600 hover:bg-accent hover:text-white transition flex items-center justify-center">
                                <i class="fa-solid fa-eye-slash"></i>
                            </button>
                            <button onclick="adminPost({action:'delete_slider',id:'<?= $s['id'] ?>'})" class="w-8 h-8 rounded bg-red-100 text-red-600 hover:bg-red-500 hover:text-white transition flex items-center justify-center">
                                <i class="fa-solid fa-trash-can"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-span-full bg-white rounded-xl shadow-sm border border-gray-200 p-10 text-center text-gray-500">
                    <i class="fa-regular fa-image text-4xl mb-3 text-gray-300"></i>
                    <p>No banners found. Upload some promotional banners.</p>
                </div>
            <?php endif; ?>
        </div>

    </main>
</div>

<!-- Add Slider Modal -->
<div id="addSliderModal" class="fixed inset-0 bg-gray-900/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <h3 class="font-bold text-gray-800"><i class="fa-solid fa-upload text-primary mr-1"></i> Upload New Banner</h3>
            <button onclick="document.getElementById('addSliderModal').classList.add('hidden')" class="text-gray-400 hover:text-red-500 transition"><i class="fa-solid fa-xmark text-lg"></i></button>
        </div>
        <form action="../ajax/admin-action.php" method="POST" enctype="multipart/form-data" class="p-6">
            <input type="hidden" name="action" value="add_slider">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Upload Image (JPG/PNG)</label>
                <input type="file" name="image" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-white file:border-0 file:bg-gray-100 file:px-4 file:py-1 file:rounded file:text-xs file:font-bold file:text-gray-700 hover:file:bg-gray-200 cursor-pointer">
            </div>
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Or Image URL</label>
                <input type="url" name="image_url" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="https://...">
            </div>
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 mb-1">Target Link URL (Optional)</label>
                <input type="url" name="link_url" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary" placeholder="https://...">
            </div>
            
            <button type="submit" class="w-full bg-primary hover:bg-green-600 text-white font-bold py-2.5 rounded-lg shadow-md transition">
                Upload Banner
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/common/footer.php'; ?>

