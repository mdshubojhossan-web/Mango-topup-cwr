<?php
// search.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';

$searchQuery = isset($_GET['q']) ? sanitize($_GET['q']) : '';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40">
        <form action="search.php" method="GET" class="relative max-w-3xl mx-auto">
            <i class="fa-solid fa-search absolute left-4 top-3.5 text-gray-400"></i>
            <input type="text" name="q" value="<?= htmlspecialchars($searchQuery) ?>" placeholder="Search games, vouchers..." class="w-full bg-gray-100 border-transparent rounded-full pl-10 pr-4 py-3 text-sm focus:bg-white focus:border-primary focus:ring-1 focus:ring-primary transition outline-none">
        </form>
    </div>

    <main class="max-w-3xl mx-auto px-4 mt-6">
        
        <h2 class="text-sm font-bold text-gray-500 uppercase mb-4 tracking-wide flex items-center gap-2">
            <i class="fa-solid fa-poll-h"></i> Search Results
        </h2>
        
        <?php if($searchQuery): ?>
            <!-- Simulated DB Results -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                <?php
                $stmt = $pdo->prepare("SELECT * FROM games WHERE name LIKE ? AND status='active'");
                $stmt->execute(["%$searchQuery%"]);
                $results = $stmt->fetchAll();
                
                if(count($results) > 0):
                    foreach($results as $game):
                ?>
                <a href="game_detail.php?id=<?= $game['id'] ?>" class="bg-white p-2 rounded-xl shadow-soft border border-gray-100 block group text-center">
                    <div class="rounded-lg bg-gray-100 mb-2 overflow-hidden aspect-square">
                        <img src="<?= htmlspecialchars($game['thumbnail'] ?? 'https://via.placeholder.com/150') ?>" class="w-full h-full object-cover group-hover:scale-105 transition" alt="<?= htmlspecialchars($game['name']) ?>">
                    </div>
                    <h3 class="font-semibold text-gray-800 text-xs truncate mb-1"><?= htmlspecialchars($game['name']) ?></h3>
                </a>
                <?php 
                    endforeach;
                else: 
                ?>
                <div class="col-span-full text-center py-10 bg-white rounded-xl shadow-soft border border-gray-100">
                    <i class="fa-solid fa-magnifying-glass-minus text-4xl text-gray-300 mb-3"></i>
                    <p class="text-gray-500 font-medium text-sm">No games found for "<?= htmlspecialchars($searchQuery) ?>"</p>
                </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-10 bg-white rounded-xl shadow-soft border border-gray-100">
                <i class="fa-solid fa-keyboard text-4xl text-gray-300 mb-3"></i>
                <p class="text-gray-500 font-medium text-sm">Type something to search</p>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
require_once 'common/footer.php';
?>

