<?php
// privacy-policy.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">Privacy Policy</h1>
    </div>

    <main class="max-w-3xl mx-auto px-4 mt-6">
        <div class="bg-white rounded-xl shadow-soft p-6 border border-gray-100">
            <h2 class="text-xl font-black text-gray-900 mb-4 border-b border-gray-100 pb-3">Your Data Privacy</h2>
            <div class="text-sm text-gray-600 space-y-4 leading-relaxed">
                <p>Your privacy is important to us. This policy explains how we collect, use, and protect your personal information.</p>
                
                <h3 class="font-bold text-gray-800 text-base mt-4">Information Collection</h3>
                <p>We collect essential data such as your name, email, and phone number exclusively for order processing and account security.</p>
                
                <h3 class="font-bold text-gray-800 text-base mt-4">Data Protection</h3>
                <p>All passwords are encrypted. We do not store sensitive payment details like bKash PINs on our servers.</p>
            </div>
        </div>
    </main>
</div>

<?php require_once 'common/footer.php'; ?>
