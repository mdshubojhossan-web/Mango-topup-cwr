// assets/js/script.js

// Global Toast Notification Function
function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    // Using FontAwesome classes explicitly as requested (No Emoji)
    const icon = type === 'success' 
        ? '<i class="fa-solid fa-circle-check text-[#3FAE72] text-xl"></i>' 
        : '<i class="fa-solid fa-circle-exclamation text-red-500 text-xl"></i>';
    
    toast.innerHTML = `${icon} <span class="text-gray-800 font-bold text-sm flex-1">${message}</span>`;
    container.appendChild(toast);

    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Global AJAX Form Handler
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.ajax-form').forEach(form => {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            // A failed/blocked AJAX request must not make registration appear
            // broken. Native form submission is the reliable fallback.
            if (form.dataset.ajaxFallback === 'true') {
                form.submit();
                return;
            }
            
            const btn = form.querySelector('button[type="submit"]');
            const originalContent = btn.innerHTML;
            
            // Set loading state
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
            btn.disabled = true;
            btn.classList.add('opacity-75', 'cursor-not-allowed');

            try {
                const formData = new FormData(form);
                const response = await fetch(form.action, {
                    method: form.method || 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json'
                    }
                });
                const raw = await response.text();
                let res;
                try {
                    res = JSON.parse(raw);
                } catch(e) {
                    // Some hosting/security layers interfere with AJAX or
                    // return an HTML error page. Retry once as a normal POST.
                    form.dataset.ajaxFallback = 'true';
                    form.submit();
                    return;
                }
                if (!response.ok) {
                    throw new Error(res.message || `Request failed (${response.status})`);
                }
                showToast(res.message || 'Done', res.status === 'success' ? 'success' : 'error');
                
                if (res.status === 'success') {
                    if (form.dataset.reset === 'true') {
                        form.reset();
                    }
                    if (res.redirect) {
                        form.dataset.redirecting = "true";
                        setTimeout(() => {
                            window.location.href = res.redirect;
                        }, 1200);
                    }
                }
            } catch (error) {
                console.error("AJAX Error:", error);
                showToast('An unexpected error occurred! Please try again.', 'error');
            } finally {
                // Restore button state if not redirecting
                if (form.dataset.redirecting !== "true") {
                    btn.innerHTML = originalContent;
                    btn.disabled = false;
                    btn.classList.remove('opacity-75', 'cursor-not-allowed');
                }
            }
        });
    });
});
