// assets/js/security.js

(function() {
    'use strict';

    // 1. Disable Right Click (Context Menu)
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // 2. Disable Text Selection
    document.addEventListener('selectstart', function(e) {
        // Allow selection inside input fields and textareas only
        if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
        }
    });

    // 3. Disable Dragging of Images
    document.addEventListener('dragstart', function(e) {
        if (e.target.tagName === 'IMG') {
            e.preventDefault();
        }
    });

    // 4. Disable Common Developer Keyboard Shortcuts
    document.addEventListener('keydown', function(e) {
        // F12 key
        if (e.key === 'F12') {
            e.preventDefault();
        }
        
        // Ctrl+Shift+I (DevTools) / Ctrl+Shift+J (Console) / Ctrl+Shift+C (Inspector)
        if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) {
            e.preventDefault();
        }
        
        // Ctrl+U (View Source)
        if (e.ctrlKey && (e.key === 'U' || e.key === 'u')) {
            e.preventDefault();
        }

        // Ctrl+S (Save Page) / Ctrl+P (Print Page)
        if (e.ctrlKey && (e.key === 'S' || e.key === 's' || e.key === 'P' || e.key === 'p')) {
            e.preventDefault();
        }

        // 5. Disable Browser Zooming via Keyboard (Ctrl + '+', '-', '0')
        if (e.ctrlKey && (e.key === '=' || e.key === '-' || e.key === '0')) {
            e.preventDefault();
        }
    });

    // 6. Disable Scroll Zooming (Ctrl + Mouse Wheel)
    document.addEventListener('wheel', function(e) {
        if (e.ctrlKey) {
            e.preventDefault();
        }
    }, { passive: false });

})();

