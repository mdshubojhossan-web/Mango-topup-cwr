<?php
// leaderboard.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';

// Mock data for leaderboard
$topSpenders = [
    ['name' => 'Al Hasan', 'spent' => 25000, 'avatar' => 'A'],
    ['name' => 'Pro Gamer', 'spent' => 18500, 'avatar' => 'P'],
    ['name' => 'Ninja BD', 'spent' => 15200, 'avatar' => 'N'],
    ['name' => 'Riad Bhai', 'spent' => 12000, 'avatar' => 'R'],
    ['name' => 'Dark Lord', 'spent' => 9500, 'avatar' => 'D']
];
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 flex items-center justify-between shadow-sm sticky top-0 z-40">
        <div class="flex items-center gap-3">
            <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
            <h1 class="text-xl font-bold text-gray-900">Leaderboard</h1>
        </div>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <!-- Tabs -->
        <div class="flex bg-white rounded-xl shadow-sm border border-gray-100 p-1 mb-6">
            <button class="flex-1 py-2 text-xs font-bold rounded-lg bg-primary text-white shadow-sm">Weekly</button>
            <button class="flex-1 py-2 text-xs font-bold rounded-lg text-gray-500 hover:text-gray-900 transition">Monthly</button>
            <button class="flex-1 py-2 text-xs font-bold rounded-lg text-gray-500 hover:text-gray-900 transition">All Time</button>
        </div>

        <!-- Top 3 Podium -->
        <div class="flex justify-center items-end gap-2 mb-8 mt-10">
            <!-- Rank 2 -->
            <div class="flex flex-col items-center w-1/3 relative">
                <div class="w-12 h-12 rounded-full border-4 border-gray-300 bg-white flex items-center justify-center font-bold text-xl text-gray-700 shadow-md z-10 -mb-4">
                    <?= $topSpenders[1]['avatar'] ?>
                </div>
                <div class="bg-gray-200 w-full rounded-t-lg flex flex-col items-center justify-start pt-6 pb-2" style="height: 100px;">
                    <i class="fa-solid fa-medal text-gray-400 text-2xl mb-1"></i>
                    <span class="text-[10px] font-bold text-gray-700 truncate w-full text-center px-1"><?= $topSpenders[1]['name'] ?></span>
                    <span class="text-[10px] font-bold text-primary mt-auto">৳ <?= number_format($topSpenders[1]['spent']) ?></span>
                </div>
            </div>
            
            <!-- Rank 1 -->
            <div class="flex flex-col items-center w-1/3 relative">
                <div class="absolute -top-6 text-yellow-400 text-2xl drop-shadow-md z-20"><i class="fa-solid fa-crown"></i></div>
                <div class="w-16 h-16 rounded-full border-4 border-yellow-400 bg-white flex items-center justify-center font-bold text-2xl text-yellow-500 shadow-lg z-10 -mb-4">
                    <?= $topSpenders[0]['avatar'] ?>
                </div>
                <div class="bg-yellow-100 w-full rounded-t-lg flex flex-col items-center justify-start pt-6 pb-2 border-t border-yellow-200" style="height: 130px;">
                    <i class="fa-solid fa-trophy text-yellow-500 text-3xl mb-1 mt-2"></i>
                    <span class="text-xs font-black text-gray-800 truncate w-full text-center px-1"><?= $topSpenders[0]['name'] ?></span>
                    <span class="text-[11px] font-black text-accent mt-auto">৳ <?= number_format($topSpenders[0]['spent']) ?></span>
                </div>
            </div>

            <!-- Rank 3 -->
            <div class="flex flex-col items-center w-1/3 relative">
                <div class="w-12 h-12 rounded-full border-4 border-orange-300 bg-white flex items-center justify-center font-bold text-xl text-orange-700 shadow-md z-10 -mb-4">
                    <?= $topSpenders[2]['avatar'] ?>
                </div>
                <div class="bg-orange-50 w-full rounded-t-lg flex flex-col items-center justify-start pt-6 pb-2" style="height: 80px;">
                    <i class="fa-solid fa-award text-orange-400 text-2xl mb-1"></i>
                    <span class="text-[10px] font-bold text-gray-700 truncate w-full text-center px-1"><?= $topSpenders[2]['name'] ?></span>
                    <span class="text-[10px] font-bold text-primary mt-auto">৳ <?= number_format($topSpenders[2]['spent']) ?></span>
                </div>
            </div>
        </div>

        <!-- Rank List (4th onwards) -->
        <div class="bg-white rounded-xl shadow-soft border border-gray-100 overflow-hidden mb-6">
            <?php for($i = 3; $i < count($topSpenders); $i++): ?>
            <div class="flex items-center justify-between p-4 <?= $i < count($topSpenders)-1 ? 'border-b border-gray-50' : '' ?>">
                <div class="flex items-center gap-4">
                    <span class="font-bold text-gray-400 w-4 text-center"><?= $i+1 ?></span>
                    <div class="w-10 h-10 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center font-bold">
                        <?= $topSpenders[$i]['avatar'] ?>
                    </div>
                    <span class="font-bold text-gray-800 text-sm"><?= $topSpenders[$i]['name'] ?></span>
                </div>
                <div class="font-bold text-accent text-sm">৳ <?= number_format($topSpenders[$i]['spent']) ?></div>
            </div>
            <?php endfor; ?>
        </div>

    </main>
</div>

<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>

