<?php
// referral.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT referral_code FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

$refCode = $user['referral_code'];
if (empty($refCode)) {
    // Generate referral code if empty
    $refCode = strtoupper(substr($_SESSION['user_name'], 0, 3)) . rand(1000, 9999);
    $pdo->prepare("UPDATE users SET referral_code = ? WHERE id = ?")->execute([$refCode, $userId]);
}

$refLink = SITE_URL . "/register.php?ref=" . $refCode;
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <div class="bg-white px-4 py-4 flex items-center gap-3 shadow-sm sticky top-0 z-40">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">Refer & Earn</h1>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <div class="bg-gradient-to-br from-primary to-green-700 rounded-2xl p-6 text-center text-white shadow-md relative overflow-hidden mb-6">
            <div class="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
            <i class="fa-solid fa-gift text-5xl text-white/90 mb-3 drop-shadow-md"></i>
            <h2 class="text-xl font-black mb-1 tracking-wide">Invite Friends</h2>
            <p class="text-xs text-white/80 font-medium">Earn bonus balance for every successful referral.</p>
        </div>

        <div class="bg-white rounded-xl shadow-soft p-5 border border-gray-100 mb-6 text-center">
            <h3 class="text-sm font-bold text-gray-600 uppercase tracking-widest mb-4">Your Referral Code</h3>
            
            <div class="border-2 border-dashed border-accent bg-orange-50 rounded-xl p-4 flex items-center justify-between mb-4">
                <span class="font-mono text-2xl font-black text-gray-800 tracking-wider"><?= htmlspecialchars($refCode) ?></span>
                <button onclick="navigator.clipboard.writeText('<?= $refCode ?>'); showToast('Code Copied!');" class="w-10 h-10 bg-accent text-white rounded-lg shadow-sm flex items-center justify-center hover:bg-orange-600 transition">
                    <i class="fa-regular fa-copy"></i>
                </button>
            </div>

            <p class="text-xs text-gray-500 mb-2">Share your referral link directly</p>
            <div class="flex gap-2">
                <input type="text" value="<?= $refLink ?>" readonly class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs text-gray-600 outline-none">
                <button onclick="navigator.clipboard.writeText('<?= $refLink ?>'); showToast('Link Copied!');" class="bg-gray-800 text-white px-4 rounded-lg text-xs font-bold hover:bg-gray-900 transition">Copy</button>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div class="bg-white rounded-xl shadow-soft p-4 border border-gray-100 text-center">
                <div class="w-10 h-10 mx-auto bg-green-50 text-primary rounded-full flex items-center justify-center mb-2"><i class="fa-solid fa-users"></i></div>
                <h4 class="text-2xl font-black text-gray-800">0</h4>
                <p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">Total Referrals</p>
            </div>
            <div class="bg-white rounded-xl shadow-soft p-4 border border-gray-100 text-center">
                <div class="w-10 h-10 mx-auto bg-orange-50 text-accent rounded-full flex items-center justify-center mb-2"><i class="fa-solid fa-coins"></i></div>
                <h4 class="text-2xl font-black text-gray-800">৳ 0</h4>
                <p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">Total Earned</p>
            </div>
        </div>

    </main>
</div>

<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>

