<?php
// refund-policy.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">Refund Policy</h1>
    </div>

    <main class="max-w-3xl mx-auto px-4 mt-6">
        <div class="bg-white rounded-xl shadow-soft p-6 border border-gray-100">
            <h2 class="text-xl font-black text-gray-900 mb-4 border-b border-gray-100 pb-3">Refund & Return Rules</h2>
            <div class="text-sm text-gray-600 space-y-4 leading-relaxed">
                <p>We strive to deliver all orders instantly. However, if an issue arises, the following refund conditions apply:</p>
                <ul class="list-disc ml-5 space-y-2">
                    <li>If a product is out of stock after payment, the amount will be refunded to your site Wallet.</li>
                    <li>No refunds are provided if the user enters an incorrect Player ID.</li>
                    <li>Digital voucher codes cannot be returned or refunded once delivered.</li>
                </ul>
            </div>
        </div>
    </main>
</div>
<?php require_once 'common/footer.php'; ?>

