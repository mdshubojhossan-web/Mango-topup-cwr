<?php
// terms.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">Terms & Conditions</h1>
    </div>

    <main class="max-w-3xl mx-auto px-4 mt-6">
        <div class="bg-white rounded-xl shadow-soft p-6 border border-gray-100">
            <h2 class="text-xl font-black text-gray-900 mb-4 border-b border-gray-100 pb-3">Agreement of Use</h2>
            <div class="text-sm text-gray-600 space-y-4 leading-relaxed">
                <p>By using <?= htmlspecialchars(siteName()) ?>, you agree to these terms and conditions. Please read them carefully before making any purchase.</p>
                
                <h3 class="font-bold text-gray-800 text-base mt-4">Account Responsibilities</h3>
                <p>You are responsible for maintaining the confidentiality of your account credentials. Any activity under your account is your sole responsibility.</p>
                
                <h3 class="font-bold text-gray-800 text-base mt-4">Order & Delivery</h3>
                <p>Ensure that you provide the correct Player ID. We are not responsible for top-ups sent to the wrong ID due to user error.</p>
            </div>
        </div>
    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
require_once 'common/footer.php';
?>

