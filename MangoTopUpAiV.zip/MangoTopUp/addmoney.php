<?php
// addmoney.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <!-- Header -->
    <div class="bg-white px-4 py-4 shadow-sm flex items-center sticky top-0 z-40">
        <h1 class="text-xl font-bold text-gray-900">Add Money</h1>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <!-- Add Money Form -->
        <form action="<?= SITE_URL ?>/instantpay.php" method="GET" class="mb-6">
            <input type="hidden" name="action" value="add_balance">
            
            <div class="mb-4">
                <label class="block text-sm font-bold text-gray-700 mb-2">Enter the amount</label>
                <input type="number" name="amount" min="10" required class="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition bg-white" placeholder="Amount">
            </div>
            
            <button type="submit" class="w-full bg-accent hover:bg-orange-600 text-white font-bold py-3 rounded-lg shadow-md transition">
                Click Here To Add Money
            </button>
        </form>

        <!-- Instruction Section -->
        <div class="bg-white rounded-xl shadow-soft border border-gray-100 overflow-hidden mb-6">
            <div class="px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                <i class="fa-solid fa-desktop text-gray-300 text-lg opacity-70"></i>
                <h3 class="font-bold text-gray-800">How to add money</h3>
            </div>
            <div class="p-4">
                <!-- Placeholder for Video/Image -->
                <div class="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center border border-gray-300 relative overflow-hidden group cursor-pointer hover:bg-gray-300 transition">
                    <i class="fa-regular fa-image text-5xl text-gray-400"></i>
                    <div class="absolute inset-0 bg-black/5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                        <i class="fa-brands fa-youtube text-4xl text-red-500"></i>
                    </div>
                </div>
            </div>
        </div>

    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
require_once 'common/footer.php';
?>

