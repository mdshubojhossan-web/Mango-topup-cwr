<?php
// profile.php
require_once 'common/config.php';
require_once 'common/auth-check.php'; // Ensure user is logged in
require_once 'common/header.php';

// Mock user data (In real project, fetch from $_SESSION or DB)
$userName = $_SESSION['user_name'] ?? 'Infinity';
$firstLetter = strtoupper(substr($userName, 0, 1));
$walletBalance = $_SESSION['user_balance'] ?? 0.00;
$supportPin = $_SESSION['support_pin'] ?? '618674';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <!-- Top Header / Topup & Nav (Similar to screenshot 9) -->
    <div class="bg-white px-4 py-3 flex justify-between items-center shadow-sm sticky top-0 z-40">
        <a href="index.php" class="flex items-center gap-2 font-bold text-gray-900">
            <div class="bg-bg p-1 rounded-full"><i class="fa-solid fa-bolt text-accent"></i></div>
            <?= htmlspecialchars(siteName()) ?>
        </a>
        <div class="flex items-center gap-2">
            <div class="bg-orange-100 text-accent font-bold px-3 py-1 rounded-full text-xs flex items-center gap-1">
                <i class="fa-solid fa-wallet"></i> ৳ <?= number_format($walletBalance, 0) ?>
            </div>
            <div class="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-sm">
                <?= $firstLetter ?>
            </div>
        </div>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <!-- Profile Info -->
        <div class="flex flex-col items-center mb-6">
            <div class="relative w-20 h-20 rounded-full bg-purple-500 border-4 border-white shadow-soft flex items-center justify-center text-white text-3xl font-bold mb-2">
                <?= $firstLetter ?>
                <div class="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
            </div>
            <div class="flex items-center gap-2 mb-1">
                <h1 class="text-2xl font-bold text-gray-900"><?= htmlspecialchars($userName) ?></h1>
                <span class="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <div class="w-1.5 h-1.5 bg-green-500 rounded-full"></div> Verified
                </span>
            </div>
            <div class="flex items-center gap-3 text-xs text-gray-500 font-medium">
                <span><i class="fa-solid fa-shield-halved mr-1"></i> Support PIN: <?= $supportPin ?></span>
                <span><i class="fa-solid fa-star mr-1"></i> Verified Account</span>
            </div>
        </div>

        <!-- Rank Card (Small) -->
        <div class="bg-white rounded-xl shadow-soft p-4 flex items-center gap-4 mb-4 border border-gray-100">
            <div class="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center border border-orange-100 text-accent text-xl">
                <i class="fa-solid fa-shield-cat"></i>
            </div>
            <div>
                <h3 class="font-bold text-gray-800 text-sm">Bronze Member</h3>
                <p class="text-xs text-gray-500">Level 1 / Current Rank</p>
            </div>
        </div>

        <!-- Wallet Card -->
        <div class="bg-white rounded-xl shadow-soft p-5 mb-6 border border-gray-100 relative overflow-hidden">
            <!-- Decorative gradient blur -->
            <div class="absolute -right-6 -top-6 w-24 h-24 bg-blue-50 rounded-full blur-2xl"></div>
            
            <div class="flex justify-between items-start mb-2 relative z-10">
                <h3 class="text-xs font-bold text-gray-500 uppercase tracking-wide">Wallet Balance</h3>
                <button class="text-gray-400 hover:text-accent transition"><i class="fa-solid fa-rotate-right"></i></button>
            </div>
            <div class="text-3xl font-bold text-gray-900 mb-4 relative z-10">
                Tk <?= number_format($walletBalance, 0) ?>
            </div>
            
            <a href="addmoney.php" class="block w-full bg-primary hover:bg-green-600 text-white text-center font-bold py-3 rounded-lg shadow-sm transition relative z-10">
                Add Money
            </a>
        </div>

        <!-- Large Bronze Rank Display -->
        <div class="bg-gradient-to-br from-[#8B5A2B] to-[#CD7F32] rounded-xl shadow-md p-6 text-center text-white relative overflow-hidden mb-6">
            <div class="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mt-10 -mr-10"></div>
            <h4 class="text-[10px] font-bold uppercase tracking-widest text-white/80 mb-4 relative z-10">Current Rank</h4>
            <div class="inline-block relative mb-2">
                <div class="w-20 h-24 flex items-center justify-center border-4 border-white/20 rounded-lg bg-white/10 mx-auto relative z-10 backdrop-blur-sm">
                    <i class="fa-solid fa-shield-cat text-4xl text-white"></i>
                </div>
                <div class="absolute top-4 -right-8 w-1 h-16 bg-white/30 transform rotate-45 blur-[1px]"></div>
            </div>
            <p class="text-xs font-medium text-white/90 relative z-10 mt-2">Level 1</p>
            <h2 class="text-3xl font-black uppercase tracking-wide relative z-10 mt-1 shadow-black">Bronze</h2>
        </div>

        <!-- Logout Form -->
        <form action="logout.php" method="POST" class="mb-4">
            <button type="submit" class="w-full bg-red-50 text-red-600 hover:bg-red-100 font-bold py-3 rounded-xl transition border border-red-100 flex justify-center items-center gap-2">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </button>
        </form>

    </main>
</div>

<?php
require_once 'common/bottom-nav.php';
?>
<script src="<?= SITE_URL ?>/assets/js/security.js"></script>
<script src="<?= SITE_URL ?>/assets/js/script.js"></script>
</body>
</html>

