<?php
// Mango TopUp portable installer. This build uses the bundled JSON MiniPDO datastore.
$root = __DIR__;
$dataDir = $root . '/data';
$dbFile = $dataDir . '/db.json';
$lockFile = $dataDir . '/.installed';
$message = '';
$error = '';

function h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = trim((string)($_POST['site_name'] ?? 'Mango TopUp')) ?: 'Mango TopUp';
    $adminName = trim((string)($_POST['admin_name'] ?? 'Super Admin')) ?: 'Super Admin';
    $adminEmail = strtolower(trim((string)($_POST['admin_email'] ?? '')));
    $adminPassword = (string)($_POST['admin_password'] ?? '');
    $apiUrl = trim((string)($_POST['player_name_api_url'] ?? 'http://ixbd.qd.je/ff.php?uid={uid}'));

    if (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) $error = 'Enter a valid admin email.';
    elseif (strlen($adminPassword) < 8) $error = 'Admin password must be at least 8 characters.';
    elseif (!preg_match('#^https?://#i', $apiUrl)) $error = 'Player-name API URL must start with http:// or https://.';
    elseif (!is_dir($dataDir) && !@mkdir($dataDir, 0755, true)) $error = 'The data folder could not be created.';
    elseif (!is_writable($dataDir)) $error = 'The data folder must be writable during installation.';
    else {
        $data = [];
        if (is_file($dbFile)) $data = json_decode((string)@file_get_contents($dbFile), true) ?: [];
        if (!$data) $data = require $root . '/common/default-data.php';
        $data['site_settings'] = $data['site_settings'] ?? [];
        $found = false;
        foreach ($data['site_settings'] as &$setting) {
            if (($setting['key_name'] ?? '') === 'site_name') { $setting['value'] = $siteName; $found = true; }
            if (($setting['key_name'] ?? '') === 'player_name_api_url') { $setting['value'] = $apiUrl; }
        }
        unset($setting);
        if (!$found) $data['site_settings'][] = ['key_name'=>'site_name','value'=>$siteName];
        $hasApi = false;
        foreach ($data['site_settings'] as $setting) if (($setting['key_name'] ?? '') === 'player_name_api_url') $hasApi = true;
        if (!$hasApi) $data['site_settings'][] = ['key_name'=>'player_name_api_url','value'=>$apiUrl];
        $admin = ['id'=>1,'name'=>$adminName,'email'=>$adminEmail,'password'=>password_hash($adminPassword, PASSWORD_DEFAULT),'status'=>'active','created_at'=>date('Y-m-d H:i:s')];
        $data['admins'] = [$admin];
        if (@file_put_contents($dbFile, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX) === false) {
            $error = 'Could not write data/db.json. Check folder permissions.';
        } else {
            @chmod($dbFile, 0600);
            @file_put_contents($lockFile, date('c'));
            $message = 'Installation completed. Delete install.php after confirming the site works.';
        }
    }
}
$installed = is_file($lockFile) || is_file($dbFile);
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mango TopUp Installer</title>
<style>body{margin:0;background:#f3f6fb;font-family:Arial,sans-serif;color:#172033}.wrap{max-width:560px;margin:40px auto;padding:20px}.card{background:#fff;border-radius:16px;padding:26px;box-shadow:0 10px 30px #17203318}h1{margin:0 0 8px;color:#f47b20}p{color:#64748b;font-size:14px;line-height:1.5}.notice{padding:12px;border-radius:8px;margin:14px 0;background:#ecfdf5;color:#166534}.error{padding:12px;border-radius:8px;margin:14px 0;background:#fef2f2;color:#991b1b}.info{padding:12px;border-radius:8px;margin:14px 0;background:#fff7ed;color:#9a3412;font-size:13px;line-height:1.5}label{display:block;font-weight:700;font-size:13px;margin:14px 0 6px}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #d6deea;border-radius:8px;font-size:14px}button{margin-top:20px;width:100%;padding:13px;border:0;border-radius:8px;background:#f47b20;color:#fff;font-weight:700;font-size:15px;cursor:pointer}.small{font-size:12px;color:#64748b}</style></head>
<body><main class="wrap"><section class="card"><h1>Mango TopUp Installer</h1><p>Set the site and admin details, then click Install.</p>
<div class="info"><b>Storage note:</b> This ZIP uses the bundled PHP JSON MiniPDO datastore, so MySQL is not required for this build. It is suitable for free hosting with PHP 8+ and a writable <code>data/</code> folder. The MySQL fields from older documentation are not used by this runtime.</div>
<?php if ($message): ?><div class="notice"><?= h($message) ?><br><a href="index.php">Open website</a> · <a href="icx/login.php">Open admin</a></div><?php endif; ?>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<form method="post">
<label>Site name</label><input name="site_name" value="<?= h($_POST['site_name'] ?? 'Mango TopUp') ?>" required>
<label>Admin name</label><input name="admin_name" value="<?= h($_POST['admin_name'] ?? 'Super Admin') ?>" required>
<label>Admin email</label><input type="email" name="admin_email" value="<?= h($_POST['admin_email'] ?? 'admin@mangotopup.com') ?>" required>
<label>Admin password</label><input type="password" name="admin_password" minlength="8" required><div class="small">At least 8 characters.</div>
<label>Free Fire player-name API URL</label><input name="player_name_api_url" value="<?= h($_POST['player_name_api_url'] ?? 'http://ixbd.qd.je/ff.php?uid={uid}') ?>" required><div class="small">Use {uid} where the player ID should be inserted.</div>
<button type="submit">Install Mango TopUp</button>
</form>
<?php if ($installed): ?><p class="small">A previous data file exists. Installing again will replace the admin account and preserve the catalog/data.</p><?php endif; ?>
</section></main></body></html>
