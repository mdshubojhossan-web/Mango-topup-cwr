# Mango TopUp — PHP free-hosting build

Mango TopUp is a PHP 8+ game top-up store with customer checkout and an admin panel.

## Install on free hosting

1. Upload and extract the ZIP into `public_html` (or the hosting document root).
2. Make sure PHP **8.0+** is enabled.
3. Make the `data/` folder writable during installation.
4. Open `/install.php` in your browser.
5. Enter the site name, admin email/password, and player-name API URL.
6. Click **Install Mango TopUp**.
7. After installation, delete `install.php` from the hosting account.

The default player-name API is:

```text
http://ixbd.qd.je/ff.php?uid={uid}
```

The `{uid}` placeholder is replaced by the submitted Free Fire UID. The response `data.username` is shown on the **Check Player Name** button.

## Login after installation

- Admin URL: `/icx/login.php`
- The admin email and password are the values entered in `install.php`.

## Storage requirement

This final build uses the bundled **PHP JSON MiniPDO** datastore in `data/db.json`. It does not require MySQL or a separate database server. The supplied `database.sql` is retained for reference, but this runtime does not use MySQL tables.

If your hosting plan only supports MySQL and does not provide writable PHP storage, this exact build is not the correct runtime; it would require a separate MySQL migration.

## Security

- `data/` and internal PHP directories are blocked by `.htaccess` on Apache.
- Delete `install.php` after setup.
- Use a strong admin password.
- Keep `data/db.json` writable only by the web process where possible.
