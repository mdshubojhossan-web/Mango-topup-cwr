<?php
require_once 'common/config.php';
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}
$pageTitle = 'Login | ' . siteName();
require_once 'common/header.php';
require_once 'common/navbar.php';
$logo = getSetting($pdo, 'site_logo', '');
?>
<div class="min-h-screen bg-gradient-to-b from-orange-50 to-white pb-24">
    <main class="max-w-6xl mx-auto px-4 py-8 md:py-16 grid md:grid-cols-2 gap-10 items-center">
        <div class="hidden md:block">
            <span class="text-[11px] font-bold text-accent uppercase tracking-widest flex items-center gap-2 mb-3">
                <span class="w-1.5 h-1.5 bg-accent rounded-full"></span> Secure Account Access
            </span>
            <h1 class="text-5xl font-black text-gray-900 leading-tight">Welcome<br><span class="text-accent">Back</span></h1>
            <p class="text-sm text-gray-500 mt-4 max-w-sm">Fast, secure and simple access to your account.</p>
            <div class="relative mt-10 w-40 h-56">
                <div class="absolute inset-0 bg-orange-100 rounded-full blur-3xl"></div>
                <div class="relative w-28 h-48 bg-white rounded-[2rem] border-4 border-orange-100 shadow-xl flex flex-col justify-between p-3 rotate-12">
                    <div class="w-8 h-1 bg-gray-200 rounded-full mx-auto"></div>
                    <div class="text-center text-orange-200 text-4xl"><i class="fa-regular fa-user"></i></div>
                    <div class="w-4 h-4 border-2 border-gray-200 rounded-full mx-auto mb-1"></div>
                </div>
                <div class="absolute right-2 top-2 w-8 h-8 bg-white rounded-lg shadow border flex items-center justify-center text-accent"><i class="fa-solid fa-lock"></i></div>
                <div class="absolute left-0 bottom-8 w-8 h-8 bg-white rounded-lg shadow border flex items-center justify-center text-primary"><i class="fa-solid fa-shield-halved"></i></div>
            </div>
        </div>

        <div class="bg-white p-5 md:p-7 rounded-2xl shadow-soft border border-orange-100/80">
            <div class="md:hidden mb-6">
                <span class="text-[10px] font-bold text-accent uppercase tracking-widest">Secure Account Access</span>
                <h1 class="text-4xl font-black text-gray-900">Welcome<br><span class="text-accent">Back</span></h1>
            </div>
            <div class="flex items-center gap-3 bg-orange-50 text-accent p-3 rounded-xl mb-4 border border-orange-100">
                <div class="w-9 h-9 bg-accent text-white rounded-lg flex items-center justify-center"><i class="fa-solid fa-user-shield"></i></div>
                <div>
                    <p class="text-sm font-bold text-gray-900">Sign in to continue</p>
                    <p class="text-[11px] text-gray-500">Access your account securely</p>
                </div>
            </div>
            <button type="button" class="w-full bg-white border border-gray-200 hover:border-gray-300 text-gray-700 font-medium py-3 px-4 rounded-xl flex items-center justify-between mb-5">
                <span class="flex items-center gap-3">
                    <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" class="w-5 h-5" alt="">
                    <span class="text-sm text-left">Continue with Google<br><span class="text-[10px] text-gray-400 font-normal">Quick and secure sign in</span></span>
                </span>
                <i class="fa-solid fa-arrow-right text-accent"></i>
            </button>
            <div class="flex items-center gap-3 mb-5">
                <div class="h-px bg-gray-200 flex-1"></div>
                <span class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Or continue with email</span>
                <div class="h-px bg-gray-200 flex-1"></div>
            </div>
            <form action="ajax/auth.php" method="POST" class="ajax-form">
                <input type="hidden" name="action" value="login">
                <label class="block text-xs font-bold text-gray-700 mb-1">Email address</label>
                <div class="relative mb-4">
                    <i class="fa-regular fa-envelope absolute left-4 top-3.5 text-gray-400"></i>
                    <input type="email" name="email" required class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-accent" placeholder="Enter your email">
                </div>
                <label class="block text-xs font-bold text-gray-700 mb-1">Password</label>
                <div class="relative mb-5">
                    <i class="fa-solid fa-lock absolute left-4 top-3.5 text-gray-400"></i>
                    <input type="password" name="password" required class="w-full pl-10 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-accent" placeholder="Enter your password">
                </div>
                <button type="submit" class="w-full bg-accent hover:bg-orange-600 text-white font-bold py-3.5 rounded-xl shadow-md flex items-center justify-center gap-2">
                    <i class="fa-solid fa-arrow-right-to-bracket"></i> Sign In
                </button>
            </form>
            <div class="grid grid-cols-3 gap-2 mt-6 text-center">
                <div><div class="w-10 h-10 mx-auto bg-yellow-50 rounded-full flex items-center justify-center text-yellow-500 mb-1"><i class="fa-solid fa-bolt"></i></div><p class="text-xs font-bold">Fast</p><p class="text-[10px] text-gray-400">Instant access</p></div>
                <div><div class="w-10 h-10 mx-auto bg-green-50 rounded-full flex items-center justify-center text-primary mb-1"><i class="fa-solid fa-check"></i></div><p class="text-xs font-bold">Secure</p><p class="text-[10px] text-gray-400">Safe login</p></div>
                <div><div class="w-10 h-10 mx-auto bg-orange-50 rounded-full flex items-center justify-center text-accent mb-1"><i class="fa-solid fa-heart"></i></div><p class="text-xs font-bold">Trusted</p><p class="text-[10px] text-gray-400">Easy & reliable</p></div>
            </div>
            <p class="text-center text-xs text-gray-500 mt-5">New here? <a href="register.php" class="text-accent font-bold">Create an account</a></p>
        </div>
    </main>
</div>
<?php require_once 'common/bottom-nav.php'; ?>
<script src="<?= SITE_URL ?>/assets/js/security.js"></script>
<script src="<?= SITE_URL ?>/assets/js/script.js"></script>
</body></html>
