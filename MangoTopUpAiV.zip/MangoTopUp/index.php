<?php
require_once 'common/config.php';
$pageTitle = siteName() . ' - Games TopUp in Bangladesh - Fast, Safe & Reliable';
require_once 'common/header.php';
require_once 'common/navbar.php';

$notice = getSetting($pdo, 'notice_text');
$popupStatus = getSetting($pdo, 'popup_status', 'inactive');
$sliders = $pdo->query("SELECT * FROM sliders WHERE status='active' ORDER BY sort_order ASC")->fetchAll();
$catRows = $pdo->query("SELECT * FROM categories WHERE status='active' ORDER BY sort_order ASC")->fetchAll();
$sections = [];
foreach ($catRows as $cr) $sections[] = [$cr['slug'], $cr['name']];
if (!$sections) {
    $sections = [
        ['flash', 'FLASH SALE'],
        ['hot', 'HOT PRODUCT'],
        ['pes', 'All PES Football™'],
        ['others', 'Others'],
        ['subscription', 'Others Subscription'],
    ];
}
function game_card($game) {
    $id = (int)$game['id'];
    $name = htmlspecialchars($game['name']);
    $thumb = htmlspecialchars($game['thumbnail'] ?? '');
    return <<<HTML
    <a href="game_detail.php?id={$id}" class="product-card fade-up bg-white rounded-xl shadow-soft border border-gray-100 block group overflow-hidden">
        <div class="bg-gray-50 overflow-hidden aspect-square">
            <img src="{$thumb}" class="w-full h-full object-cover group-hover:scale-110 transition duration-500" alt="{$name}" loading="lazy">
        </div>
        <h3 class="font-semibold text-gray-700 text-[10px] leading-tight text-center px-1.5 py-1.5 min-h-[34px] line-clamp-2">{$name}</h3>
    </a>
HTML;
}
?>
<style>
.mango-wrap{max-width:430px;margin:0 auto;padding:0 12px 110px}
.mango-notice{display:flex;align-items:center;background:#fff;border:1px solid #f0d9c2;border-radius:999px;overflow:hidden;margin-top:12px;height:42px}
.mango-notice-tag{background:#f08a1c;color:#fff;font-size:11px;font-weight:800;letter-spacing:.6px;display:flex;align-items:center;gap:6px;padding:0 12px;height:42px;flex:0 0 auto}
.mango-notice-dot{width:10px;height:10px;border:2px solid #fff;border-radius:50%;display:inline-block}
.mango-notice-text{flex:1;overflow:hidden;white-space:nowrap;color:#222;font-size:12px;font-weight:500}
.mango-notice-x{width:26px;height:26px;border-radius:50%;background:#f08a1c;color:#fff;border:0;margin:0 8px 0 6px;display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.mango-hero{margin-top:10px;border-radius:18px;overflow:hidden;background:#111;position:relative}
.slider-viewport{overflow:hidden;width:100%}
.slider-track{display:flex;transition:transform .55s cubic-bezier(.22,.61,.36,1);will-change:transform}
.slider-track a{min-width:100%;flex:0 0 100%;display:block}
.slider-track img{width:100%;height:190px;object-fit:cover;display:block}
.mango-dots{display:flex;justify-content:center;gap:6px;margin:8px 0 12px}
.mango-dots i{display:block;height:4px;border-radius:99px;background:#d4d4d4}
.mango-dots i.on{width:18px;background:#4b5563}
.mango-dots i.off{width:10px}
.mango-links{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.mango-link{background:#f08a1c;color:#fff;border-radius:16px;padding:8px 8px;display:flex;align-items:center;gap:8px;text-decoration:none;min-height:54px}
.mango-link .ic{width:30px;height:30px;border-radius:50%;background:#fff;color:#f08a1c;display:flex;align-items:center;justify-content:center;font-size:15px;flex:0 0 auto}
.mango-link .tx small{display:block;font-size:9px;font-weight:700;letter-spacing:.3px;line-height:1;opacity:.95;margin-bottom:2px}
.mango-link .tx b{display:block;font-size:12px;font-weight:800;line-height:1.1}
</style>
<main class="mango-wrap">
    <?php if ($notice): ?>
    <div id="noticeBar" class="mango-notice">
        <span class="mango-notice-tag"><span class="mango-notice-dot"></span>NOTICE</span>
        <div class="mango-notice-text"><span class="animate-marquee"><?= htmlspecialchars($notice) ?></span></div>
        <button type="button" class="mango-notice-x" onclick="document.getElementById('noticeBar').remove()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <?php endif; ?>

    <section class="mango-hero">
        <div class="slider-viewport">
            <div class="slider-track" id="sliderTrack">
                <?php foreach ($sliders as $s): ?>
                <a href="<?= htmlspecialchars($s['link_url'] ?: '#') ?>">
                    <img src="<?= htmlspecialchars($s['image']) ?>" alt="Banner">
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <div class="mango-dots">
        <?php foreach ($sliders as $i => $s): ?>
            <i class="hero-dot <?= $i===0 ? 'on' : 'off' ?>"></i>
        <?php endforeach; ?>
    </div>

    <section class="mango-links">
        <a class="mango-link" href="<?= htmlspecialchars(getSetting($pdo,'support_telegram','#')) ?>">
            <span class="ic"><i class="fa-brands fa-telegram"></i></span>
            <span class="tx"><small>SUPPORT</small><b>Telegram</b></span>
        </a>
        <a class="mango-link" href="<?= htmlspecialchars(getSetting($pdo,'social_group','#')) ?>">
            <span class="ic"><i class="fa-solid fa-user-group"></i></span>
            <span class="tx"><small>GROUP</small><b>Join Group</b></span>
        </a>
        <a class="mango-link" href="<?= htmlspecialchars(getSetting($pdo,'social_facebook','#')) ?>">
            <span class="ic"><i class="fa-brands fa-facebook-f"></i></span>
            <span class="tx"><small>PAGE</small><b>Facebook</b></span>
        </a>
        <a class="mango-link" href="<?= htmlspecialchars(getSetting($pdo,'support_whatsapp','#')) ?>">
            <span class="ic"><i class="fa-brands fa-whatsapp"></i></span>
            <span class="tx"><small>CHAT</small><b>WhatsApp</b></span>
        </a>
    </section>

    <?php foreach ($sections as $sec):
        $list = $pdo->query("SELECT * FROM games WHERE status='active' AND category='{$sec[0]}' ORDER BY sort_order ASC")->fetchAll();
        if (!$list) continue;
    ?>
    <section class="mt-6 px-3">
        <h2 class="text-center text-[18px] font-black tracking-wide text-slate-600 mb-3"><?= $sec[1] ?></h2>
        <div class="grid grid-cols-3 gap-2">
            <?php foreach ($list as $g) echo game_card($g); ?>
        </div>
    </section>
    <?php endforeach; ?>
</main>

<?php if ($popupStatus === 'active'): ?>
<div id="promoPopup" class="popup-overlay fixed inset-0 bg-black/55 z-[80] flex items-center justify-center p-4">
    <div class="popup-box relative max-w-sm w-full">
        <div class="bg-white rounded-2xl overflow-hidden shadow-2xl">
            <?php if (getSetting($pdo,'popup_image')): ?>
            <a href="<?= htmlspecialchars(getSetting($pdo,'popup_link','#')) ?>">
                <img src="<?= htmlspecialchars(getSetting($pdo,'popup_image')) ?>" class="w-full object-cover" alt="Offer">
            </a>
            <?php endif; ?>
            <div class="p-4 text-center">
                <p class="font-bold text-gray-900"><?= htmlspecialchars(getSetting($pdo,'popup_title')) ?></p>
                <p class="text-xs text-gray-600 mt-1 leading-relaxed"><?= nl2br(htmlspecialchars(getSetting($pdo,'popup_message'))) ?></p>
                <a href="<?= htmlspecialchars(getSetting($pdo,'popup_link','#')) ?>" class="mt-3 inline-block bg-accent hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-full text-sm"><?= htmlspecialchars(getSetting($pdo,'popup_btn','Click now')) ?></a>
            </div>
        </div>
        <div class="flex justify-center mt-3">
            <button type="button" onclick="document.getElementById('promoPopup').remove()" class="popup-close w-9 h-9 rounded-full bg-white text-gray-800 shadow-lg flex items-center justify-center">
                <i class="fa-solid fa-xmark text-sm"></i>
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
const track = document.getElementById('sliderTrack');
const dots = document.querySelectorAll('.hero-dot');
const total = track ? track.children.length : 0;
let si = 0;
function goSlide(n){
    if (!track || !total) return;
    si = (n + total) % total;
    track.style.transform = 'translateX(' + (-si * 100) + '%)';
    dots.forEach((d,i)=> d.className = 'hero-dot ' + (i===si ? 'on' : 'off'));
}
setInterval(()=> goSlide(si+1), 4000);
let startX = 0;
if (track) {
    track.addEventListener('touchstart', e => startX = e.touches[0].clientX, {passive:true});
    track.addEventListener('touchend', e => {
        const dx = e.changedTouches[0].clientX - startX;
        if (dx > 40) goSlide(si-1);
        if (dx < -40) goSlide(si+1);
    });
}
</script>
<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>
