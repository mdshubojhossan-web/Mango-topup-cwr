<?php
// delete-account.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">Delete Account</h1>
    </div>

    <main class="max-w-3xl mx-auto px-4 mt-6">
        <div class="bg-white rounded-xl shadow-soft p-6 border border-gray-100 text-center">
            <i class="fa-solid fa-user-xmark text-4xl text-red-500 mb-4"></i>
            <h2 class="text-xl font-black text-gray-900 mb-2">Request Account Deletion</h2>
            <p class="text-sm text-gray-600 mb-6">If you wish to permanently delete your account and all associated data, please contact our support team. This action cannot be undone.</p>
            
            <a href="mailto:support@icxtopup.com" class="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-8 rounded-lg shadow-md transition uppercase tracking-wide inline-block">
                Contact Support
            </a>
        </div>
    </main>
</div>
<?php require_once 'common/footer.php'; ?>

