-- Mango TopUp / ICX schema
-- The live app uses SQLite at data/mango.sqlite and auto-creates tables on first run.
-- Import this file only if you switch to MySQL.

CREATE TABLE IF NOT EXISTS site_settings (
  key_name VARCHAR(100) PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) UNIQUE NOT NULL,
  phone VARCHAR(30),
  password VARCHAR(255) NOT NULL,
  balance DECIMAL(12,2) DEFAULT 0,
  support_pin VARCHAR(20),
  referral_code VARCHAR(30),
  referred_by INT,
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS games (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  slug VARCHAR(160) UNIQUE,
  type VARCHAR(20) DEFAULT 'uid',
  category VARCHAR(40) DEFAULT 'hot',
  thumbnail TEXT,
  banner TEXT,
  description TEXT,
  rules TEXT,
  stock_note VARCHAR(80),
  status VARCHAR(20) DEFAULT 'active',
  sort_order INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS packages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  sort_order INT DEFAULT 0,
  status VARCHAR(20) DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(40) UNIQUE,
  user_id INT,
  game_id INT,
  package_id INT,
  player_id VARCHAR(80),
  quantity INT DEFAULT 1,
  total_amount DECIMAL(12,2) DEFAULT 0,
  payment_method VARCHAR(40),
  txn_id VARCHAR(80),
  status VARCHAR(20) DEFAULT 'Pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wallet_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  amount DECIMAL(12,2),
  payment_method VARCHAR(40),
  txn_id VARCHAR(80),
  sender_number VARCHAR(40),
  status VARCHAR(20) DEFAULT 'Pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payment_methods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  number VARCHAR(40),
  type VARCHAR(20) DEFAULT 'personal',
  status VARCHAR(20) DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS sliders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  image TEXT,
  title VARCHAR(160),
  link_url TEXT,
  status VARCHAR(20) DEFAULT 'active',
  sort_order INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS redeem_codes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT,
  package_id INT,
  user_id INT,
  code VARCHAR(120),
  status VARCHAR(20) DEFAULT 'unused',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  title VARCHAR(160),
  message TEXT,
  is_read TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  game_id INT,
  rating INT,
  comment TEXT,
  status VARCHAR(20) DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wishlist (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  game_id INT,
  UNIQUE KEY uniq_wish (user_id, game_id)
);

CREATE TABLE IF NOT EXISTS coupons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) UNIQUE,
  discount DECIMAL(10,2) DEFAULT 0,
  type VARCHAR(20) DEFAULT 'percent',
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT,
  action TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
