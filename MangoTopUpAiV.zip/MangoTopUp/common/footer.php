<?php
?>
<footer class="mt-10 bg-[#071426] text-white pt-10 pb-28 md:pb-10">
    <div class="max-w-[430px] md:max-w-[720px] mx-auto px-5">
        <div class="mb-8">
            <h3 class="text-base font-extrabold mb-2 tracking-wide uppercase">Stay Connected</h3>
            <p class="text-xs text-gray-300 leading-relaxed mb-4">If you face any problem, contact us on Telegram for a fast solution.</p>
            <div class="flex gap-2.5">
                <a href="<?= htmlspecialchars(getSetting($pdo,'social_facebook','#')) ?>" class="w-10 h-10 rounded-md border border-white/20 flex items-center justify-center hover:bg-accent hover:border-accent transition"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#" class="w-10 h-10 rounded-md border border-white/20 flex items-center justify-center hover:bg-accent hover:border-accent transition"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="w-10 h-10 rounded-md border border-white/20 flex items-center justify-center hover:bg-accent hover:border-accent transition"><i class="fa-brands fa-youtube"></i></a>
                <a href="<?= htmlspecialchars(getSetting($pdo,'support_telegram','#')) ?>" class="w-10 h-10 rounded-md border border-white/20 flex items-center justify-center hover:bg-accent hover:border-accent transition"><i class="fa-brands fa-telegram"></i></a>
            </div>
        </div>

        <div class="mb-8">
            <h3 class="text-base font-extrabold mb-2 tracking-wide uppercase">Our Mobile App</h3>
            <p class="text-xs text-gray-300">Install the app for faster topup and order tracking.</p>
        </div>

        <div class="mb-8">
            <h3 class="text-base font-extrabold mb-3 tracking-wide uppercase">Support Center</h3>
            <div class="space-y-3">
                <a href="<?= htmlspecialchars(getSetting($pdo,'support_whatsapp','#')) ?>" class="block border border-white/20 rounded-xl p-3 flex items-center gap-4 hover:border-accent transition">
                    <i class="fa-brands fa-whatsapp text-3xl text-green-400"></i>
                    <div class="border-l border-white/20 pl-4">
                        <p class="text-[11px] font-bold text-gray-300">Help line [9AM-12PM]</p>
                        <p class="text-sm font-semibold">WhatsApp HelpLine</p>
                    </div>
                </a>
                <a href="<?= htmlspecialchars(getSetting($pdo,'support_telegram','#')) ?>" class="block border border-white/20 rounded-xl p-3 flex items-center gap-4 hover:border-accent transition">
                    <i class="fa-brands fa-telegram text-3xl text-sky-400"></i>
                    <div class="border-l border-white/20 pl-4">
                        <p class="text-[11px] font-bold text-gray-300">Help line [9AM-12PM]</p>
                        <p class="text-sm font-semibold">Telegram Support</p>
                    </div>
                </a>
            </div>
        </div>

        <div class="text-center border-t border-white/10 pt-6">
            <div class="flex flex-wrap justify-center gap-x-4 gap-y-2 text-[12px] text-gray-300 font-medium mb-5">
                <a href="<?= SITE_URL ?>/about-us.php" class="hover:text-accent">About Us</a>
                <a href="<?= SITE_URL ?>/terms.php" class="hover:text-accent">Terms & Conditions</a>
                <a href="<?= SITE_URL ?>/privacy-policy.php" class="hover:text-accent">Privacy Policy</a>
                <a href="<?= SITE_URL ?>/refund-policy.php" class="hover:text-accent">Refund & Return Policy</a>
                <a href="<?= SITE_URL ?>/delete-account.php" class="hover:text-accent">Delete Account Policy</a>
            </div>
            <p class="text-[11px] text-gray-400 leading-relaxed">
                © <?= htmlspecialchars(siteName()) ?> <?= date('Y') ?> | All Rights Reserved<br>
                Developed by
                <a href="https://t.me/infinity_codex" target="_blank" rel="noopener" class="text-accent font-extrabold hover:underline">RiAAD</a>
            </p>
        </div>
    </div>
</footer>

<a href="<?= htmlspecialchars(getSetting($pdo,'support_whatsapp','#')) ?>" class="fixed bottom-24 right-4 bg-accent text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition z-50 border-2 border-white/20">
    <i class="fa-solid fa-headset text-xl"></i>
</a>
<script src="<?= SITE_URL ?>/assets/js/security.js"></script>
<script src="<?= SITE_URL ?>/assets/js/script.js"></script>
</body>
</html>
