<?php
// common/config.php
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

date_default_timezone_set('Asia/Dhaka');

define('ROOT_PATH', dirname(__DIR__));
define('DB_PATH', dirname(ROOT_PATH) . '/MangoTopUp-data/mango.sqlite');

$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
$projRoot = realpath(ROOT_PATH);
$base = '';
if ($docRoot && $projRoot && $docRoot !== false && strpos($projRoot, $docRoot) === 0) {
    $base = str_replace('\\', '/', substr($projRoot, strlen($docRoot)));
}
define('SITE_URL', rtrim(($https ? 'https' : 'http') . '://' . $host . $base, '/'));

foreach ([ROOT_PATH . '/data', ROOT_PATH . '/uploads/slides', ROOT_PATH . '/uploads/games'] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
}

require_once __DIR__ . '/minidb.php';
$dataStore = ROOT_PATH . '/data';
if (!is_dir($dataStore)) @mkdir($dataStore, 0755, true);
$dbFile = $dataStore . '/db.json';
// Older sandbox installs stored data one directory above the project; migrate it only when the local file is absent.
$legacyDbFile = dirname(ROOT_PATH) . '/MangoTopUp-data/db.json';
if (!is_file($dbFile) && is_file($legacyDbFile)) @copy($legacyDbFile, $dbFile);
if (is_file($dbFile)) @chmod($dbFile, 0600);
$pdo = new MiniPDO($dbFile);

function sanitize($value) {
    if (is_array($value)) {
        return array_map('sanitize', $value);
    }
    return trim(htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'));
}

function getSetting($pdo, $key, $default = '') {
    static $cache = null;
    if ($key === '__reset') { $cache = null; return $default; }
    if ($cache === null) {
        $cache = [];
        try {
            $rows = $pdo->query('SELECT key_name, value FROM site_settings')->fetchAll();
            foreach ($rows as $row) {
                $cache[$row['key_name']] = $row['value'];
            }
        } catch (Exception $e) {
            $cache = [];
        }
    }
    return $cache[$key] ?? $default;
}

function siteName($fallback = 'Mango TopUp') {
    global $pdo;
    try { return getSetting($pdo, 'site_name', $fallback) ?: $fallback; } catch (Throwable $e) { return $fallback; }
}

function money_fmt($amount, $symbol = null) {
    global $pdo;
    $symbol = $symbol ?? getSetting($pdo, 'currency_symbol', '৳');
    return $symbol . ' ' . number_format((float)$amount, 0);
}

function initDatabase($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS site_settings (
            key_name TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            password TEXT NOT NULL,
            balance REAL DEFAULT 0,
            support_pin TEXT,
            referral_code TEXT,
            referred_by INTEGER,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS games (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT UNIQUE,
            type TEXT DEFAULT 'uid',
            category TEXT DEFAULT 'hot',
            thumbnail TEXT,
            banner TEXT,
            description TEXT,
            rules TEXT,
            stock_note TEXT,
            status TEXT DEFAULT 'active',
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS packages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            game_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            sort_order INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_no TEXT UNIQUE,
            user_id INTEGER,
            game_id INTEGER,
            package_id INTEGER,
            player_id TEXT,
            quantity INTEGER DEFAULT 1,
            total_amount REAL DEFAULT 0,
            payment_method TEXT,
            txn_id TEXT,
            status TEXT DEFAULT 'Pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wallet_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount REAL,
            payment_method TEXT,
            txn_id TEXT,
            sender_number TEXT,
            status TEXT DEFAULT 'Pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS payment_methods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            number TEXT,
            type TEXT DEFAULT 'personal',
            status TEXT DEFAULT 'active'
        );
        CREATE TABLE IF NOT EXISTS sliders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            image TEXT,
            title TEXT,
            link_url TEXT,
            status TEXT DEFAULT 'active',
            sort_order INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS redeem_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            game_id INTEGER,
            package_id INTEGER,
            user_id INTEGER,
            code TEXT,
            status TEXT DEFAULT 'unused',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT,
            message TEXT,
            is_read INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            game_id INTEGER,
            rating INTEGER,
            comment TEXT,
            status TEXT DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wishlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            game_id INTEGER,
            UNIQUE(user_id, game_id)
        );
        CREATE TABLE IF NOT EXISTS coupons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE,
            discount REAL DEFAULT 0,
            type TEXT DEFAULT 'percent',
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER,
            action TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    ");

    $count = (int)$pdo->query('SELECT COUNT(*) FROM site_settings')->fetchColumn();
    if ($count === 0) {
        seedDatabase($pdo);
    }
}

function seedDatabase($pdo) {
    $settings = [
        'site_name' => 'Mango TopUp',
        'currency_symbol' => 'Tk',
        'notice_text' => 'টাকা চুরি করে কেউ টপআপ করবেন না। যদি করেন সে ক্ষেত্রে তাকে টপ আপ দেওয়া হবে না।',
        'support_whatsapp' => 'https://wa.me/8801700000000',
        'support_telegram' => 'https://t.me/mangotopup',
        'social_facebook' => 'https://facebook.com',
        'social_youtube' => 'https://youtube.com',
        'social_instagram' => 'https://instagram.com',
        'popup_status' => 'active',
        'popup_title' => 'Special limited edition.... ORDER NOW',
        'popup_message' => 'সকল কুলারের আব্বা Mr Triple R X Piva বাংলাদেশের শুধুমাত্র আমাদের কাছে পেয়ে যাচ্ছেন। লাগলে এখনই অর্ডার করে ফেলুন DK Gadget\'s Hub থেকে',
        'popup_btn' => 'ক্লিক করুন',
        'popup_link' => '#',
    ];
    $st = $pdo->prepare('INSERT OR REPLACE INTO site_settings (key_name, value) VALUES (?, ?)');
    foreach ($settings as $k => $v) {
        $st->execute([$k, $v]);
    }

    $adminPass = password_hash('admin123', PASSWORD_DEFAULT);
    $pdo->prepare('INSERT INTO admins (name, email, password) VALUES (?, ?, ?)')
        ->execute(['Super Admin', 'admin@mangotopup.com', $adminPass]);

    $userPass = password_hash('demo123', PASSWORD_DEFAULT);
    $pdo->prepare('INSERT INTO users (name, email, phone, password, balance, support_pin, referral_code, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute(['Infinity', 'demo@mangotopup.com', '01700000000', $userPass, 0, '618674', 'MANGO618', 'active']);

    $pdo->exec("INSERT INTO payment_methods (name, number, type, status) VALUES
        ('bKash', '01700-000000', 'personal', 'active'),
        ('Nagad', '01800-000000', 'personal', 'active'),
        ('Rocket', '01900-000000', 'personal', 'active')
    ");

    $pdo->exec("INSERT INTO sliders (image, title, link_url, status, sort_order) VALUES
        ('https://placehold.co/1200x520/111827/ffffff?text=24+Hour+Top+Up', 'দিন-রাত ২৪ ঘন্টা TOP UP করুন', 'game_detail.php?id=1', 'active', 1),
        ('https://placehold.co/1200x520/0f172a/f97316?text=Flash+Sale', 'Flash Sale is Live', 'index.php', 'active', 2),
        ('https://placehold.co/1200x520/1e3a5f/ffffff?text=UID+Topup+BD+Server', 'UID Topup BD Server', 'game_detail.php?id=1', 'active', 3)
    ");

    $games = [
        [1, 'Uid Topup [BD SERVER]', 'uid-topup-bd', 'uid', 'hot', 'https://placehold.co/300x300/0E3B2E/ffffff?text=UID', 'UID diamond topup for Bangladesh server.', "শুধুমাত্র Bangladesh সার্ভার ID Code দিয়ে টপ আপ হবে।\nPlayer ID Code ভুল দিলে Diamond না পেলে mangotopup দায়ী নয়।\nOrder কনফার্ম হওয়ার পরও আইডিতে ডায়মন্ড না গেলে চেক করার জন্য ID Pass দিতে হবে।", '1405540000000', 1],
        [2, 'UNIPIN VOUCHER (BDT)', 'unipin-voucher', 'voucher', 'hot', 'https://placehold.co/300x300/7c2d12/ffffff?text=UNIPIN', 'Unipin voucher codes for Garena.', "শুধুমাত্র BD সার্ভারে VOUCHER দিয়ে টপ আপ হবে।\nকোড রিডিম করুন shop.garena.my থেকে।\nUPBD দেখালে Unipin Gift Card এ ব্যবহার করতে হবে।\nBDMB দেখালে Unipin Voucher এ ব্যবহার করতে হবে।", '', 2],
        [3, 'TikTok Coins', 'tiktok-coins', 'uid', 'flash', 'https://placehold.co/300x300/111111/fe2c55?text=TikTok', 'TikTok coin topup.', 'সঠিক ইউজারনেম দিন। ভুল আইডিতে পাঠানো কয়েন ফেরতযোগ্য নয়।', '', 3],
        [4, 'DLS 2026', 'dls-2026', 'uid', 'flash', 'https://placehold.co/300x300/14532d/ffffff?text=DLS+26', 'Dream League Soccer coins.', 'সঠিক প্লেয়ার আইডি দিন।', '', 4],
        [5, 'EFootball Luis Suarez & Iker', 'efootball-suarez', 'uid', 'flash', 'https://placehold.co/300x300/1d4ed8/ffffff?text=eFootball', 'eFootball special pack.', 'সঠিক কনসোল/আইডি দিন।', '', 5],
        [6, 'eFootball 2026', 'efootball-2026', 'uid', 'pes', 'https://placehold.co/300x300/1e40af/ffffff?text=PES', 'eFootball coins and players.', 'সঠিক আইডি দিন।', '', 6],
        [7, 'YouTube Premium', 'youtube-premium', 'voucher', 'subscription', 'https://placehold.co/300x300/b91c1c/ffffff?text=YouTube', 'YouTube Premium subscription.', 'অ্যাকাউন্ট ইমেইল সঠিকভাবে দিন।', '', 7],
        [8, 'Facebook Boost', 'facebook-boost', 'uid', 'subscription', 'https://placehold.co/300x300/1d4ed8/ffffff?text=FB', 'Facebook page boost service.', 'পেজ লিংক সঠিকভাবে দিন।', '', 8],
        [9, 'Telegram Premium', 'telegram-premium', 'uid', 'subscription', 'https://placehold.co/300x300/0284c7/ffffff?text=TG', 'Telegram premium.', 'ইউজারনেম দিন।', '', 9],
        [10, 'ChatGPT Plus', 'chatgpt-plus', 'voucher', 'others', 'https://placehold.co/300x300/111827/22c55e?text=GPT', 'ChatGPT Plus voucher.', 'ইমেইল সঠিকভাবে দিন।', '', 10],
        [11, 'Pubg Mobile UC', 'pubg-uc', 'uid', 'hot', 'https://placehold.co/300x300/854d0e/ffffff?text=PUBG', 'PUBG Mobile UC.', 'শুধুমাত্র সঠিক UID ব্যবহার করুন।', '', 11],
        [12, 'Free Fire Diamonds', 'free-fire', 'uid', 'hot', 'https://placehold.co/300x300/9a3412/ffffff?text=FF', 'Free Fire diamonds.', 'BD সার্ভার আইডি দিন।', '', 12],
    ];
    $gStmt = $pdo->prepare('INSERT INTO games (id, name, slug, type, category, thumbnail, description, rules, stock_note, sort_order, status) VALUES (?,?,?,?,?,?,?,?,?,?,\'active\')');
    foreach ($games as $g) {
        $gStmt->execute($g);
    }

    $packages = [
        [1, 'Weekly', 155, 1], [1, 'Monthly', 775, 2],
        [1, '25 Diamond', 20, 3], [1, '50 Diamond', 35, 4],
        [1, '115 Diamond', 78, 5], [1, '240 Diamond', 156, 6],
        [1, '355 Diamond', 235, 7], [1, '480 Diamond', 316, 8],
        [1, '610 Diamond', 400, 9], [1, '850 Diamond', 558, 10],
        [1, '1240 Diamond', 799, 11], [1, '2530 Diamond', 1610, 12],
        [1, '5060 Diamond', 3220, 13],
        [2, '25 Diamond Code', 19, 1], [2, '50 Diamond Code', 35, 2],
        [2, '115 Diamond Code', 79, 3], [2, '240 Diamond Code', 159, 4],
        [2, '610 Diamond Code', 404, 5], [2, '1240 Diamond Code', 809, 6],
        [2, '2530 Diamond Code', 1626, 7], [2, 'Weekly Code', 160, 8],
        [2, 'Monthly Code', 775, 9],
        [3, '70 Coins', 99, 1], [3, '350 Coins', 449, 2], [3, '700 Coins', 849, 3],
        [4, '100 Coins', 80, 1], [4, '500 Coins', 350, 2],
        [5, 'Suarez Pack', 90, 1], [5, 'Iker Pack', 120, 2],
        [6, '130 Coins', 99, 1], [6, '550 Coins', 399, 2],
        [7, '1 Month', 199, 1], [7, '3 Month', 549, 2],
        [8, 'Boost 1 Day', 150, 1],
        [9, '1 Month', 249, 1],
        [10, '1 Month', 899, 1],
        [11, '60 UC', 95, 1], [11, '325 UC', 480, 2],
        [12, '100 Diamond', 80, 1], [12, '310 Diamond', 230, 2],
    ];
    $pStmt = $pdo->prepare('INSERT INTO packages (game_id, name, price, sort_order, status) VALUES (?,?,?,?,\'active\')');
    foreach ($packages as $p) {
        $pStmt->execute($p);
    }
}

initDatabase($pdo);

function ensure_admin_catalog($pdo) {
    $cats = $pdo->query("SELECT * FROM categories")->fetchAll();
    if ($cats) return;
    $seed = [
        ['flash','FLASH SALE',1],
        ['hot','HOT PRODUCT',2],
        ['pes','All PES Football',3],
        ['others','Others',4],
        ['subscription','Others Subscription',5],
    ];
    $i=1;
    foreach ($seed as $c) {
        $pdo->prepare("INSERT INTO categories (name, slug, sort_order, status) VALUES (?,?,?,?)")
            ->execute([$c[1], $c[0], $c[2], 'active']);
        $i++;
    }
}
ensure_admin_catalog($pdo);
