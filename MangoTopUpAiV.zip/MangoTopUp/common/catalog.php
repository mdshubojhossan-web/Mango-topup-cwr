<?php
function refreshCatalogIfNeeded($pdo) {
    $ver = '';
    try {
        $st = $pdo->prepare("SELECT value FROM site_settings WHERE key_name='catalog_version'");
        $st->execute();
        $ver = (string)$st->fetchColumn();
    } catch (Exception $e) {
        $ver = '';
    }
    if ($ver === '3') {
        return;
    }
    seedCatalog($pdo);
    $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES ('catalog_version', '3') ON CONFLICT(key_name) DO UPDATE SET value=excluded.value")->execute();
}

function seedCatalog($pdo) {
    $pdo->exec('DELETE FROM packages');
    $pdo->exec('DELETE FROM games');
    $pdo->exec('DELETE FROM sliders');

    $notice = '১৮ বছরের নিচে কেউ অর্ডার করতে অবশ্যই বাবা-মায়ের অনুমতি লাগবে। মা-বাবা বা ফ্যামিলির কারো ফোন থেকে টাকা চুরি করে কেউ টপআপ করবেন না! যদি করেন সে ক্ষেত্রে তাকে টপ আপ দেওয়া হবে না। যেকোনো প্রয়োজনে হোয়াটসঅ্যাপ অথবা টেলিগ্রাম এ যোগাযোগ করুন, ধন্যবাদ। হোয়াটসঅ্যাপ: 01318962340';
    $sets = [
        'site_name' => 'Mango TopUp',
        'site_logo' => 'https://admin.mangotopup.com/notices/1732479782.png',
        'notice_text' => $notice,
        'support_whatsapp' => 'https://wa.me/8801318962340',
        'support_telegram' => 'https://t.me/Mangoadmin007',
        'social_facebook' => 'https://facebook.com',
        'social_group' => 'https://t.me/mangotopup420',
        'popup_status' => 'active',
        'popup_image' => 'https://admin.mangotopup.com/notices/1787130477_home_page_notice.jpg',
        'popup_title' => 'Special limited edition.... ORDER NOW',
        'popup_message' => "সকল কুলারের আব্বা Mr Triple R X Piva বাংলাদেশের শুধুমাত্র আমাদের কাছে পেয়ে যাচ্ছেন। লাগলে এখনই অর্ডার করে ফেলুন DK Gadget's Hub থেকে",
        'popup_btn' => 'ক্লিক করুন',
        'popup_link' => 'https://www.dkgadgetshub.com/product-show/piva-x-triple-r',
        'currency_symbol' => 'Tk',
    ];
    $st = $pdo->prepare('INSERT INTO site_settings (key_name, value) VALUES (?, ?) ON CONFLICT(key_name) DO UPDATE SET value=excluded.value');
    foreach ($sets as $k => $v) {
        $st->execute([$k, $v]);
    }

    $sIns = $pdo->prepare('INSERT INTO sliders (image, title, link_url, status, sort_order) VALUES (?,?,?,?,?)');
    $sIns->execute(['https://admin.mangotopup.com/banners/1766768410.jpg', 'Banner 1', 'https://t.me/Mangoadmin007', 'active', 1]);
    $sIns->execute(['https://admin.mangotopup.com/banners/1753986524.jpg', 'Banner 2', 'https://t.me/mangotopup420', 'active', 2]);
    $sIns->execute(['https://admin.mangotopup.com/banners/1753986402.jpg', 'How to topup', 'https://youtu.be/ndr0vSaws0s', 'active', 3]);
    $sIns->execute(['https://admin.mangotopup.com/banners/1787130014.jpeg', 'DK Gadgets', 'https://www.dkgadgetshub.com/product-show/piva-x-triple-r', 'active', 4]);

    $games = [
        ['EFootball™ Luis Suarez & Iker Casillas', 'efootball-suarez', 'uid', 'flash', 'https://admin.mangotopup.com/products/1788648335.jpg', 1],
        ['TikTok Coins', 'tiktok-coins', 'uid', 'flash', 'https://admin.mangotopup.com/products/1779738333.jpeg', 2],
        ['DLS 2026', 'dls-2026', 'uid', 'flash', 'https://admin.mangotopup.com/products/1788635591.jpg', 3],
        ['Uid Topup [BD SERVER]', 'uid-topup-bd', 'uid', 'hot', 'https://admin.mangotopup.com/products/1786469692.jpeg', 10],
        ['Weekly/Monthly', 'weekly-monthly', 'uid', 'hot', 'https://admin.mangotopup.com/products/1786470110.jpeg', 11],
        ['FF Like', 'ff-like', 'uid', 'hot', 'https://admin.mangotopup.com/products/1785676047.jpg', 12],
        ['Level Up Pass BD', 'level-up-pass-bd', 'uid', 'hot', 'https://admin.mangotopup.com/products/1786469805.jpeg', 13],
        ['Weekly Lite', 'weekly-lite', 'uid', 'hot', 'https://admin.mangotopup.com/products/1786470043.jpeg', 14],
        ['UNIPIN VOUCHER (BDT)', 'unipin-voucher', 'voucher', 'hot', 'https://admin.mangotopup.com/products/1786469860.jpeg', 15],
        ['EFootball™ Android', 'efootball-android', 'uid', 'pes', 'https://admin.mangotopup.com/products/1788804433.jpeg', 20],
        ['EFootball™ For I-Phone', 'efootball-iphone', 'uid', 'pes', 'https://admin.mangotopup.com/products/1788802444.jpeg', 21],
        ['FC Football™ {Stat Pass And Coins}', 'fc-football', 'uid', 'pes', 'https://admin.mangotopup.com/products/1788208179.jpeg', 22],
        ['EA SPORTS FC™ {Offers+Packs}', 'ea-sports-fc', 'uid', 'pes', 'https://admin.mangotopup.com/products/1788207982.jpeg', 23],
        ['Roblox Top Up', 'roblox', 'uid', 'pes', 'https://admin.mangotopup.com/products/1788550626.jpg', 24],
        ['PUBG Uid UC', 'pubg-uid-uc', 'uid', 'others', 'https://admin.mangotopup.com/products/1786472520.jpeg', 30],
        ['Premium User', 'premium-user', 'uid', 'others', 'https://admin.mangotopup.com/products/1773737494.jpeg', 31],
        ['COC', 'coc', 'uid', 'others', 'https://admin.mangotopup.com/products/1774813871.jpg', 32],
        ['Clash Royal', 'clash-royal', 'uid', 'others', 'https://admin.mangotopup.com/products/1788956735.jpeg', 33],
        ['AIRDROP IN-GAME', 'airdrop', 'uid', 'others', 'https://admin.mangotopup.com/products/1784950679.jpg', 34],
        ['FF Uid [Indonesia]', 'ff-indonesia', 'uid', 'others', 'https://admin.mangotopup.com/products/1736417408.jpg', 35],
        ['Need Help??? টেলিগ্রামে মেসেজ করুন', 'need-help', 'uid', 'others', 'https://admin.mangotopup.com/products/1788985891.jpeg', 36],
        ['Good Shorts HUB', 'good-shorts', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1789501564.jpeg', 40],
        ['NETFLIX', 'netflix', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1780857860.jpeg', 41],
        ['Amazon Prime', 'amazon-prime', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1780861766.jpeg', 42],
        ['Chorki', 'chorki', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1780863260.jpeg', 43],
        ['VPN', 'vpn', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1780864955.jpeg', 44],
        ['Telegram Premium', 'telegram-premium', 'uid', 'subscription', 'https://admin.mangotopup.com/products/1742713793.jpg', 45],
        ['FB SERVICE', 'fb-service', 'uid', 'subscription', 'https://admin.mangotopup.com/products/1740898059.jpg', 46],
        ['Crunchyroll Premium Offer', 'crunchyroll', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1780860160.jpeg', 47],
        ['Canva Pro', 'canva-pro', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1779735024.jpeg', 48],
        ['1 Month Yt Premium', 'yt-premium', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1782068110.jpeg', 49],
        ['Gemini Pro/Plus Veo 3 With Google Storage', 'gemini-pro', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1786038533.jpg', 50],
        ['Cap Cut', 'capcut', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1780853818.jpeg', 51],
        ['Chat Gpt Premium', 'chatgpt', 'voucher', 'subscription', 'https://admin.mangotopup.com/products/1758048680.png', 52],
    ];

    $uidRules = "শুধুমাত্র Bangladesh সার্ভার ID Code দিয়ে টপ আপ হবে।\nPlayer ID Code ভুল দিলে Diamond না পেলে mangotopup দায়ী নয়।\nOrder কনফার্ম হওয়ার পরও আইডিতে ডায়মন্ড না গেলে চেক করার জন্য ID Pass দিতে হবে।";
    $voucherRules = "শুধুমাত্র BD সার্ভারে VOUCHER দিয়ে টপ আপ হবে।\nকোড রিডিম করুন shop.garena.my থেকে।\nUPBD দেখালে Unipin Gift Card এ ব্যবহার করতে হবে।\nBDMB দেখালে Unipin Voucher এ ব্যবহার করতে হবে।";

    $gs = $pdo->prepare('INSERT INTO games (name, slug, type, category, thumbnail, description, rules, stock_note, sort_order, status) VALUES (?,?,?,?,?,?,?,?,?,\'active\')');
    $map = [];
    foreach ($games as $g) {
        $rules = $g[2] === 'voucher' ? $voucherRules : $uidRules;
        $stock = $g[1] === 'uid-topup-bd' ? '1405540000000' : '';
        $gs->execute([$g[0], $g[1], $g[2], $g[3], $g[4], $g[0], $rules, $stock, $g[5]]);
        $map[$g[1]] = (int)$pdo->lastInsertId();
    }

    $ps = $pdo->prepare('INSERT INTO packages (game_id, name, price, sort_order, status) VALUES (?,?,?,?,\'active\')');
    $packMap = [
        'uid-topup-bd' => [['Weekly',155],['Monthly',775],['25 Diamond',20],['50 Diamond',35],['115 Diamond',78],['240 Diamond',156],['355 Diamond',235],['480 Diamond',316],['610 Diamond',400],['850 Diamond',558],['1240 Diamond',799],['2530 Diamond',1610],['5060 Diamond',3220]],
        'unipin-voucher' => [['25 Diamond Code',19],['50 Diamond Code',35],['115 Diamond Code',79],['240 Diamond Code',159],['610 Diamond Code',404],['1240 Diamond Code',809],['2530 Diamond Code',1626],['Weekly Code',160],['Monthly Code',775]],
        'weekly-monthly' => [['Weekly',155],['Monthly',775],['Weekly Lite',80]],
        'weekly-lite' => [['Weekly Lite',80]],
        'ff-like' => [['50 Like',20],['100 Like',35],['200 Like',60]],
        'level-up-pass-bd' => [['Level Up Pass',450]],
        'tiktok-coins' => [['70 Coins',99],['350 Coins',449],['700 Coins',849]],
        'dls-2026' => [['100 Coins',80],['500 Coins',350]],
        'efootball-suarez' => [['Suarez Pack',90],['Iker Pack',120]],
        'pubg-uid-uc' => [['60 UC',95],['325 UC',480],['660 UC',920]],
        'netflix' => [['1 Month',199],['3 Month',549]],
        'chatgpt' => [['1 Month',899]],
        'telegram-premium' => [['1 Month',249],['12 Month',1999]],
    ];
    foreach ($map as $slug => $gid) {
        $list = $packMap[$slug] ?? [['Standard',99],['Premium',199]];
        $i = 1;
        foreach ($list as $pk) {
            $ps->execute([$gid, $pk[0], $pk[1], $i]);
            $i++;
        }
    }
}
