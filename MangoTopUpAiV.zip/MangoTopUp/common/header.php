<?php
// common/header.php
if (!isset($pdo)) {
    require_once __DIR__ . '/config.php';
}
$siteName = getSetting($pdo, 'site_name', 'Mango TopUp');
$pageTitle = $pageTitle ?? $siteName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '<?= getSetting($pdo, "color_primary", "#3FAE72") ?>',
                        accent: '<?= getSetting($pdo, "color_accent", "#FF7A00") ?>',
                        dark: '<?= getSetting($pdo, "color_dark", "#0B1B36") ?>',
                        bg: '<?= getSetting($pdo, "color_bg", "#FFF7ED") ?>'
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body class="bg-[#F6F7FB] font-sans antialiased text-gray-800">
