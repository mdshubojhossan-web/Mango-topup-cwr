<?php
return array (
  'site_settings' => 
  array (
    0 => 
    array (
      'key_name' => 'site_name',
      'value' => 'Mango TopUp',
    ),
    1 => 
    array (
      'key_name' => 'site_logo',
      'value' => 'https://admin.mangotopup.com/notices/1732479782.png',
    ),
    2 => 
    array (
      'key_name' => 'notice_text',
      'value' => '১৮ বছরের নিচে কেউ অর্ডার করতে অবশ্যই বাবা-মায়ের অনুমতি লাগবে। মা-বাবা বা ফ্যামিলির কারো ফোন থেকে টাকা চুরি করে কেউ টপআপ করবেন না! যদি করেন সে ক্ষেত্রে তাকে টপ আপ দেওয়া হবে না। যেকোনো প্রয়োজনে হোয়াটসঅ্যাপ অথবা টেলিগ্রাম এ যোগাযোগ করুন, ধন্যবাদ। হোয়াটসঅ্যাপ: 01318962340',
    ),
    3 => 
    array (
      'key_name' => 'support_whatsapp',
      'value' => 'https://wa.me/8801318962340',
    ),
    4 => 
    array (
      'key_name' => 'support_telegram',
      'value' => 'https://t.me/Mangoadmin007',
    ),
    5 => 
    array (
      'key_name' => 'social_facebook',
      'value' => 'https://facebook.com',
    ),
    6 => 
    array (
      'key_name' => 'social_group',
      'value' => 'https://t.me/mangotopup420',
    ),
    7 => 
    array (
      'key_name' => 'popup_status',
      'value' => 'active',
    ),
    8 => 
    array (
      'key_name' => 'popup_image',
      'value' => 'https://admin.mangotopup.com/notices/1787130477_home_page_notice.jpg',
    ),
    9 => 
    array (
      'key_name' => 'popup_title',
      'value' => 'Special limited edition.... ORDER NOW',
    ),
    10 => 
    array (
      'key_name' => 'popup_message',
      'value' => 'সকল কুলারের আব্বা Mr Triple R X Piva বাংলাদেশের শুধুমাত্র আমাদের কাছে পেয়ে যাচ্ছেন। লাগলে এখনই অর্ডার করে ফেলুন DK Gadget\'s Hub থেকে',
    ),
    11 => 
    array (
      'key_name' => 'popup_btn',
      'value' => 'ক্লিক করুন',
    ),
    12 => 
    array (
      'key_name' => 'popup_link',
      'value' => 'https://www.dkgadgetshub.com/product-show/piva-x-triple-r',
    ),
    13 => 
    array (
      'key_name' => 'currency_symbol',
      'value' => 'Tk',
    ),
    14 => 
    array (
      'key_name' => 'catalog_version',
      'value' => '3',
    ),
    15 => 
    array (
      'key_name' => 'player_name_api_url',
      'value' => 'http://ixbd.qd.je/ff.php?uid={uid}',
    ),
  ),
  'admins' => 
  array (
    0 => 
    array (
      'id' => 1,
      'name' => 'Super Admin',
      'email' => 'admin@mangotopup.com',
      'password' => '$2y$10$fBZzcufEmsxZe.YOCHGCFur/N53tmK0NRpLAT6rrOmLLKh6EGGcdG',
      'status' => 'active',
      'created_at' => '2026-09-28 00:53:04',
    ),
  ),
  'users' => 
  array (
    0 => 
    array (
      'id' => 1,
      'name' => 'Infinity',
      'email' => 'demo@mangotopup.com',
      'phone' => '01700000000',
      'password' => '$2y$10$554a5WKE18U3izzLQOA86.AtLgcBJzoOHSPiRujjoZWApsfuXshoS',
      'balance' => 0,
      'support_pin' => '618674',
      'referral_code' => 'MANGO618',
      'referred_by' => NULL,
      'status' => 'active',
      'created_at' => '2026-09-28 00:53:04',
    ),
  ),
  'payment_methods' => 
  array (
    0 => 
    array (
      'id' => 1,
      'name' => 'bKash',
      'number' => '01700-000000',
      'type' => 'personal',
      'status' => 'active',
    ),
    1 => 
    array (
      'id' => 2,
      'name' => 'Nagad',
      'number' => '01800-000000',
      'type' => 'personal',
      'status' => 'active',
    ),
    2 => 
    array (
      'id' => 3,
      'name' => 'Rocket',
      'number' => '01900-000000',
      'type' => 'personal',
      'status' => 'active',
    ),
  ),
  'sliders' => 
  array (
    0 => 
    array (
      'id' => 1,
      'image' => 'https://admin.mangotopup.com/banners/1766768410.jpg',
      'title' => 'Banner 1',
      'link_url' => 'https://t.me/Mangoadmin007',
      'status' => 'active',
      'sort_order' => 1,
    ),
    1 => 
    array (
      'id' => 2,
      'image' => 'https://admin.mangotopup.com/banners/1753986524.jpg',
      'title' => 'Banner 2',
      'link_url' => 'https://t.me/mangotopup420',
      'status' => 'active',
      'sort_order' => 2,
    ),
    2 => 
    array (
      'id' => 3,
      'image' => 'https://admin.mangotopup.com/banners/1753986402.jpg',
      'title' => 'How to topup',
      'link_url' => 'https://youtu.be/ndr0vSaws0s',
      'status' => 'active',
      'sort_order' => 3,
    ),
    3 => 
    array (
      'id' => 4,
      'image' => 'https://admin.mangotopup.com/banners/1787130014.jpeg',
      'title' => 'DK Gadgets',
      'link_url' => 'https://www.dkgadgetshub.com/product-show/piva-x-triple-r',
      'status' => 'active',
      'sort_order' => 4,
    ),
  ),
  'orders' => 
  array (
  ),
  'wallet_requests' => 
  array (
  ),
  'redeem_codes' => 
  array (
  ),
  'notifications' => 
  array (
  ),
  'reviews' => 
  array (
  ),
  'wishlist' => 
  array (
  ),
  'coupons' => 
  array (
  ),
  'activity_logs' => 
  array (
  ),
  'games' => 
  array (
    0 => 
    array (
      'id' => 1,
      'name' => 'EFootball™ Luis Suarez & Iker Casillas',
      'slug' => 'efootball-suarez',
      'type' => 'uid',
      'category' => 'flash',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788648335.jpg',
      'banner' => '',
      'description' => 'EFootball™ Luis Suarez & Iker Casillas',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 1,
      'created_at' => '2026-09-28 00:53:04',
    ),
    1 => 
    array (
      'id' => 2,
      'name' => 'TikTok Coins',
      'slug' => 'tiktok-coins',
      'type' => 'uid',
      'category' => 'flash',
      'thumbnail' => 'https://admin.mangotopup.com/products/1779738333.jpeg',
      'banner' => '',
      'description' => 'TikTok Coins',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 2,
      'created_at' => '2026-09-28 00:53:04',
    ),
    2 => 
    array (
      'id' => 3,
      'name' => 'DLS 2026',
      'slug' => 'dls-2026',
      'type' => 'uid',
      'category' => 'flash',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788635591.jpg',
      'banner' => '',
      'description' => 'DLS 2026',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 3,
      'created_at' => '2026-09-28 00:53:04',
    ),
    3 => 
    array (
      'id' => 4,
      'name' => 'Uid Topup [BD SERVER]',
      'slug' => 'uid-topup-bd',
      'type' => 'uid',
      'category' => 'hot',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786469692.jpeg',
      'banner' => '',
      'description' => 'Uid Topup [BD SERVER]',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '1405540000000',
      'status' => 'active',
      'sort_order' => 10,
      'created_at' => '2026-09-28 00:53:04',
    ),
    4 => 
    array (
      'id' => 5,
      'name' => 'Weekly/Monthly',
      'slug' => 'weekly-monthly',
      'type' => 'uid',
      'category' => 'hot',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786470110.jpeg',
      'banner' => '',
      'description' => 'Weekly/Monthly',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 11,
      'created_at' => '2026-09-28 00:53:04',
    ),
    5 => 
    array (
      'id' => 6,
      'name' => 'FF Like',
      'slug' => 'ff-like',
      'type' => 'uid',
      'category' => 'hot',
      'thumbnail' => 'https://admin.mangotopup.com/products/1785676047.jpg',
      'banner' => '',
      'description' => 'FF Like',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 12,
      'created_at' => '2026-09-28 00:53:04',
    ),
    6 => 
    array (
      'id' => 7,
      'name' => 'Level Up Pass BD',
      'slug' => 'level-up-pass-bd',
      'type' => 'uid',
      'category' => 'hot',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786469805.jpeg',
      'banner' => '',
      'description' => 'Level Up Pass BD',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 13,
      'created_at' => '2026-09-28 00:53:04',
    ),
    7 => 
    array (
      'id' => 8,
      'name' => 'Weekly Lite',
      'slug' => 'weekly-lite',
      'type' => 'uid',
      'category' => 'hot',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786470043.jpeg',
      'banner' => '',
      'description' => 'Weekly Lite',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 14,
      'created_at' => '2026-09-28 00:53:04',
    ),
    8 => 
    array (
      'id' => 9,
      'name' => 'UNIPIN VOUCHER (BDT)',
      'slug' => 'unipin-voucher',
      'type' => 'voucher',
      'category' => 'hot',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786469860.jpeg',
      'banner' => '',
      'description' => 'UNIPIN VOUCHER (BDT)',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 15,
      'created_at' => '2026-09-28 00:53:04',
    ),
    9 => 
    array (
      'id' => 10,
      'name' => 'EFootball™ Android',
      'slug' => 'efootball-android',
      'type' => 'uid',
      'category' => 'pes',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788804433.jpeg',
      'banner' => '',
      'description' => 'EFootball™ Android',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 20,
      'created_at' => '2026-09-28 00:53:04',
    ),
    10 => 
    array (
      'id' => 11,
      'name' => 'EFootball™ For I-Phone',
      'slug' => 'efootball-iphone',
      'type' => 'uid',
      'category' => 'pes',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788802444.jpeg',
      'banner' => '',
      'description' => 'EFootball™ For I-Phone',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 21,
      'created_at' => '2026-09-28 00:53:04',
    ),
    11 => 
    array (
      'id' => 12,
      'name' => 'FC Football™ {Stat Pass And Coins}',
      'slug' => 'fc-football',
      'type' => 'uid',
      'category' => 'pes',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788208179.jpeg',
      'banner' => '',
      'description' => 'FC Football™ {Stat Pass And Coins}',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 22,
      'created_at' => '2026-09-28 00:53:04',
    ),
    12 => 
    array (
      'id' => 13,
      'name' => 'EA SPORTS FC™ {Offers+Packs}',
      'slug' => 'ea-sports-fc',
      'type' => 'uid',
      'category' => 'pes',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788207982.jpeg',
      'banner' => '',
      'description' => 'EA SPORTS FC™ {Offers+Packs}',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 23,
      'created_at' => '2026-09-28 00:53:04',
    ),
    13 => 
    array (
      'id' => 14,
      'name' => 'Roblox Top Up',
      'slug' => 'roblox',
      'type' => 'uid',
      'category' => 'pes',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788550626.jpg',
      'banner' => '',
      'description' => 'Roblox Top Up',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 24,
      'created_at' => '2026-09-28 00:53:04',
    ),
    14 => 
    array (
      'id' => 15,
      'name' => 'PUBG Uid UC',
      'slug' => 'pubg-uid-uc',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786472520.jpeg',
      'banner' => '',
      'description' => 'PUBG Uid UC',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 30,
      'created_at' => '2026-09-28 00:53:04',
    ),
    15 => 
    array (
      'id' => 16,
      'name' => 'Premium User',
      'slug' => 'premium-user',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1773737494.jpeg',
      'banner' => '',
      'description' => 'Premium User',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 31,
      'created_at' => '2026-09-28 00:53:04',
    ),
    16 => 
    array (
      'id' => 17,
      'name' => 'COC',
      'slug' => 'coc',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1774813871.jpg',
      'banner' => '',
      'description' => 'COC',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 32,
      'created_at' => '2026-09-28 00:53:04',
    ),
    17 => 
    array (
      'id' => 18,
      'name' => 'Clash Royal',
      'slug' => 'clash-royal',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788956735.jpeg',
      'banner' => '',
      'description' => 'Clash Royal',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 33,
      'created_at' => '2026-09-28 00:53:04',
    ),
    18 => 
    array (
      'id' => 19,
      'name' => 'AIRDROP IN-GAME',
      'slug' => 'airdrop',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1784950679.jpg',
      'banner' => '',
      'description' => 'AIRDROP IN-GAME',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 34,
      'created_at' => '2026-09-28 00:53:04',
    ),
    19 => 
    array (
      'id' => 20,
      'name' => 'FF Uid [Indonesia]',
      'slug' => 'ff-indonesia',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1736417408.jpg',
      'banner' => '',
      'description' => 'FF Uid [Indonesia]',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 35,
      'created_at' => '2026-09-28 00:53:04',
    ),
    20 => 
    array (
      'id' => 21,
      'name' => 'Need Help??? টেলিগ্রামে মেসেজ করুন',
      'slug' => 'need-help',
      'type' => 'uid',
      'category' => 'others',
      'thumbnail' => 'https://admin.mangotopup.com/products/1788985891.jpeg',
      'banner' => '',
      'description' => 'Need Help??? টেলিগ্রামে মেসেজ করুন',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 36,
      'created_at' => '2026-09-28 00:53:04',
    ),
    21 => 
    array (
      'id' => 22,
      'name' => 'Good Shorts HUB',
      'slug' => 'good-shorts',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1789501564.jpeg',
      'banner' => '',
      'description' => 'Good Shorts HUB',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 40,
      'created_at' => '2026-09-28 00:53:04',
    ),
    22 => 
    array (
      'id' => 23,
      'name' => 'NETFLIX',
      'slug' => 'netflix',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1780857860.jpeg',
      'banner' => '',
      'description' => 'NETFLIX',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 41,
      'created_at' => '2026-09-28 00:53:04',
    ),
    23 => 
    array (
      'id' => 24,
      'name' => 'Amazon Prime',
      'slug' => 'amazon-prime',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1780861766.jpeg',
      'banner' => '',
      'description' => 'Amazon Prime',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 42,
      'created_at' => '2026-09-28 00:53:04',
    ),
    24 => 
    array (
      'id' => 25,
      'name' => 'Chorki',
      'slug' => 'chorki',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1780863260.jpeg',
      'banner' => '',
      'description' => 'Chorki',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 43,
      'created_at' => '2026-09-28 00:53:04',
    ),
    25 => 
    array (
      'id' => 26,
      'name' => 'VPN',
      'slug' => 'vpn',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1780864955.jpeg',
      'banner' => '',
      'description' => 'VPN',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 44,
      'created_at' => '2026-09-28 00:53:04',
    ),
    26 => 
    array (
      'id' => 27,
      'name' => 'Telegram Premium',
      'slug' => 'telegram-premium',
      'type' => 'uid',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1742713793.jpg',
      'banner' => '',
      'description' => 'Telegram Premium',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 45,
      'created_at' => '2026-09-28 00:53:04',
    ),
    27 => 
    array (
      'id' => 28,
      'name' => 'FB SERVICE',
      'slug' => 'fb-service',
      'type' => 'uid',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1740898059.jpg',
      'banner' => '',
      'description' => 'FB SERVICE',
      'rules' => 'Topup is only for Bangladesh server ID codes.
Mango TopUp is not responsible if diamonds are missing due to a wrong Player ID.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 46,
      'created_at' => '2026-09-28 00:53:04',
    ),
    28 => 
    array (
      'id' => 29,
      'name' => 'Crunchyroll Premium Offer',
      'slug' => 'crunchyroll',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1780860160.jpeg',
      'banner' => '',
      'description' => 'Crunchyroll Premium Offer',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 47,
      'created_at' => '2026-09-28 00:53:04',
    ),
    29 => 
    array (
      'id' => 30,
      'name' => 'Canva Pro',
      'slug' => 'canva-pro',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1779735024.jpeg',
      'banner' => '',
      'description' => 'Canva Pro',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 48,
      'created_at' => '2026-09-28 00:53:04',
    ),
    30 => 
    array (
      'id' => 31,
      'name' => '1 Month Yt Premium',
      'slug' => 'yt-premium',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1782068110.jpeg',
      'banner' => '',
      'description' => '1 Month Yt Premium',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 49,
      'created_at' => '2026-09-28 00:53:04',
    ),
    31 => 
    array (
      'id' => 32,
      'name' => 'Gemini Pro/Plus Veo 3 With Google Storage',
      'slug' => 'gemini-pro',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1786038533.jpg',
      'banner' => '',
      'description' => 'Gemini Pro/Plus Veo 3 With Google Storage',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 50,
      'created_at' => '2026-09-28 00:53:04',
    ),
    32 => 
    array (
      'id' => 33,
      'name' => 'Cap Cut',
      'slug' => 'capcut',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1780853818.jpeg',
      'banner' => '',
      'description' => 'Cap Cut',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 51,
      'created_at' => '2026-09-28 00:53:04',
    ),
    33 => 
    array (
      'id' => 34,
      'name' => 'Chat Gpt Premium',
      'slug' => 'chatgpt',
      'type' => 'voucher',
      'category' => 'subscription',
      'thumbnail' => 'https://admin.mangotopup.com/products/1758048680.png',
      'banner' => '',
      'description' => 'Chat Gpt Premium',
      'rules' => 'Voucher topup is only for BD server.
Redeem the code from shop.garena.my.',
      'stock_note' => '',
      'status' => 'active',
      'sort_order' => 52,
      'created_at' => '2026-09-28 00:53:04',
    ),
  ),
  'packages' => 
  array (
    0 => 
    array (
      'id' => 1,
      'game_id' => 1,
      'name' => 'Suarez Pack',
      'price' => 90,
      'sort_order' => 1,
      'status' => 'active',
    ),
    1 => 
    array (
      'id' => 2,
      'game_id' => 1,
      'name' => 'Iker Pack',
      'price' => 120,
      'sort_order' => 2,
      'status' => 'active',
    ),
    2 => 
    array (
      'id' => 3,
      'game_id' => 2,
      'name' => '70 Coins',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    3 => 
    array (
      'id' => 4,
      'game_id' => 2,
      'name' => '350 Coins',
      'price' => 449,
      'sort_order' => 2,
      'status' => 'active',
    ),
    4 => 
    array (
      'id' => 5,
      'game_id' => 2,
      'name' => '700 Coins',
      'price' => 849,
      'sort_order' => 3,
      'status' => 'active',
    ),
    5 => 
    array (
      'id' => 6,
      'game_id' => 3,
      'name' => '100 Coins',
      'price' => 80,
      'sort_order' => 1,
      'status' => 'active',
    ),
    6 => 
    array (
      'id' => 7,
      'game_id' => 3,
      'name' => '500 Coins',
      'price' => 350,
      'sort_order' => 2,
      'status' => 'active',
    ),
    7 => 
    array (
      'id' => 8,
      'game_id' => 4,
      'name' => 'Weekly',
      'price' => 155,
      'sort_order' => 1,
      'status' => 'active',
    ),
    8 => 
    array (
      'id' => 9,
      'game_id' => 4,
      'name' => 'Monthly',
      'price' => 775,
      'sort_order' => 2,
      'status' => 'active',
    ),
    9 => 
    array (
      'id' => 10,
      'game_id' => 4,
      'name' => '25 Diamond',
      'price' => 20,
      'sort_order' => 3,
      'status' => 'active',
    ),
    10 => 
    array (
      'id' => 11,
      'game_id' => 4,
      'name' => '50 Diamond',
      'price' => 35,
      'sort_order' => 4,
      'status' => 'active',
    ),
    11 => 
    array (
      'id' => 12,
      'game_id' => 4,
      'name' => '115 Diamond',
      'price' => 78,
      'sort_order' => 5,
      'status' => 'active',
    ),
    12 => 
    array (
      'id' => 13,
      'game_id' => 4,
      'name' => '240 Diamond',
      'price' => 156,
      'sort_order' => 6,
      'status' => 'active',
    ),
    13 => 
    array (
      'id' => 14,
      'game_id' => 4,
      'name' => '355 Diamond',
      'price' => 235,
      'sort_order' => 7,
      'status' => 'active',
    ),
    14 => 
    array (
      'id' => 15,
      'game_id' => 4,
      'name' => '480 Diamond',
      'price' => 316,
      'sort_order' => 8,
      'status' => 'active',
    ),
    15 => 
    array (
      'id' => 16,
      'game_id' => 4,
      'name' => '610 Diamond',
      'price' => 400,
      'sort_order' => 9,
      'status' => 'active',
    ),
    16 => 
    array (
      'id' => 17,
      'game_id' => 4,
      'name' => '850 Diamond',
      'price' => 558,
      'sort_order' => 10,
      'status' => 'active',
    ),
    17 => 
    array (
      'id' => 18,
      'game_id' => 4,
      'name' => '1240 Diamond',
      'price' => 799,
      'sort_order' => 11,
      'status' => 'active',
    ),
    18 => 
    array (
      'id' => 19,
      'game_id' => 4,
      'name' => '2530 Diamond',
      'price' => 1610,
      'sort_order' => 12,
      'status' => 'active',
    ),
    19 => 
    array (
      'id' => 20,
      'game_id' => 4,
      'name' => '5060 Diamond',
      'price' => 3220,
      'sort_order' => 13,
      'status' => 'active',
    ),
    20 => 
    array (
      'id' => 21,
      'game_id' => 5,
      'name' => 'Weekly',
      'price' => 155,
      'sort_order' => 1,
      'status' => 'active',
    ),
    21 => 
    array (
      'id' => 22,
      'game_id' => 5,
      'name' => 'Monthly',
      'price' => 775,
      'sort_order' => 2,
      'status' => 'active',
    ),
    22 => 
    array (
      'id' => 23,
      'game_id' => 5,
      'name' => 'Weekly Lite',
      'price' => 80,
      'sort_order' => 3,
      'status' => 'active',
    ),
    23 => 
    array (
      'id' => 24,
      'game_id' => 6,
      'name' => '50 Like',
      'price' => 20,
      'sort_order' => 1,
      'status' => 'active',
    ),
    24 => 
    array (
      'id' => 25,
      'game_id' => 6,
      'name' => '100 Like',
      'price' => 35,
      'sort_order' => 2,
      'status' => 'active',
    ),
    25 => 
    array (
      'id' => 26,
      'game_id' => 6,
      'name' => '200 Like',
      'price' => 60,
      'sort_order' => 3,
      'status' => 'active',
    ),
    26 => 
    array (
      'id' => 27,
      'game_id' => 7,
      'name' => 'Level Up Pass',
      'price' => 450,
      'sort_order' => 1,
      'status' => 'active',
    ),
    27 => 
    array (
      'id' => 28,
      'game_id' => 8,
      'name' => 'Weekly Lite',
      'price' => 80,
      'sort_order' => 1,
      'status' => 'active',
    ),
    28 => 
    array (
      'id' => 29,
      'game_id' => 9,
      'name' => '25 Diamond Code',
      'price' => 19,
      'sort_order' => 1,
      'status' => 'active',
    ),
    29 => 
    array (
      'id' => 30,
      'game_id' => 9,
      'name' => '50 Diamond Code',
      'price' => 35,
      'sort_order' => 2,
      'status' => 'active',
    ),
    30 => 
    array (
      'id' => 31,
      'game_id' => 9,
      'name' => '115 Diamond Code',
      'price' => 79,
      'sort_order' => 3,
      'status' => 'active',
    ),
    31 => 
    array (
      'id' => 32,
      'game_id' => 9,
      'name' => '240 Diamond Code',
      'price' => 159,
      'sort_order' => 4,
      'status' => 'active',
    ),
    32 => 
    array (
      'id' => 33,
      'game_id' => 9,
      'name' => '610 Diamond Code',
      'price' => 404,
      'sort_order' => 5,
      'status' => 'active',
    ),
    33 => 
    array (
      'id' => 34,
      'game_id' => 9,
      'name' => '1240 Diamond Code',
      'price' => 809,
      'sort_order' => 6,
      'status' => 'active',
    ),
    34 => 
    array (
      'id' => 35,
      'game_id' => 9,
      'name' => '2530 Diamond Code',
      'price' => 1626,
      'sort_order' => 7,
      'status' => 'active',
    ),
    35 => 
    array (
      'id' => 36,
      'game_id' => 9,
      'name' => 'Weekly Code',
      'price' => 160,
      'sort_order' => 8,
      'status' => 'active',
    ),
    36 => 
    array (
      'id' => 37,
      'game_id' => 9,
      'name' => 'Monthly Code',
      'price' => 775,
      'sort_order' => 9,
      'status' => 'active',
    ),
    37 => 
    array (
      'id' => 38,
      'game_id' => 10,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    38 => 
    array (
      'id' => 39,
      'game_id' => 10,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    39 => 
    array (
      'id' => 40,
      'game_id' => 11,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    40 => 
    array (
      'id' => 41,
      'game_id' => 11,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    41 => 
    array (
      'id' => 42,
      'game_id' => 12,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    42 => 
    array (
      'id' => 43,
      'game_id' => 12,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    43 => 
    array (
      'id' => 44,
      'game_id' => 13,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    44 => 
    array (
      'id' => 45,
      'game_id' => 13,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    45 => 
    array (
      'id' => 46,
      'game_id' => 14,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    46 => 
    array (
      'id' => 47,
      'game_id' => 14,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    47 => 
    array (
      'id' => 48,
      'game_id' => 15,
      'name' => '60 UC',
      'price' => 95,
      'sort_order' => 1,
      'status' => 'active',
    ),
    48 => 
    array (
      'id' => 49,
      'game_id' => 15,
      'name' => '325 UC',
      'price' => 480,
      'sort_order' => 2,
      'status' => 'active',
    ),
    49 => 
    array (
      'id' => 50,
      'game_id' => 15,
      'name' => '660 UC',
      'price' => 920,
      'sort_order' => 3,
      'status' => 'active',
    ),
    50 => 
    array (
      'id' => 51,
      'game_id' => 16,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    51 => 
    array (
      'id' => 52,
      'game_id' => 16,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    52 => 
    array (
      'id' => 53,
      'game_id' => 17,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    53 => 
    array (
      'id' => 54,
      'game_id' => 17,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    54 => 
    array (
      'id' => 55,
      'game_id' => 18,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    55 => 
    array (
      'id' => 56,
      'game_id' => 18,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    56 => 
    array (
      'id' => 57,
      'game_id' => 19,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    57 => 
    array (
      'id' => 58,
      'game_id' => 19,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    58 => 
    array (
      'id' => 59,
      'game_id' => 20,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    59 => 
    array (
      'id' => 60,
      'game_id' => 20,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    60 => 
    array (
      'id' => 61,
      'game_id' => 21,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    61 => 
    array (
      'id' => 62,
      'game_id' => 21,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    62 => 
    array (
      'id' => 63,
      'game_id' => 22,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    63 => 
    array (
      'id' => 64,
      'game_id' => 22,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    64 => 
    array (
      'id' => 65,
      'game_id' => 23,
      'name' => '1 Month',
      'price' => 199,
      'sort_order' => 1,
      'status' => 'active',
    ),
    65 => 
    array (
      'id' => 66,
      'game_id' => 23,
      'name' => '3 Month',
      'price' => 549,
      'sort_order' => 2,
      'status' => 'active',
    ),
    66 => 
    array (
      'id' => 67,
      'game_id' => 24,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    67 => 
    array (
      'id' => 68,
      'game_id' => 24,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    68 => 
    array (
      'id' => 69,
      'game_id' => 25,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    69 => 
    array (
      'id' => 70,
      'game_id' => 25,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    70 => 
    array (
      'id' => 71,
      'game_id' => 26,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    71 => 
    array (
      'id' => 72,
      'game_id' => 26,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    72 => 
    array (
      'id' => 73,
      'game_id' => 27,
      'name' => '1 Month',
      'price' => 249,
      'sort_order' => 1,
      'status' => 'active',
    ),
    73 => 
    array (
      'id' => 74,
      'game_id' => 27,
      'name' => '12 Month',
      'price' => 1999,
      'sort_order' => 2,
      'status' => 'active',
    ),
    74 => 
    array (
      'id' => 75,
      'game_id' => 28,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    75 => 
    array (
      'id' => 76,
      'game_id' => 28,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    76 => 
    array (
      'id' => 77,
      'game_id' => 29,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    77 => 
    array (
      'id' => 78,
      'game_id' => 29,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    78 => 
    array (
      'id' => 79,
      'game_id' => 30,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    79 => 
    array (
      'id' => 80,
      'game_id' => 30,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    80 => 
    array (
      'id' => 81,
      'game_id' => 31,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    81 => 
    array (
      'id' => 82,
      'game_id' => 31,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    82 => 
    array (
      'id' => 83,
      'game_id' => 32,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    83 => 
    array (
      'id' => 84,
      'game_id' => 32,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    84 => 
    array (
      'id' => 85,
      'game_id' => 33,
      'name' => 'Standard',
      'price' => 99,
      'sort_order' => 1,
      'status' => 'active',
    ),
    85 => 
    array (
      'id' => 86,
      'game_id' => 33,
      'name' => 'Premium',
      'price' => 199,
      'sort_order' => 2,
      'status' => 'active',
    ),
    86 => 
    array (
      'id' => 87,
      'game_id' => 34,
      'name' => '1 Month',
      'price' => 899,
      'sort_order' => 1,
      'status' => 'active',
    ),
  ),
);
