<?php
$siteName = getSetting($pdo, 'site_name', 'Mango TopUp');
$logo = getSetting($pdo, 'site_logo', '');
$isLoggedIn = isset($_SESSION['user_id']);
$walletBalance = $_SESSION['user_balance'] ?? 0;
$userName = $_SESSION['user_name'] ?? '';
$firstLetter = $userName ? strtoupper(substr($userName, 0, 1)) : 'U';
?>
<header class="bg-white sticky top-0 z-40 border-b border-gray-100">
    <div class="max-w-[430px] mx-auto px-3 py-3 flex items-center justify-between">
        <a href="<?= SITE_URL ?>/index.php" class="flex items-center gap-2">
            <?php if ($logo): ?>
                <img src="<?= htmlspecialchars($logo) ?>" alt="<?= htmlspecialchars($siteName) ?>" class="h-10 md:h-12 object-contain">
            <?php else: ?>
                <span class="w-9 h-9 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-white font-black"><?= strtoupper(substr($siteName,0,1)) ?></span>
                <span class="font-black text-sm"><?= htmlspecialchars($siteName) ?></span>
            <?php endif; ?>
        </a>
        <div class="flex items-center gap-4">
            <a href="<?= SITE_URL ?>/game.php" class="hidden md:inline text-sm font-semibold text-gray-700 hover:text-accent">Topup</a>
            <a href="<?= SITE_URL ?>/contact.php" class="hidden md:inline text-sm font-semibold text-gray-700 hover:text-accent">Contact Us</a>
            <?php if ($isLoggedIn): ?>
                <a href="<?= SITE_URL ?>/addmoney.php" class="bg-accent text-white font-bold px-3 py-1.5 rounded-full text-xs flex items-center gap-1">
                    <i class="fa-solid fa-wallet"></i> Tk <?= number_format((float)$walletBalance, 0) ?>
                </a>
                <a href="<?= SITE_URL ?>/profile.php" class="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-sm"><?= htmlspecialchars($firstLetter) ?></a>
            <?php else: ?>
                <a href="<?= SITE_URL ?>/login.php" class="bg-accent text-white px-5 py-1.5 rounded-md text-sm font-semibold shadow-sm">Login</a>
            <?php endif; ?>
        </div>
    </div>
</header>
