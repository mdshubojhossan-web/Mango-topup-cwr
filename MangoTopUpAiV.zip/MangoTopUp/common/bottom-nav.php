<?php
// common/bottom-nav.php
$currentPage = basename($_SERVER['PHP_SELF']);
$isLoggedIn = isset($_SESSION['user_id']);
?>
<?php if ($isLoggedIn): ?>
<div class="md:hidden fixed bottom-0 w-full bg-white shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-40 rounded-t-2xl flex justify-between items-center px-2 h-16">
    <a href="<?= SITE_URL ?>/index.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'index.php' ? 'text-accent' : 'text-gray-500' ?> transition">
        <i class="fa-solid fa-house text-xl mb-1"></i>
        <span class="text-[10px] font-medium">Home</span>
    </a>
    <a href="<?= SITE_URL ?>/order.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'order.php' ? 'text-accent' : 'text-gray-500' ?> transition">
        <i class="fa-solid fa-bag-shopping text-xl mb-1"></i>
        <span class="text-[10px] font-medium">My Orders</span>
    </a>
    <a href="<?= SITE_URL ?>/addmoney.php" class="relative -top-6 flex flex-col items-center justify-center w-16">
        <div class="bg-accent text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg border-4 border-[#F6F7FB]">
            <i class="fa-solid fa-plus text-2xl"></i>
        </div>
        <span class="text-[10px] font-medium text-gray-700 absolute -bottom-4 whitespace-nowrap">Add Money</span>
    </a>
    <a href="<?= SITE_URL ?>/mycode.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'mycode.php' ? 'text-accent' : 'text-gray-500' ?> transition">
        <i class="fa-regular fa-id-card text-xl mb-1"></i>
        <span class="text-[10px] font-medium">My Codes</span>
    </a>
    <a href="<?= SITE_URL ?>/profile.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'profile.php' ? 'text-accent' : 'text-gray-500' ?> transition">
        <i class="fa-regular fa-user text-xl mb-1"></i>
        <span class="text-[10px] font-medium">My Account</span>
    </a>
</div>
<?php else: ?>
<div class="md:hidden fixed bottom-0 w-full bg-white shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-40 flex justify-between items-center px-2 h-16">
    <a href="<?= SITE_URL ?>/index.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'index.php' ? 'text-accent' : 'text-gray-400' ?> transition">
        <i class="fa-solid fa-house text-xl mb-1"></i>
        <span class="text-[10px] font-medium">Home</span>
    </a>
    <a href="<?= SITE_URL ?>/tutorial.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'tutorial.php' ? 'text-accent' : 'text-gray-400' ?> transition">
        <i class="fa-regular fa-circle-play text-xl mb-1"></i>
        <span class="text-[10px] font-medium">Tutorial</span>
    </a>
    <a href="<?= SITE_URL ?>/game.php" class="flex flex-col items-center flex-1 <?= in_array($currentPage, ['game.php','game_detail.php']) ? 'text-accent' : 'text-gray-400' ?> transition">
        <i class="fa-solid fa-grip text-xl mb-1"></i>
        <span class="text-[10px] font-medium">TopUp</span>
    </a>
    <a href="<?= SITE_URL ?>/contact.php" class="flex flex-col items-center flex-1 <?= $currentPage == 'contact.php' ? 'text-accent' : 'text-gray-400' ?> transition">
        <i class="fa-solid fa-headset text-xl mb-1"></i>
        <span class="text-[10px] font-medium">Contact Us</span>
    </a>
</div>
<?php endif; ?>
