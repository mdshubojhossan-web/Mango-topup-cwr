<?php
require_once 'common/config.php';
$pageTitle = 'Contact Us | ' . siteName();
require_once 'common/header.php';
require_once 'common/navbar.php';
?>
<div class="bg-gray-50 min-h-screen pb-24">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold">Contact Us</h1>
    </div>
    <main class="max-w-3xl mx-auto px-4 mt-6 space-y-3">
        <a href="<?= htmlspecialchars(getSetting($pdo,'support_whatsapp','#')) ?>" class="block bg-white rounded-xl p-4 shadow-soft border flex items-center gap-3">
            <i class="fa-brands fa-whatsapp text-3xl text-green-500"></i>
            <div><p class="font-bold">WhatsApp Helpline</p><p class="text-xs text-gray-500">9AM - 12PM</p></div>
        </a>
        <a href="<?= htmlspecialchars(getSetting($pdo,'support_telegram','#')) ?>" class="block bg-white rounded-xl p-4 shadow-soft border flex items-center gap-3">
            <i class="fa-brands fa-telegram text-3xl text-sky-500"></i>
            <div><p class="font-bold">Telegram Support</p><p class="text-xs text-gray-500">9AM - 12PM</p></div>
        </a>
        <a href="<?= htmlspecialchars(getSetting($pdo,'social_facebook','#')) ?>" class="block bg-white rounded-xl p-4 shadow-soft border flex items-center gap-3">
            <i class="fa-brands fa-facebook text-3xl text-blue-600"></i>
            <div><p class="font-bold">Facebook Page</p><p class="text-xs text-gray-500">Updates and offers</p></div>
        </a>
    </main>
</div>
<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>
