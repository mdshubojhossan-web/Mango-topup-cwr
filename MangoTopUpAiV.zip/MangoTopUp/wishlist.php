<?php
// wishlist.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';
require_once 'common/navbar.php';

// Mock wishlist
$hasWishlist = true;
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 flex items-center shadow-sm sticky top-0 z-40">
        <h1 class="text-xl font-bold text-gray-900"><i class="fa-solid fa-heart text-red-500 mr-2"></i> My Wishlist</h1>
    </div>

    <main class="max-w-3xl mx-auto px-4 mt-6">
        
        <?php if($hasWishlist): ?>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div class="bg-white p-2 rounded-xl shadow-soft border border-gray-100 block group relative">
                    <button class="absolute top-3 right-3 w-8 h-8 bg-white/90 rounded-full text-red-500 shadow-sm z-10 flex items-center justify-center hover:bg-red-50 transition"><i class="fa-solid fa-trash-can text-sm"></i></button>
                    <div class="rounded-lg bg-gray-100 mb-2 overflow-hidden aspect-square">
                        <img src="https://via.placeholder.com/150/3FAE72/FFFFFF?text=FreeFire" class="w-full h-full object-cover">
                    </div>
                    <h3 class="font-semibold text-gray-800 text-xs truncate mb-2 text-center">Free Fire ID Code</h3>
                    <a href="game_detail.php?id=1" class="block w-full bg-accent text-white text-center py-1.5 rounded-lg text-xs font-bold hover:bg-orange-600 transition">Topup Now</a>
                </div>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-2xl shadow-soft p-10 text-center border border-gray-100">
                <i class="fa-regular fa-heart text-4xl text-gray-300 mb-4"></i>
                <h3 class="text-lg font-bold text-gray-700">Wishlist is Empty</h3>
                <p class="text-xs text-gray-500 mt-2">Save your favorite games here.</p>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>

