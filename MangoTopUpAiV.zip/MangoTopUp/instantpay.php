<?php
// instantpay.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';

// Check if data came from add money or game order
$isAddMoney = isset($_GET['action']) && $_GET['action'] == 'add_balance';
$amount = $isAddMoney ? ($_GET['amount'] ?? 0) : ($_POST['price'] ?? 0);
$gameId = (int)($_POST['game_id'] ?? 0);
$packageId = (int)($_POST['package_id'] ?? 0);
$playerId = sanitize($_POST['player_id'] ?? '');
$quantity = max(1, (int)($_POST['quantity'] ?? 1));

// Fallback for demo
if($amount == 0) $amount = 155; 
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <!-- Header -->
    <div class="bg-white px-4 py-4 shadow-sm flex items-center sticky top-0 z-40 gap-3">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">Payment Process</h1>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <!-- Order Summary -->
        <div class="bg-white rounded-xl shadow-soft p-4 border border-gray-100 mb-6">
            <h2 class="text-sm font-bold text-gray-500 uppercase mb-3">Order Summary</h2>
            <div class="flex justify-between items-center mb-2">
                <span class="text-gray-700 font-medium"><?= $isAddMoney ? 'Add Money to Wallet' : 'Game Topup' ?></span>
                <span class="font-bold text-gray-900">৳ <?= number_format($amount, 2) ?></span>
            </div>
            <div class="h-px bg-gray-100 my-2"></div>
            <div class="flex justify-between items-center">
                <span class="font-bold text-gray-900">Total Payable</span>
                <span class="font-black text-accent text-lg">৳ <?= number_format($amount, 2) ?></span>
            </div>
        </div>

        <form action="<?= SITE_URL ?>/ajax/submit-payment.php" method="POST" class="ajax-form" data-reset="true">
            <input type="hidden" name="type" value="<?= $isAddMoney ? 'add_money' : 'order' ?>">
            <input type="hidden" name="amount" value="<?= $amount ?>">
            <?php if (!$isAddMoney): ?>
            <input type="hidden" name="game_id" value="<?= $gameId ?>">
            <input type="hidden" name="package_id" value="<?= $packageId ?>">
            <input type="hidden" name="player_id" value="<?= htmlspecialchars($playerId, ENT_QUOTES) ?>">
            <input type="hidden" name="quantity" value="<?= $quantity ?>">
            <?php endif; ?>
            
            <!-- Payment Method Selection (Mocking DB Data) -->
            <div class="mb-6">
                <h3 class="font-bold text-gray-800 mb-3">Select Payment Method</h3>
                <div class="grid grid-cols-2 gap-3">
                    <label class="relative border-2 border-accent bg-orange-50 rounded-xl p-3 flex items-center gap-3 cursor-pointer">
                        <input type="radio" name="payment_method" value="bKash" class="hidden" checked>
                        <div class="w-8 h-8 rounded bg-pink-500 text-white flex items-center justify-center font-bold text-xs">bK</div>
                        <span class="font-bold text-gray-800 text-sm">bKash</span>
                    </label>
                    <label class="relative border border-gray-200 bg-white rounded-xl p-3 flex items-center gap-3 cursor-pointer hover:border-gray-300">
                        <input type="radio" name="payment_method" value="Nagad" class="hidden">
                        <div class="w-8 h-8 rounded bg-orange-500 text-white flex items-center justify-center font-bold text-xs">Ng</div>
                        <span class="font-bold text-gray-600 text-sm">Nagad</span>
                    </label>
                </div>
            </div>

            <!-- Payment Instructions Box -->
            <div class="bg-orange-50 border border-orange-100 rounded-xl p-4 mb-6">
                <p class="text-xs text-gray-600 mb-2">Please <span class="font-bold text-accent">Send Money</span> to the number below.</p>
                <div class="flex items-center justify-between bg-white border border-gray-200 rounded-lg p-3 mb-3">
                    <div>
                        <p class="text-[10px] text-gray-500 font-bold uppercase">bKash Personal</p>
                        <p class="font-black text-gray-800 text-lg tracking-wider" id="payNumber">01700-000000</p>
                    </div>
                    <button type="button" onclick="navigator.clipboard.writeText('01700000000'); showToast('Number Copied!');" class="w-10 h-10 bg-gray-100 rounded-lg text-gray-600 hover:bg-accent hover:text-white transition flex items-center justify-center">
                        <i class="fa-regular fa-copy"></i>
                    </button>
                </div>
            </div>

            <!-- Verification Inputs -->
            <div class="bg-white rounded-xl shadow-soft p-4 border border-gray-100 mb-6">
                <h3 class="font-bold text-gray-800 mb-4">Payment Verification</h3>
                
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-700 mb-1">Sender Number</label>
                    <input type="text" name="sender_number" required class="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition bg-gray-50 focus:bg-white" placeholder="Number you sent money from">
                </div>
                
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-700 mb-1">Transaction ID</label>
                    <input type="text" name="txn_id" required class="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition bg-gray-50 focus:bg-white uppercase" placeholder="e.g. 8M3JD92K1">
                </div>
            </div>
            
            <button type="submit" class="w-full bg-accent hover:bg-orange-600 text-white font-bold py-3.5 rounded-lg shadow-md transition uppercase tracking-wide flex justify-center items-center gap-2">
                <i class="fa-solid fa-check-circle"></i> Confirm Payment
            </button>
        </form>

    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
require_once 'common/footer.php';
?>
