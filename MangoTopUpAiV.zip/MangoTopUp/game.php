<?php
// game.php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/navbar.php';

$typeFilter =$_GET['type'] ?? 'all';

$query = "SELECT * FROM games WHERE status='active'";
if ($typeFilter === 'uid') {$query .= " AND type='uid'";
} elseif ($typeFilter === 'voucher') {$query .= " AND type='voucher'";
}
$query .= " ORDER BY sort_order ASC, id DESC";

$games = $pdo->query($query)->fetchAll();
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600 hover:text-accent transition"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold text-gray-900">All Games</h1>
    </div>

    <main class="max-w-[430px] md:max-w-[720px] mx-auto px-3 mt-6">
        
        <!-- Filter Tabs -->
        <div class="flex overflow-x-auto hide-scrollbar gap-2 mb-6 bg-white p-2 rounded-xl shadow-sm border border-gray-100">
            <a href="?type=all" class="flex-1 text-center py-2 rounded-lg text-xs font-bold transition <?= $typeFilter == 'all' ? 'bg-primary text-white shadow-sm' : 'text-gray-500 hover:bg-gray-50' ?>">All</a>
            <a href="?type=uid" class="flex-1 text-center py-2 rounded-lg text-xs font-bold transition <?= $typeFilter == 'uid' ? 'bg-primary text-white shadow-sm' : 'text-gray-500 hover:bg-gray-50' ?>">UID Topup</a>
            <a href="?type=voucher" class="flex-1 text-center py-2 rounded-lg text-xs font-bold transition <?= $typeFilter == 'voucher' ? 'bg-primary text-white shadow-sm' : 'text-gray-500 hover:bg-gray-50' ?>">Vouchers</a>
        </div>

        <?php if(count($games) > 0): ?>
            <div class="grid grid-cols-3 gap-2">
                <?php foreach($games as$game): ?>
                <a href="game_detail.php?id=<?= $game['id'] ?>" class="bg-white p-2 rounded-xl shadow-soft border border-gray-100 block group text-center relative">
                    <?php if($game['type'] == 'voucher'): ?>
                        <span class="absolute top-0 left-0 bg-accent text-white text-[9px] font-bold px-1.5 py-0.5 rounded-tl-xl rounded-br-lg z-10 uppercase tracking-wider">Voucher</span>
                    <?php endif; ?>
                    <div class="rounded-lg bg-gray-100 mb-2 overflow-hidden aspect-square">
                        <img src="<?= htmlspecialchars($game['thumbnail'] ?? 'https://via.placeholder.com/150') ?>" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt="<?= htmlspecialchars($game['name']) ?>">
                    </div>
                    <h3 class="font-semibold text-gray-700 text-[10px] leading-tight line-clamp-2 min-h-[28px] px-1"><?= htmlspecialchars($game['name']) ?></h3>
                </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-10 bg-white rounded-xl shadow-soft border border-gray-100">
                <i class="fa-solid fa-gamepad text-4xl text-gray-300 mb-3"></i>
                <p class="text-gray-500 font-medium text-sm">No games available in this category.</p>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
require_once 'common/footer.php';
?>

