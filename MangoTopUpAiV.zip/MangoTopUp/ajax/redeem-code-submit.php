<?php
// ajax/redeem-code-submit.php
require_once '../common/config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Please login to redeem codes.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = sanitize($_POST['code'] ?? '');
    
    if (empty($code)) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid code.']);
        exit;
    }

    // Checking if coupon exists and is active
    $stmt = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND status = 'active' AND used_count < usage_limit");
    $stmt->execute([$code]);
    $coupon = $stmt->fetch();

    if ($coupon) {
        echo json_encode([
            'status' => 'success', 
            'message' => 'Coupon applied successfully!',
            'discount_type' => $coupon['discount_type'],
            'discount_value' => $coupon['discount_value']
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid or expired code.']);
    }
}
?>

