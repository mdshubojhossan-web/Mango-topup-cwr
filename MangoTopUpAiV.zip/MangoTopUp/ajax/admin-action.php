<?php
require_once __DIR__ . '/../common/config.php';
while (ob_get_level()) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status'=>'error','message'=>'Unauthorized']);
    exit;
}
$action = $_POST['action'] ?? $_GET['action'] ?? '';

function ok($msg, $extra=[]) {
    echo json_encode(array_merge(['status'=>'success','message'=>$msg], $extra));
    exit;
}
function fail($msg) {
    echo json_encode(['status'=>'error','message'=>$msg]);
    exit;
}
function logAdmin($pdo, $text) {
    $pdo->prepare("INSERT INTO activity_logs (admin_id, action) VALUES (?, ?)")->execute([$_SESSION['admin_id'] ?? 0, $text]);
}
function save_upload($field, $folder) {
    if (!isset($_FILES[$field]) || ($_FILES[$field]['error'] ?? 1) !== UPLOAD_ERR_OK) return '';
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp','gif','svg'])) return '';
    $dir = dirname(__DIR__) . '/uploads/' . $folder . '/';
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    $name = $folder . '_' . uniqid() . '.' . $ext;
    $dest = $dir . $name;
    if (!@move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        $alt = '/tmp/' . $name;
        if (!@move_uploaded_file($_FILES[$field]['tmp_name'], $alt)) return '';
        return SITE_URL . '/uploads/' . $folder . '/' . $name;
    }
    return SITE_URL . '/uploads/' . $folder . '/' . $name;
}

if ($action === 'update_settings') {
    foreach (($_POST['settings'] ?? []) as $key => $value) {
        $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES (?, ?) ON CONFLICT(key_name) DO UPDATE SET value = excluded.value")->execute([$key, $value]);
    }
    $logo = save_upload('site_logo_file', 'logo');
    if ($logo) {
        $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES (?, ?) ON CONFLICT(key_name) DO UPDATE SET value = excluded.value")->execute(['site_logo', $logo]);
    }
    $popup = save_upload('popup_image_file', 'popup');
    if ($popup) {
        $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES (?, ?) ON CONFLICT(key_name) DO UPDATE SET value = excluded.value")->execute(['popup_image', $popup]);
    }
    logAdmin($pdo, 'Updated site settings');
    getSetting($pdo,'__reset');
    ok('Settings saved', ['redirect'=>'site-settings.php']);
}

if ($action === 'save_category') {
    $id = (int)($_POST['id'] ?? 0);
    $name = sanitize($_POST['name'] ?? '');
    $slug = sanitize($_POST['slug'] ?? '') ?: strtolower(preg_replace('/[^a-z0-9]+/i','-', $name));
    $sort = (int)($_POST['sort_order'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'active');
    if (!$name) fail('Category name required');
    if ($id) {
        $pdo->prepare("UPDATE categories SET name=?, slug=?, sort_order=?, status=? WHERE id=?")->execute([$name,$slug,$sort,$status,$id]);
        ok('Category updated', ['redirect'=>'category.php']);
    } else {
        $pdo->prepare("INSERT INTO categories (name, slug, sort_order, status) VALUES (?,?,?,?)")->execute([$name,$slug,$sort,$status]);
        ok('Category added', ['redirect'=>'category.php']);
    }
}
if ($action === 'delete_category') {
    $id=(int)($_POST['id']??0);
    $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
    ok('Category deleted');
}
if ($action === 'toggle_category') {
    $id=(int)($_POST['id']??0);
    $row=$pdo->prepare("SELECT * FROM categories WHERE id=?"); $row->execute([$id]); $row=$row->fetch();
    if(!$row) fail('Not found');
    $next = (($row['status']??'active')==='active')?'inactive':'active';
    $pdo->prepare("UPDATE categories SET status=? WHERE id=?")->execute([$next,$id]);
    ok('Category '.$next);
}

if ($action === 'save_game') {
    $id = (int)($_POST['id'] ?? 0);
    $name = sanitize($_POST['name'] ?? '');
    $slug = sanitize($_POST['slug'] ?? '') ?: strtolower(preg_replace('/[^a-z0-9]+/i','-', $name));
    $type = sanitize($_POST['type'] ?? 'uid');
    $category = sanitize($_POST['category'] ?? 'hot');
    $thumbnail = sanitize($_POST['thumbnail'] ?? '');
    $up = save_upload('thumbnail_file', 'games');
    if ($up) $thumbnail = $up;
    $rules = $_POST['rules'] ?? '';
    $stock = sanitize($_POST['stock_note'] ?? '');
    $status = sanitize($_POST['status'] ?? 'active');
    $sort = (int)($_POST['sort_order'] ?? 0);
    if (!$name) fail('Product name required');
    if ($id) {
        $pdo->prepare("UPDATE games SET name=?, slug=?, type=?, category=?, thumbnail=?, rules=?, stock_note=?, status=?, sort_order=? WHERE id=?")
            ->execute([$name,$slug,$type,$category,$thumbnail,$rules,$stock,$status,$sort,$id]);
        logAdmin($pdo, "Updated product #$id");
        ok('Product updated', ['redirect'=>'product.php?edit='.$id]);
    } else {
        $pdo->prepare("INSERT INTO games (name, slug, type, category, thumbnail, description, rules, stock_note, status, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?)")
            ->execute([$name,$slug,$type,$category,$thumbnail,$name,$rules,$stock,$status,$sort]);
        logAdmin($pdo, 'Added product '.$name);
        ok('Product added', ['redirect'=>'product.php']);
    }
}
if ($action === 'delete_game') {
    $id = (int)($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM games WHERE id=?")->execute([$id]);
    $pdo->prepare("DELETE FROM packages WHERE game_id=?")->execute([$id]);
    ok('Product deleted');
}
if ($action === 'toggle_game') {
    $id=(int)($_POST['id']??0);
    $row=$pdo->prepare("SELECT * FROM games WHERE id=?"); $row->execute([$id]); $row=$row->fetch();
    if(!$row) fail('Not found');
    $next = (($row['status']??'active')==='active')?'inactive':'active';
    $pdo->prepare("UPDATE games SET status=? WHERE id=?")->execute([$next,$id]);
    ok('Product '.$next);
}

if ($action === 'save_package') {
    $id = (int)($_POST['id'] ?? 0);
    $gameId = (int)($_POST['game_id'] ?? 0);
    $name = sanitize($_POST['name'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $old = (float)($_POST['old_price'] ?? 0);
    $discount = (float)($_POST['discount'] ?? 0);
    $sort = (int)($_POST['sort_order'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'active');
    if ($discount > 0 && $old > $price) {
        /* keep both */
    } elseif ($discount > 0 && $old <= 0) {
        $old = $price;
        $price = round($price - ($price * $discount / 100), 2);
    }
    if (!$gameId || !$name) fail('Package name required');
    if ($id) {
        $pdo->prepare("UPDATE packages SET name=?, price=?, old_price=?, discount=?, sort_order=?, status=? WHERE id=?")
            ->execute([$name,$price,$old,$discount,$sort,$status,$id]);
        ok('Package updated', ['redirect'=>'product.php?edit='.$gameId]);
    } else {
        $pdo->prepare("INSERT INTO packages (game_id, name, price, old_price, discount, sort_order, status) VALUES (?,?,?,?,?,?,?)")
            ->execute([$gameId,$name,$price,$old,$discount,$sort,$status]);
        ok('Package added', ['redirect'=>'product.php?edit='.$gameId]);
    }
}
if ($action === 'delete_package') {
    $id = (int)($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM packages WHERE id=?")->execute([$id]);
    ok('Package deleted');
}
if ($action === 'toggle_package') {
    $id=(int)($_POST['id']??0);
    $row=$pdo->prepare("SELECT * FROM packages WHERE id=?"); $row->execute([$id]); $row=$row->fetch();
    if(!$row) fail('Not found');
    $next = (($row['status']??'active')==='active')?'inactive':'active';
    $pdo->prepare("UPDATE packages SET status=? WHERE id=?")->execute([$next,$id]);
    ok('Package '.$next);
}

if ($action === 'update_order_status') {
    $id = (int)($_POST['id'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'Pending');
    $pdo->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$status,$id]);
    ok('Order status updated');
}
if ($action === 'toggle_user') {
    $id = (int)($_POST['id'] ?? 0);
    $user = $pdo->prepare("SELECT * FROM users WHERE id=?"); $user->execute([$id]); $user=$user->fetch();
    if (!$user) fail('User not found');
    $next = ($user['status'] ?? 'active') === 'blocked' ? 'active' : 'blocked';
    $pdo->prepare("UPDATE users SET status=? WHERE id=?")->execute([$next,$id]);
    ok('User '.$next);
}
if ($action === 'adjust_balance') {
    $id = (int)($_POST['id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $user = $pdo->prepare("SELECT * FROM users WHERE id=?"); $user->execute([$id]); $user=$user->fetch();
    if (!$user) fail('User not found');
    $new = max(0, (float)$user['balance'] + $amount);
    $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$new,$id]);
    ok('Balance updated to '.$new);
}
if ($action === 'wallet_action') {
    $id = (int)($_POST['id'] ?? 0);
    $do = sanitize($_POST['do'] ?? '');
    $req = $pdo->prepare("SELECT * FROM wallet_requests WHERE id=?"); $req->execute([$id]); $req=$req->fetch();
    if (!$req) fail('Request not found');
    if (($req['status'] ?? 'Pending') !== 'Pending') fail('This request has already been processed');
    if ($do === 'approve') {
        $user = $pdo->prepare("SELECT * FROM users WHERE id=?"); $user->execute([$req['user_id']]); $user=$user->fetch();
        if (!$user) fail('User not found');
        $new = (float)($user['balance'] ?? 0) + (float)$req['amount'];
        $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$new, $req['user_id']]);
        $pdo->prepare("UPDATE wallet_requests SET status=? WHERE id=?")->execute(['Approved',$id]);
        ok('Approved and balance added');
    } elseif ($do === 'reject') {
        $pdo->prepare("UPDATE wallet_requests SET status=? WHERE id=?")->execute(['Rejected',$id]);
        ok('Request rejected');
    } else {
        fail('Invalid wallet action');
    }
}
if ($action === 'add_slider') {
    $link = sanitize($_POST['link_url'] ?? '');
    $imageUrl = sanitize($_POST['image_url'] ?? '');
    $up = save_upload('image', 'slides');
    if ($up) $imageUrl = $up;
    if (!$imageUrl) fail('Image required');
    $pdo->prepare("INSERT INTO sliders (image, link_url, status, sort_order) VALUES (?,?,?,?)")->execute([$imageUrl,$link,'active',0]);
    ok('Banner added', ['redirect'=>'slider.php']);
}
if ($action === 'delete_slider') {
    $id=(int)($_POST['id']??0);
    $pdo->prepare("DELETE FROM sliders WHERE id=?")->execute([$id]);
    ok('Banner deleted');
}
if ($action === 'toggle_slider') {
    $id=(int)($_POST['id']??0);
    $row=$pdo->prepare("SELECT * FROM sliders WHERE id=?"); $row->execute([$id]); $row=$row->fetch();
    $next = (($row['status']??'active')==='active')?'inactive':'active';
    $pdo->prepare("UPDATE sliders SET status=? WHERE id=?")->execute([$next,$id]);
    ok('Banner '.$next);
}
if ($action === 'add_payment_method') {
    $name=sanitize($_POST['name']??''); $number=sanitize($_POST['number']??''); $status=sanitize($_POST['status']??'active');
    if(!$name||!$number) fail('All fields required');
    $pdo->prepare("INSERT INTO payment_methods (name, number, status) VALUES (?,?,?)")->execute([$name,$number,$status]);
    ok('Payment method added', ['redirect'=>'payment-method.php']);
}
if ($action === 'delete_payment') {
    $id=(int)($_POST['id']??0);
    $pdo->prepare("DELETE FROM payment_methods WHERE id=?")->execute([$id]);
    ok('Removed');
}
if ($action === 'add_codes') {
    $gameId=$_POST['game_id']??0; $packageId=$_POST['package_id']??0; $codesRaw=$_POST['codes']??'';
    if(!$gameId||!$packageId||!$codesRaw) fail('Fill all fields');
    $n=0;
    foreach (explode("\n", str_replace("\r",'',$codesRaw)) as $code) {
        $code=sanitize($code); if($code==='') continue;
        $pdo->prepare("INSERT INTO redeem_codes (game_id, package_id, code) VALUES (?,?,?)")->execute([$gameId,$packageId,$code]);
        $n++;
    }
    ok("$n codes added", ['redirect'=>'redeem-code.php']);
}
if ($action === 'save_coupon') {
    $code=sanitize($_POST['code']??''); $discount=(float)($_POST['discount']??0);
    if(!$code) fail('Code required');
    $pdo->prepare("INSERT INTO coupons (code, discount, type, status) VALUES (?,?,?,?)")->execute([$code,$discount,'percent','active']);
    ok('Coupon added', ['redirect'=>'coupon.php']);
}
fail('Unknown action');
