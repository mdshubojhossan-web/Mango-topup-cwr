<?php
// ajax/wishlist-toggle.php
require_once '../common/config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Please login to save games.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $gameId = (int)($_POST['game_id'] ?? 0);

    if ($gameId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid game.']);
        exit;
    }

    // Check if already in wishlist
    $stmt = $pdo->prepare("SELECT id FROM wishlist WHERE user_id = ? AND game_id = ?");
    $stmt->execute([$userId, $gameId]);
    $exists = $stmt->fetch();

    if ($exists) {
        // Remove from wishlist
        $pdo->prepare("DELETE FROM wishlist WHERE id = ?")->execute([$exists['id']]);
        echo json_encode(['status' => 'success', 'message' => 'Removed from wishlist', 'action' => 'removed']);
    } else {
        // Add to wishlist
        $pdo->prepare("INSERT INTO wishlist (user_id, game_id) VALUES (?, ?)")->execute([$userId, $gameId]);
        echo json_encode(['status' => 'success', 'message' => 'Added to wishlist', 'action' => 'added']);
    }
}
?>

