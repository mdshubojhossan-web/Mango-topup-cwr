<?php
// ajax/review-submit.php
require_once '../common/config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Please login to submit a review.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $gameId = (int)($_POST['game_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 5);
    $comment = sanitize($_POST['comment'] ?? '');

    if ($gameId <= 0 || empty($comment)) {
        echo json_encode(['status' => 'error', 'message' => 'Please provide a valid rating and comment.']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO reviews (user_id, game_id, rating, comment) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$userId, $gameId, $rating, $comment])) {
        echo json_encode(['status' => 'success', 'message' => 'Review submitted successfully! Pending approval.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit review.']);
    }
}
?>

