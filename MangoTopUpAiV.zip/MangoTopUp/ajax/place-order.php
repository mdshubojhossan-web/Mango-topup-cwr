<?php
// ajax/place-order.php
require_once '../common/config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Please login to place an order.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $orderNo = 'ICX' . strtoupper(uniqid());
    
    $gameId = (int)($_POST['game_id'] ?? 0);
    $packageId = (int)($_POST['package_id'] ?? 0);
    $playerId = sanitize($_POST['player_id'] ?? '');
    $paymentMethod = sanitize($_POST['payment_method'] ?? 'wallet');
    $txnId = sanitize($_POST['txn_id'] ?? 'N/A');
    $amount = 0;

    if (empty($gameId) || empty($packageId) || $playerId === '') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid order details.']);
        exit;
    }

    $gameStmt = $pdo->prepare("SELECT id, type FROM games WHERE id=? AND status='active'");
    $gameStmt->execute([$gameId]);
    $game = $gameStmt->fetch();
    $packageStmt = $pdo->prepare("SELECT id, game_id, price FROM packages WHERE id=? AND game_id=? AND status='active'");
    $packageStmt->execute([$packageId, $gameId]);
    $package = $packageStmt->fetch();
    if (!$game || !$package || ($game['type'] ?? 'uid') === 'uid' && $playerId === '') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid product or package.']);
        exit;
    }
    $amount = (float)$package['price'];
    if ($amount <= 0 || !in_array($paymentMethod, ['wallet', 'instant'], true)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid payment details.']);
        exit;
    }
    if ($paymentMethod === 'wallet') {
        $userStmt = $pdo->prepare('SELECT balance FROM users WHERE id=? AND status=\'active\'');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user || (float)$user['balance'] < $amount) {
            echo json_encode(['status' => 'error', 'message' => 'Insufficient wallet balance.']);
            exit;
        }
        $pdo->prepare('UPDATE users SET balance=? WHERE id=?')->execute([(float)$user['balance'] - $amount, $userId]);
    }

    $stmt = $pdo->prepare("INSERT INTO orders (order_no, user_id, game_id, package_id, player_id, total_amount, payment_method, txn_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt->execute([$orderNo, $userId, $gameId, $packageId, $playerId, $amount, $paymentMethod, $txnId])) {
        echo json_encode(['status' => 'success', 'message' => 'Order placed successfully!', 'redirect' => '../order.php']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to place order.']);
    }
}
?>
