<?php
// ajax/notification-read.php
require_once '../common/config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    
    // Mark all as read
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
    if ($stmt->execute([$userId])) {
        echo json_encode(['status' => 'success', 'message' => 'Notifications marked as read.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update notifications.']);
    }
}
?>

