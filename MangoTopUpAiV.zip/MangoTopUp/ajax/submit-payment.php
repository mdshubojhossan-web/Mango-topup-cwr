<?php
// ajax/submit-payment.php
require_once '../common/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'Please login first.']);
        exit;
    }

    $userId = $_SESSION['user_id'];
    $type = $_POST['type'] ?? 'order';
    $amount = (float)($_POST['amount'] ?? 0);
    $paymentMethod = sanitize($_POST['payment_method'] ?? '');
    $senderNumber = sanitize($_POST['sender_number'] ?? '');
    $txnId = sanitize($_POST['txn_id'] ?? '');

    if ($amount < 10 || !is_finite($amount) || empty($paymentMethod) || empty($senderNumber) || empty($txnId)) {
        echo json_encode(['status' => 'error', 'message' => 'Please fill all payment details.']);
        exit;
    }
    $methodStmt = $pdo->prepare("SELECT id FROM payment_methods WHERE name=? AND status='active'");
    $methodStmt->execute([$paymentMethod]);
    if (!$methodStmt->fetch()) {
        echo json_encode(['status' => 'error', 'message' => 'This payment method is unavailable.']);
        exit;
    }

    if ($type === 'add_money') {
        // Handle Wallet Add Money Request
        $stmt = $pdo->prepare("INSERT INTO wallet_requests (user_id, amount, payment_method, txn_id) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$userId, $amount, $paymentMethod, $txnId])) {
            echo json_encode([
                'status' => 'success', 
                'message' => 'Wallet request submitted! Pending admin approval.', 
                'redirect' => '../profile.php'
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to submit request. Try again.']);
        }
    } else {
        // Handle Game Topup Order
        $orderNo = 'ICX' . strtoupper(uniqid());
        $gameId = (int)($_POST['game_id'] ?? 0);
        $packageId = (int)($_POST['package_id'] ?? 0);
        $playerId = sanitize($_POST['player_id'] ?? '');
        $gameStmt = $pdo->prepare("SELECT id, type FROM games WHERE id=? AND status='active'");
        $gameStmt->execute([$gameId]);
        $game = $gameStmt->fetch();
        $packageStmt = $pdo->prepare("SELECT id, game_id, price FROM packages WHERE id=? AND game_id=? AND status='active'");
        $packageStmt->execute([$packageId, $gameId]);
        $package = $packageStmt->fetch();
        if (!$game || !$package || ($game['type'] ?? 'uid') === 'uid' && $playerId === '') {
            echo json_encode(['status' => 'error', 'message' => 'Invalid product, package, or player ID.']);
            exit;
        }
        $amount = (float)$package['price'];
        $stmt = $pdo->prepare("INSERT INTO orders (order_no, user_id, game_id, package_id, player_id, total_amount, payment_method, txn_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$orderNo, $userId, $gameId, $packageId, $playerId, $amount, $paymentMethod, $txnId])) {
            echo json_encode([
                'status' => 'success', 
                'message' => 'Order placed successfully! Please wait for processing.', 
                'redirect' => '../order.php'
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to place order. Try again.']);
        }
    }
}
?>
