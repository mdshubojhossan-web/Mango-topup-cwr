<?php
require_once 'common/config.php';
$pageTitle = 'About Us | ' . siteName();
require_once 'common/header.php';
require_once 'common/navbar.php';
?>
<div class="bg-gray-50 min-h-screen pb-24">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold">About Us</h1>
    </div>
    <main class="max-w-3xl mx-auto px-4 mt-6">
        <div class="bg-white rounded-xl shadow-soft p-6 border border-gray-100 text-sm text-gray-600 leading-relaxed space-y-3">
            <h2 class="text-xl font-black text-gray-900"><?= htmlspecialchars(siteName()) ?></h2>
            <p><?= htmlspecialchars(siteName()) ?> is a Bangladesh based digital top-up platform for games, vouchers and subscriptions. We deliver UID top-up and voucher codes quickly with wallet pay and instant pay options.</p>
            <p>Our goal is simple: fast delivery, clear pricing and reliable support through WhatsApp and Telegram.</p>
        </div>
    </main>
</div>
<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>
