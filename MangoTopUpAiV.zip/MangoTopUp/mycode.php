<?php
// mycode.php
require_once 'common/config.php';
require_once 'common/auth-check.php';
require_once 'common/header.php';

// Check if user has codes (Mocking empty state as per screenshot)
$hasCodes = false; 
?>

<div class="bg-gray-50 min-h-screen pb-24 md:pb-8">
    
    <!-- Header -->
    <div class="bg-white px-4 py-4 flex items-center justify-between shadow-sm sticky top-0 z-40">
        <div class="flex items-center">
            <div class="border border-gray-200 rounded-lg p-1.5 mr-3 flex items-center justify-center text-gray-700 bg-gray-50">
                <i class="fa-regular fa-file-lines text-sm"></i>
            </div>
            <h1 class="text-xl font-bold text-gray-900">My Codes</h1>
        </div>
        <a href="https://shop.garena.my/app" target="_blank" rel="noopener" class="bg-accent text-white text-xs font-bold py-2 px-3 rounded-full shadow-sm hover:bg-orange-600 transition flex items-center gap-1.5">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Redeem Code
        </a>
    </div>

    <main class="max-w-md mx-auto px-4 mt-6">
        
        <?php if(!$hasCodes): ?>
        <!-- Empty State -->
        <div class="bg-white rounded-2xl shadow-soft p-10 text-center border border-gray-100 mb-6">
            <h3 class="text-lg font-bold text-gray-700 mb-5">No code data found !</h3>
            <a href="<?= SITE_URL ?>/index.php" class="inline-block bg-accent hover:bg-orange-600 text-white font-bold py-2.5 px-8 rounded-full shadow-md transition text-sm uppercase tracking-wider">
                ORDER NOW
            </a>
        </div>
        <?php else: ?>
        <!-- Code List will go here when data exists -->
        <?php endif; ?>

    </main>
</div>

<?php 
require_once 'common/bottom-nav.php'; 
?>
<!-- Floating Action Button (Headset Icon) -->
<a href="#" class="fixed bottom-24 right-4 bg-accent text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:scale-105 transition z-50 border-2 border-white/20">
    <i class="fa-solid fa-headset text-xl"></i>
</a>
<?php
require_once 'common/footer.php';
?>

