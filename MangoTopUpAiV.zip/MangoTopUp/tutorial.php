<?php
require_once 'common/config.php';
$pageTitle = 'টিউটোরিয়াল | ' . siteName();
require_once 'common/header.php';
require_once 'common/navbar.php';
?>
<div class="bg-gray-50 min-h-screen pb-24">
    <div class="bg-white px-4 py-4 shadow-sm sticky top-0 z-40 flex items-center gap-3">
        <a href="javascript:history.back()" class="text-gray-600"><i class="fa-solid fa-arrow-left"></i></a>
        <h1 class="text-xl font-bold">কীভাবে অর্ডার করবেন?</h1>
    </div>
    <main class="max-w-3xl mx-auto px-4 mt-6 space-y-3 text-sm">
        <?php
        $steps = [
            'একটি পণ্য নির্বাচন করে প্যাকেজ বেছে নিন।',
            'UID টপআপের জন্য সঠিক Player ID লিখুন।',
            'লগইন করে Wallet Pay অথবা Instant Pay নির্বাচন করুন।',
            'পেমেন্টের পর Transaction ID জমা দিন।',
            'My Orders থেকে অর্ডারের স্ট্যাটাস দেখুন।',
        ];
        foreach ($steps as $i=>$s): ?>
        <div class="bg-white rounded-xl p-4 shadow-soft border border-gray-100 flex gap-3">
            <span class="w-7 h-7 rounded-full bg-accent text-white flex items-center justify-center font-bold shrink-0"><?= $i+1 ?></span>
            <p class="font-medium text-gray-700"><?= $s ?></p>
        </div>
        <?php endforeach; ?>
    </main>
</div>
<?php require_once 'common/bottom-nav.php'; require_once 'common/footer.php'; ?>
